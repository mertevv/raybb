# -*- coding: utf-8 -*-
"""Event builder: turns a parsed transaction into the emitted payload.

The output is schema-compatible with the reference webhook payload:

``id``, ``event_type``, ``timestamp``, ``chain``, ``failed``, ``source``,
``fee_payer``, ``followed_wallets``, ``token_changes``, ``tokens``, ``position``,
``fees``, ``event``.

Amounts always come from real balance deltas. Decoded instruction data is used
only for classification and for the enrichment fields (``pool``, ``commission``,
bin range, realised amounts), and any decoded figure that disagrees with the
observed delta is discarded rather than reported.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Sequence

from .deltas import LAMPORTS_PER_SOL, BalanceDelta, TxView
from .decoders import TradeIntent, TransferIntent, analyse
from .decoders.base import normalise_instructions
from .ids import (
    ASSOCIATED_TOKEN_PROGRAM,
    COMPUTE_BUDGET,
    JITO_TIP_PROGRAM,
    QUOTE_MINTS,
    ROUTER_PROGRAMS,
    SYSTEM_PROGRAM,
    TOKEN_2022_PROGRAM,
    TOKEN_PROGRAM,
    WSOL,
    source_for,
)
from .positions import PositionTracker
from .pricing import PriceOracle, TokenInfo
from .store import Store

log = logging.getLogger("raycore.events")

CHAIN = "solana"

#: A native-SOL leg worth less than this fraction of the other outgoing legs is
#: treated as transaction cost rather than the payment for the trade.
_FEE_DUST_RATIO = 0.02

#: event_type values the emitter can produce.
EVENT_TYPES = (
    "buy",
    "sell",
    "swap",
    "transfer_in",
    "transfer_out",
    "token_mint",
    "add_liquidity",
    "remove_liquidity",
    "migrate",
    "other",
)


def _iso(ts: float | None) -> str:
    moment = datetime.fromtimestamp(ts or 0.0, tz=timezone.utc)
    return moment.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _iso_optional(ts: float | None) -> str | None:
    if not ts:
        return None
    try:
        return _iso(ts)
    except (OverflowError, OSError, ValueError):
        return None


# --------------------------------------------------------------------------- #
#  Fees
# --------------------------------------------------------------------------- #


def extract_fees(view: TxView) -> dict[str, float]:
    """Priority fee and Jito tip paid by the transaction.

    The compute-budget instructions carry the requested values, which is what the
    payer was charged for the priority component; the tip is read off the Jito
    tip-account transfer when present.
    """
    priority = 0.0
    tip = 0.0

    for ix in normalise_instructions(view.raw):
        if ix.program_id == COMPUTE_BUDGET and len(ix.data) >= 5:
            from .binary import Reader

            reader = Reader(ix.data)
            try:
                kind = reader.u8()
                if kind == 3:  # SetComputeUnitPrice
                    micros = reader.u64()
                    priority += micros / 1_000_000.0
                elif kind == 2:  # SetComputeUnitLimit — not a fee
                    continue
            except Exception:  # noqa: BLE001
                continue

    instructions = normalise_instructions(view.raw)
    tip_index = next(
        (i for i, ix in enumerate(instructions) if ix.program_id == JITO_TIP_PROGRAM),
        None,
    )
    if tip_index is not None:
        for ix in instructions[tip_index + 1 :]:
            if ix.program_id != SYSTEM_PROGRAM or len(ix.data) < 12:
                continue
            from .binary import Reader

            try:
                reader = Reader(ix.data)
                if reader.u32() == 2:
                    tip += reader.u64() / LAMPORTS_PER_SOL
            except Exception:  # noqa: BLE001
                continue
            break

    return {
        "priority_fee": round(priority, 12),
        "jito_tip": round(tip, 12),
        "total_tip": round(priority + tip, 12),
    }


# --------------------------------------------------------------------------- #
#  Classification
# --------------------------------------------------------------------------- #


def _pick_intent(
    intents: Sequence[TradeIntent],
    wallet: str,
    incoming: Sequence[BalanceDelta],
    outgoing: Sequence[BalanceDelta],
) -> TradeIntent | None:
    """Choose the intent that best describes what *wallet* actually did."""
    if not intents:
        return None
    in_mints = {d.mint for d in incoming}
    out_mints = {d.mint for d in outgoing}

    def score(intent: TradeIntent) -> int:
        points = 0
        legs = {intent.mint_in, intent.mint_out} - {None}
        if legs & in_mints:
            points += 2
        if legs & out_mints:
            points += 2
        if intent.source == "pumpfun" and WSOL in legs:
            points += 1
        # A fill can belong to several participants; prefer the one naming us.
        if intent.extra.get("user") == wallet:
            points += 4
        # Prefer non-router venues: a Jupiter route wrapping a Raydium fill should
        # report the venue that actually executed it.
        if intent.program_id not in ROUTER_PROGRAMS:
            points += 1
        return points

    return max(intents, key=score)


def classify(
    deltas: Sequence[BalanceDelta],
    intent: TradeIntent | None,
    transfers: Sequence[TransferIntent],
) -> tuple[str, dict[str, Any]]:
    """Decide the ``event_type`` and build the ``event`` block.

    Order of evidence: the decoded venue intent, then explicit transfer/mint
    instructions, then the shape of the balance movement on its own. The last one
    means an unrecognised program still yields a sensible ``swap`` rather than
    being dropped.
    """
    incoming = [d for d in deltas if d.raw_delta > 0]
    outgoing = [d for d in deltas if d.raw_delta < 0]

    if intent is not None:
        event_type = intent.kind if intent.kind in EVENT_TYPES else "other"
        if event_type == "migrate":
            event_type = "migrate"
        detail: dict[str, Any] = {
            "type": event_type,
            "mintIn": intent.mint_in,
            "mintOut": intent.mint_out,
            "programId": intent.program_id,
        }
        if intent.pool:
            detail["pool"] = intent.pool
        if intent.commission:
            detail["commission"] = intent.commission
        detail.update(intent.extra)
        return event_type, detail

    mint_transfer = next((t for t in transfers if t.kind == "transfer" and t.mint), None)
    if mint_transfer is not None:
        direction = "out" if any(d.mint == mint_transfer.mint and d.raw_delta < 0 for d in deltas) else "in"
        event_type = "transfer_out" if direction == "out" else "transfer_in"
        detail = {
            "type": "transfer",
            "mintIn": mint_transfer.mint if direction == "in" else None,
            "mintOut": mint_transfer.mint if direction == "out" else None,
            "from": mint_transfer.from_,
            "to": mint_transfer.to,
            "amountIn": mint_transfer.extra.get("amount") if direction == "in" else None,
            "amountOut": mint_transfer.extra.get("amount") if direction == "out" else None,
        }
        if "authority" in mint_transfer.extra:
            detail["authority"] = mint_transfer.authority
            detail["isDelegated"] = mint_transfer.extra.get("isDelegated", False)
        return event_type, detail

    mint_intent = next((t for t in transfers if t.kind == "mint"), None)
    if mint_intent is not None and any(d.raw_delta > 0 for d in incoming):
        return "token_mint", {
            "type": "mint",
            "mintIn": mint_intent.mint,
            "mintOut": None,
            "to": mint_intent.to,
            "authority": mint_intent.authority,
        }

    if not incoming:
        event_type = "transfer_out" if outgoing else "other"
        return event_type, {
            "type": "transfer_out" if outgoing else "unknown",
            "mintIn": None,
            "mintOut": outgoing[0].mint if outgoing else None,
        }

    if not outgoing:
        return "transfer_in", {
            "type": "transfer_in",
            "mintIn": incoming[0].mint,
            "mintOut": None,
        }

    # Two legs moving in opposite directions: a swap of unknown venue.
    leg_in = incoming[0]
    leg_out = outgoing[0]
    quote_in = leg_in.mint in QUOTE_MINTS
    quote_out = leg_out.mint in QUOTE_MINTS
    if quote_out and not quote_in:
        event_type = "buy"
    elif quote_in and not quote_out:
        event_type = "sell"
    else:
        event_type = "swap"
    return event_type, {
        "type": event_type,
        "mintIn": leg_in.mint,
        "mintOut": leg_out.mint,
        "valueIn": leg_in.amount,
        "valueOut": leg_out.amount,
    }


# --------------------------------------------------------------------------- #
#  Builder
# --------------------------------------------------------------------------- #


class EventBuilder:
    """Assembles payloads for one transaction across every tracked wallet."""

    def __init__(self, store: Store, oracle: PriceOracle, tracker: PositionTracker) -> None:
        self._store = store
        self._oracle = oracle
        self._tracker = tracker

    async def build(
        self,
        view: TxView,
        tracked: Iterable[str],
        names: Mapping[str, str | None] | None = None,
    ) -> list[dict[str, Any]]:
        """One payload per tracked wallet that the transaction touches."""
        tracked = {a for a in tracked}
        participants = sorted(tracked & (view.tokens.keys() | view.lamports.keys()))
        if not participants:
            return []

        names = dict(names or {})
        intents, transfers = analyse(view, frozenset(participants))
        fees = extract_fees(view)

        payloads: list[dict[str, Any]] = []
        for wallet in participants:
            deltas = view.deltas(wallet)
            if not deltas:
                continue
            incoming = [d for d in deltas if d.raw_delta > 0]
            outgoing = [d for d in deltas if d.raw_delta < 0]
            intent = _pick_intent(intents, wallet, incoming, outgoing)
            event_type, detail = classify(deltas, intent, transfers)

            # Enrich with prices before rendering.
            mints = {d.mint for d in deltas}
            if detail.get("mintIn"):
                mints.add(detail["mintIn"])
            if detail.get("mintOut"):
                mints.add(detail["mintOut"])
            tokens = await self._oracle.get_many(mints)

            payload = await self._render(
                view=view,
                wallet=wallet,
                name=names.get(wallet),
                deltas=deltas,
                event_type=event_type,
                detail=detail,
                tokens=tokens,
                fees=fees,
                intent=intent,
            )
            payloads.append(payload)
        return payloads

    async def _render(
        self,
        view: TxView,
        wallet: str,
        name: str | None,
        deltas: Sequence[BalanceDelta],
        event_type: str,
        detail: dict[str, Any],
        tokens: Mapping[str, TokenInfo],
        fees: dict[str, float],
        intent: TradeIntent | None,
    ) -> dict[str, Any]:
        # For a two-sided trade the transaction itself fixes the price the traded token
        # changed hands at, and that is what the payload should report: the fetched
        # spot price is "now", which for a historical transaction would make the
        # two sides of one swap disagree by whatever the market did since.
        # Only the traded token takes that price — applying it to every leg would
        # price a 2.4 SOL leg at a memecoin's unit price and report it as ~$0.
        trade_price = self._trade_price(deltas, tokens)
        traded_mint = self._traded_mint(deltas, tokens, trade_price)

        token_changes: list[dict[str, Any]] = []
        for delta in deltas:
            if trade_price is not None and delta.mint == traded_mint:
                price = trade_price
            else:
                price = self._price_for(delta, deltas, tokens)
            token_changes.append(
                {
                    "address": wallet,
                    "direction": delta.direction,
                    "mint": delta.mint,
                    "amount_raw": str(delta.raw_delta),
                    "amount": delta.amount,
                    "price_usd": price,
                    "value_usd": round(delta.amount * price, 8),
                }
            )

        position = None
        if event_type in ("buy", "sell"):
            position = await self._position_block(
                wallet=wallet,
                deltas=deltas,
                event_type=event_type,
                detail=detail,
                tokens=tokens,
            )

        sol_after = view.sol_after(wallet)
        token_rows = {
            mint: info.to_payload()
            for mint, info in tokens.items()
            if any(d.mint == mint for d in deltas) or mint in (detail.get("mintIn"), detail.get("mintOut"))
        }

        source = intent.source if intent else self._infer_source(view)
        payload: dict[str, Any] = {
            "id": view.signature,
            "event_type": event_type,
            "timestamp": _iso(view.block_time),
            "chain": CHAIN,
            "failed": view.failed,
            "source": source,
            "fee_payer": view.fee_payer,
            "followed_wallets": [
                {
                    "address": wallet,
                    "wallet_name": name,
                    "funded_at": await self._funded_at(wallet),
                    "sol_balance": None if sol_after is None else sol_after / LAMPORTS_PER_SOL,
                }
            ],
            "token_changes": token_changes,
            "tokens": token_rows,
            "fees": fees,
        }
        if position is not None:
            payload["position"] = position
        if detail:
            payload["event"] = detail
        if view.error:
            payload["error"] = view.error
        return payload

    @staticmethod
    def _traded_mint(
        deltas: Sequence[BalanceDelta],
        tokens: Mapping[str, TokenInfo],
        trade_price: float | None,
    ) -> str | None:
        """The mint :meth:`_trade_price` priced.

        Both legs of a swap are the same trade, but only one of them is *the*
        token; the other is what was paid. Re-deriving it here (rather than
        returning it alongside the price) keeps both helpers independently
        testable.
        """
        if trade_price is None:
            return None

        def priced(leg: BalanceDelta) -> float:
            info = tokens.get(leg.mint)
            return abs(leg.amount) * float(info.price_usd if info else 0.0)

        traded = [d for d in deltas if d.mint not in QUOTE_MINTS and abs(d.amount) > 0]
        if not traded:
            return None

        def score(base: BalanceDelta) -> tuple[int, float]:
            others = [d for d in deltas if d.mint != base.mint]
            paid_by_token = [d for d in others if d.mint not in QUOTE_MINTS]
            counterpart = paid_by_token or [d for d in others if d.mint in QUOTE_MINTS]
            value = max((priced(d) for d in counterpart), default=0.0)
            if value <= 0:
                return (0, 0.0)
            return (2 if paid_by_token else 1, value)

        ranked = sorted(
            ((score(base), base) for base in traded), key=lambda pair: pair[0], reverse=True
        )
        (quality, _value), base = ranked[0]
        return base.mint if quality else None

    @staticmethod
    def _trade_price(
        deltas: Sequence[BalanceDelta],
        tokens: Mapping[str, TokenInfo],
    ) -> float | None:
        """Price the trade actually executed at, if a leg of it is priced.

        Any two opposite legs imply the same price per unit of the non-quote
        asset, so one price covers the whole movement and both sides of the swap
        agree. Returns ``None`` when nothing usable is priced, leaving the caller
        to fall back to per-leg pricing.
        """
        incoming = [d for d in deltas if d.raw_delta > 0]
        outgoing = [d for d in deltas if d.raw_delta < 0]
        if not incoming or not outgoing:
            return None

        def priced(leg: BalanceDelta) -> float:
            info = tokens.get(leg.mint)
            return abs(leg.amount) * float(info.price_usd if info else 0.0)

        # The traded token is a non-quote leg, and the asset that paid for it is
        # another leg of the same movement. Scoring the candidates matters: raw
        # amounts are not comparable across tokens with different decimals, so
        # "largest delta wins" would happily price SOL in terms of a memecoin.
        traded = [d for d in deltas if d.mint not in QUOTE_MINTS and abs(d.amount) > 0]
        if not traded:
            return None

        def score(base: BalanceDelta) -> tuple[int, float]:
            others = [d for d in deltas if d.mint != base.mint]
            paid_by_token = [d for d in others if d.mint not in QUOTE_MINTS]
            counterpart = paid_by_token or [d for d in others if d.mint in QUOTE_MINTS]
            value = max((priced(d) for d in counterpart), default=0.0)
            if value <= 0:
                return (0, 0.0)
            # A token-for-token leg beats a quote leg: the fee tail cannot be
            # mistaken for the payment.
            return (2 if paid_by_token else 1, value)

        ranked = sorted(
            ((score(base), base) for base in traded), key=lambda pair: pair[0], reverse=True
        )
        (quality, value), base = ranked[0]
        if quality == 0:
            return None

        base_amount = abs(base.amount)
        if not base_amount:
            return None
        price = value / base_amount
        return price if 1e-12 <= price <= 1e12 else None

    @staticmethod
    def _price_for(
        delta: BalanceDelta,
        deltas: Sequence[BalanceDelta],
        tokens: Mapping[str, TokenInfo],
    ) -> float:
        """USD price for one leg of a movement.

        Preference order: the fetched price, then — for a trade whose other leg
        does have a price — the implied price of the traded token. An unpriced leg
        next to a priced one is almost always a brand-new token, and dividing the
        known value by the unknown amount recovers its launch price, which is
        exactly the number a wallet tracker is looking at.
        """
        info = tokens.get(delta.mint)
        price = float(info.price_usd) if info else 0.0
        if price > 0 or delta.raw_delta == 0:
            return price

        amount = abs(delta.amount)
        if not amount:
            return 0.0
        for other in deltas:
            if other.mint == delta.mint or other.raw_delta == 0:
                continue
            other_price = float(getattr(tokens.get(other.mint), "price_usd", 0.0) or 0.0)
            if other_price <= 0:
                continue
            other_value = abs(other.amount) * other_price
            if other_value <= 0:
                continue
            implied = other_value / amount
            # Sanity band: a derived price off by orders of magnitude means the
            # legs are not a trade (e.g. rent plus a fee), so keep the zero.
            if 1e-12 <= implied <= 1e12:
                return implied
        return 0.0

    async def _position_block(
        self,
        wallet: str,
        deltas: Sequence[BalanceDelta],
        event_type: str,
        detail: Mapping[str, Any],
        tokens: Mapping[str, TokenInfo],
    ) -> dict[str, Any] | None:
        """Update the position and render its ``position`` block.

        The traded token is the leg that arrived; the leg that left pays for it.
        That counter-leg is not always SOL — a route can pay in another token — so
        it is taken from the observed movement, preferring a recognised quote mint
        when several legs left at once.
        """
        incoming = [d for d in deltas if d.raw_delta > 0]
        outgoing = [d for d in deltas if d.raw_delta < 0]
        if not incoming or not outgoing:
            return None

        base = self._pick_base_leg(incoming, outgoing, detail)
        quote = self._pick_quote_leg(outgoing, base, tokens)
        if quote is None:
            return None

        mint = base.mint
        info = tokens.get(mint)
        decimals = int(info.decimals) if info and info.decimals else base.decimals
        if not decimals:
            decimals = 6
        price = float(info.price_usd) if info else 0.0

        quote_info = tokens.get(quote.mint)
        quote_decimals = int(quote_info.decimals) if quote_info and quote_info.decimals else quote.decimals

        snapshot = await self._tracker.apply(
            wallet=wallet,
            mint=mint,
            quote_mint=quote.mint,
            decimals=decimals,
            quantity_raw=base.raw_delta,
            quote_raw=quote.raw_delta,
            side=event_type,
            quote_decimals=quote_decimals,
        )
        current_price = self._current_price(price, snapshot.average_cost_basis)
        return snapshot.to_payload(event_type, current_price)

    @staticmethod
    def _pick_base_leg(
        incoming: Sequence[BalanceDelta],
        outgoing: Sequence[BalanceDelta],
        detail: Mapping[str, Any],
    ) -> BalanceDelta:
        """The token that arrived — the subject of a buy.

        SOL arriving alongside another token is a withdrawal or a refund, not a
        purchase, so the native leg is only accepted when nothing else came in.
        """
        out_mints = {d.mint for d in outgoing}
        hint = detail.get("mintOut") or detail.get("mintIn")
        if hint:
            for delta in incoming:
                if delta.mint == hint:
                    return delta
        non_quote = [d for d in incoming if d.mint not in QUOTE_MINTS]
        for delta in non_quote:
            if delta.mint not in out_mints:
                return delta
        # Every incoming leg is also leaving: a wrap or a self-trade. Take the
        # largest, and ignore the native leg which is usually just a fee.
        return max((d for d in incoming if d.mint not in QUOTE_MINTS), key=lambda d: abs(d.raw_delta), default=incoming[0])

    @classmethod
    def _pick_quote_leg(
        cls,
        outgoing: Sequence[BalanceDelta],
        base: BalanceDelta,
        tokens: Mapping[str, TokenInfo],
    ) -> BalanceDelta | None:
        """The asset that actually paid for the trade.

        A buy almost always shows a small SOL outflow next to the real payment —
        that is the network fee, not the consideration. The native leg is only
        taken as the quote when it is not dust beside the other outgoing legs,
        which stops a token-for-token buy from being booked at its fee amount.
        """
        candidates = [d for d in outgoing if d.mint != base.mint]
        if not candidates:
            return None

        native = next((d for d in candidates if d.mint in QUOTE_MINTS), None)
        others = [d for d in candidates if d.mint not in QUOTE_MINTS]
        if not others:
            return native
        if native is None:
            return max(others, key=lambda d: abs(d.raw_delta))

        def value(delta: BalanceDelta) -> float:
            info = tokens.get(delta.mint)
            price = float(info.price_usd) if info else 0.0
            return abs(delta.amount) * price

        largest_other = max(value(d) for d in others)
        if value(native) >= largest_other * _FEE_DUST_RATIO:
            return native
        return max(others, key=lambda d: abs(d.raw_delta))

    @staticmethod
    def _current_price(usd_price: float, average: float | None) -> float | None:
        """Prefer the venue's own quote; fall back to the USD price.

        Position figures are denominated in the quote asset, so a token with no
        usable USD price still gets a coherent ``current_price`` from its basis.
        """
        if average is not None:
            return average
        return usd_price or None

    async def _funded_at(self, wallet: str) -> str | None:
        for row in await self._store.all_wallets():
            if row.address == wallet:
                return row.funded_at
        return None

    @staticmethod
    def _infer_source(view: TxView) -> str:
        """Fall back to the most specific program in the transaction."""
        from .ids import DEX_PROGRAMS

        best = "solana program library"
        for ix in normalise_instructions(view.raw):
            program = ix.program_id
            if program in DEX_PROGRAMS and program not in ROUTER_PROGRAMS:
                return source_for(program)
            if program in (
                SYSTEM_PROGRAM,
                TOKEN_PROGRAM,
                TOKEN_2022_PROGRAM,
                ASSOCIATED_TOKEN_PROGRAM,
            ):
                best = source_for(program)
        return best


__all__ = ["CHAIN", "EVENT_TYPES", "EventBuilder", "classify", "extract_fees"]