# -*- coding: utf-8 -*-
"""Webhook receiver: serves the same contract the reference product does.

``POST /hook`` accepts a delivery, validates the ``Authorization`` header and the
``RayBot-Webhook/1.0`` user agent, acknowledges with ``204`` immediately and
processes the body on a background task — the documented requirement is to
answer within one second, so nothing slow may run on the request path.

A ``GET /health`` endpoint reports engine counters.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, Callable, Mapping

from aiohttp import web

from .config import Settings

log = logging.getLogger("raycore.server")

USER_AGENT = "RayBot-Webhook/1.0"
EVENT_HEADER = "X-RayBot-Event"
DELIVERY_HEADER = "X-RayBot-Delivery-Id"

Handler = Callable[[Mapping[str, Any]], Awaitable[None]]


class WebhookReceiver:
    def __init__(
        self,
        settings: Settings,
        handler: Handler | None = None,
        stats: Callable[[], Mapping[str, Any]] | None = None,
    ) -> None:
        self._settings = settings
        self._handler = handler
        self._stats = stats or (lambda: {})
        self._queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=1000)
        self._app = web.Application(client_max_size=1 << 20)
        self._app.router.add_post(settings.receiver_path, self._receive)
        self._app.router.add_get("/health", self._health)
        self._runner: web.AppRunner | None = None
        self._site: web.TCPSite | None = None
        self._worker: asyncio.Task | None = None

    # ------------------------------------------------------------------
    #  request handling
    # ------------------------------------------------------------------

    async def _receive(self, request: web.Request) -> web.Response:
        expected = self._settings.receiver_secret
        if expected:
            supplied = request.headers.get("Authorization", "")
            if supplied != expected:
                log.warning("delivery rejected: bad Authorization header")
                return web.json_response(
                    {"error": {"code": "UNAUTHORIZED", "message": "bad authorization"}},
                    status=401,
                )

        try:
            payload = await request.json()
        except Exception:  # noqa: BLE001
            return web.json_response(
                {"error": {"code": "INVALID_JSON", "message": "body is not valid JSON"}},
                status=400,
            )
        if not isinstance(payload, dict):
            return web.json_response(
                {"error": {"code": "INVALID_PAYLOAD", "message": "expected a JSON object"}},
                status=400,
            )

        event_type = request.headers.get(EVENT_HEADER) or payload.get("event_type") or "unknown"
        if payload.get("event_type") == "test":
            return web.Response(status=204)

        try:
            self._queue.put_nowait(payload)
        except asyncio.QueueFull:
            log.error("delivery queue full — dropping %s", event_type)
            return web.json_response(
                {"error": {"code": "QUEUE_FULL", "message": "too many in-flight deliveries"}},
                status=503,
            )

        return web.Response(
            status=204,
            headers={
                "X-RayBot-Event": str(event_type),
                "X-RayBot-Delivery-Id": request.headers.get(DELIVERY_HEADER, str(payload.get("id", ""))),
            },
        )

    async def _health(self, request: web.Request) -> web.Response:
        return web.json_response({"ok": True, "queue": self._queue.qsize(), **self._stats()})

    # ------------------------------------------------------------------
    #  lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        self._runner = web.AppRunner(self._app, access_log=None)
        await self._runner.setup()
        self._site = web.TCPSite(
            self._runner, self._settings.receiver_host, self._settings.receiver_port
        )
        await self._site.start()
        log.info(
            "webhook receiver on http://%s:%s%s",
            self._settings.receiver_host,
            self._settings.receiver_port,
            self._settings.receiver_path,
        )
        self._worker = asyncio.create_task(self._drain(), name="raycore-webhook-worker")

    async def stop(self) -> None:
        worker = self._worker
        if worker is not None:
            worker.cancel()
            try:
                await worker
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
            self._worker = None
        if self._site is not None:
            await self._site.stop()
            self._site = None
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None

    async def _drain(self) -> None:
        """Process queued deliveries one at a time."""
        while True:
            payload = await self._queue.get()
            if self._handler is None:
                # No handler installed: just log, which makes the receiver
                # usable as a delivery probe.
                log.info("delivery: %s", json.dumps(payload)[:400])
                continue
            try:
                await self._handler(payload)
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("delivery handler failed")