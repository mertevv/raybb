# -*- coding: utf-8 -*-
"""Composite signals: several wallets buying one token, or one wallet scaling in.

Both detectors read the same ``buys`` table the engine writes, so they work for
events that arrived minutes apart as well as ones in the same transaction.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Mapping

from .store import Store

log = logging.getLogger("raycore.signals")


@dataclass(slots=True)
class SignalConfig:
    multi_buy_enabled: bool = True
    multi_buy_wallets: int = 2
    multi_buy_window: float = 60.0
    accumulation_enabled: bool = True
    accumulation_buys: int = 3
    accumulation_window: float = 3600.0

    @classmethod
    def from_settings(cls, settings) -> "SignalConfig":
        return cls(
            multi_buy_enabled=settings.multi_buy_enabled,
            multi_buy_wallets=max(settings.multi_buy_wallets, 2),
            multi_buy_window=settings.multi_buy_window,
            accumulation_enabled=settings.accumulation_enabled,
            accumulation_buys=max(settings.accumulation_buys, 2),
            accumulation_window=settings.accumulation_window,
        )


def _base_mint(payload: Mapping[str, Any]) -> str | None:
    from .ids import QUOTE_MINTS

    for change in payload.get("token_changes") or []:
        mint = change.get("mint")
        if mint and mint not in QUOTE_MINTS and change.get("direction") == "in":
            return mint
    return None


def _wallet(payload: Mapping[str, Any]) -> str | None:
    wallets = payload.get("followed_wallets") or []
    return wallets[0].get("address") if wallets else None


def _value_usd(payload: Mapping[str, Any]) -> float:
    values = [float(c.get("value_usd") or 0.0) for c in payload.get("token_changes") or []]
    return max(values) if values else 0.0


def _token_row(payload: Mapping[str, Any], mint: str) -> dict[str, Any]:
    return (payload.get("tokens") or {}).get(mint) or {}


async def record_buy(store: Store, payload: Mapping[str, Any]) -> str | None:
    """Persist a buy so the signal detectors can see it. Returns the mint."""
    if payload.get("event_type") != "buy" or payload.get("failed"):
        return None
    mint = _base_mint(payload)
    wallet = _wallet(payload)
    if not mint or not wallet:
        return None
    await store.record_buy(wallet, mint, payload.get("id", ""), _value_usd(payload))
    return mint


async def detect(store: Store, payload: Mapping[str, Any], cfg: SignalConfig) -> list[dict[str, Any]]:
    """Return any signal payloads triggered by *payload*."""
    out: list[dict[str, Any]] = []
    if payload.get("event_type") != "buy" or payload.get("failed"):
        return out
    mint = _base_mint(payload)
    if not mint:
        return out

    if cfg.multi_buy_enabled:
        signal = await _multi_buy(store, payload, mint, cfg)
        if signal:
            out.append(signal)

    if cfg.accumulation_enabled:
        signal = await _accumulation(store, payload, mint, cfg)
        if signal:
            out.append(signal)

    return out


async def _multi_buy(
    store: Store, payload: Mapping[str, Any], mint: str, cfg: SignalConfig
) -> dict[str, Any] | None:
    now = time.time()
    window = now - cfg.multi_buy_window
    buys = await store.recent_buys(mint, window)
    distinct = {wallet for wallet, ts, _v in buys if wallet != _wallet(payload)}
    if len(distinct) + 1 < cfg.multi_buy_wallets:
        return None

    participants = [
        {
            "address": wallet,
            "wallet_name": ((payload.get("followed_wallets") or [{}])[0].get("wallet_name")),
            "bought_at": _iso(ts),
            "value_usd": round(value, 8),
        }
        for wallet, ts, value in buys
    ]
    return {
        "id": payload.get("id"),
        "event_type": "multi_buy",
        "timestamp": _iso(now),
        "chain": payload.get("chain", "solana"),
        "failed": False,
        "source": payload.get("source"),
        "fee_payer": payload.get("fee_payer"),
        "followed_wallets": payload.get("followed_wallets"),
        "token_changes": payload.get("token_changes"),
        "tokens": payload.get("tokens"),
        "position": payload.get("position"),
        "fees": payload.get("fees"),
        "event": payload.get("event"),
        "multi_buy": {
            "mint": mint,
            "token": _token_row(payload, mint),
            "wallet_count": len({wallet for wallet, _ts, _v in buys}),
            "window_seconds": cfg.multi_buy_window,
            "total_value_usd": round(sum(v for _w, _ts, v in buys), 8),
            "wallets": participants,
        },
    }


async def _accumulation(
    store: Store, payload: Mapping[str, Any], mint: str, cfg: SignalConfig
) -> dict[str, Any] | None:
    wallet = _wallet(payload)
    now = time.time()
    window = now - cfg.accumulation_window
    buys = [b for b in await store.recent_buys(mint, window) if b[0] == wallet]
    if len(buys) < cfg.accumulation_buys:
        return None

    return {
        "id": payload.get("id"),
        "event_type": "accumulation",
        "timestamp": _iso(now),
        "chain": payload.get("chain", "solana"),
        "failed": False,
        "source": payload.get("source"),
        "fee_payer": payload.get("fee_payer"),
        "followed_wallets": payload.get("followed_wallets"),
        "token_changes": payload.get("token_changes"),
        "tokens": payload.get("tokens"),
        "position": payload.get("position"),
        "fees": payload.get("fees"),
        "event": payload.get("event"),
        "accumulation": {
            "mint": mint,
            "token": _token_row(payload, mint),
            "buy_count": len(buys),
            "window_seconds": cfg.accumulation_window,
            "total_value_usd": round(sum(v for _w, _ts, v in buys), 8),
            "total_invested_quote": payload.get("position", {}).get("total_invested"),
            "first_buy_at": _iso(buys[0][1]),
            "last_buy_at": _iso(buys[-1][1]),
        },
    }


def _iso(ts: float) -> str:
    from datetime import datetime, timezone

    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat(timespec="milliseconds").replace(
        "+00:00", "Z"
    )