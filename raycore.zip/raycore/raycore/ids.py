# -*- coding: utf-8 -*-
"""Program identifiers, Anchor helpers and well-known mint metadata.

Anchor discriminators are *computed*, never hard-coded: an instruction tagged
``global:sell`` has discriminator ``sha256(b"global:sell")[:8]``. Computing them
at import time means there are no magic bytes to mistype, and a program that
renames an instruction simply stops matching instead of silently mis-decoding.

Some programs (Meteora DLMM among them) use hand-assigned discriminators instead
of Anchor's hashing; those live in :data:`EXPLICIT_DISCRIMINATORS` and were taken
from live mainnet traffic, not from guesswork.
"""

from __future__ import annotations

import hashlib
from typing import Dict, Iterable

# --------------------------------------------------------------------------- #
#  Programs
# --------------------------------------------------------------------------- #

SYSTEM_PROGRAM = "11111111111111111111111111111111"
COMPUTE_BUDGET = "ComputeBudget111111111111111111111111111111"
TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
TOKEN_2022_PROGRAM = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
ASSOCIATED_TOKEN_PROGRAM = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"
JITO_TIP_PROGRAM = "96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5"
MEMO_PROGRAM = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr"

DEX_PROGRAMS: Dict[str, str] = {
    # pump.fun bonding curve, its successor program, and the PumpSwap AMM
    "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P": "pumpfun",
    "5kZmvKbaqNjSNEnQKEREEKu5r9JkaDRKrQMUvZagCMoz": "pumpfun",
    "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA": "pumpswap",
    # Raydium
    "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8": "raydium",
    "5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j": "raydium",
    "CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK": "raydium",
    "routeUGWgWzqBWFcrCfv8tritsqukccJPu3q5GPP3xS": "jupiter",
    # Meteora
    "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo": "meteora",
    "dbcij3LWUppWqq96dh6gJWwBifmcGfLSB5D4Du3AQGU6": "meteora",
    "Eo7WjKq67rjJQSZxS6z3YkapzY3eMj6Xy8X5EQVn5UaB": "meteora",
    # Orca
    "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc": "orca",
    "9W959DqEETiGZocYWCQPaJ6sBmUzgfxXfqGeTEdp3aQP": "orca",
    "DjVE6JNiYqPL2QXyCUUh8rNjHrbz9hXHNYt99MQ59qw1": "orca",
    # Jupiter
    "JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4": "jupiter",
    "JUP4Fb2cqiRUcaTNcLLudY6j1coNBbQ9jkH7QAaVeE": "jupiter",
    "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN": "jupiter",
    # other venues
    "srmqPvymJeFKQ4zGQed1GFppgkRHL9kaELCbyksJtPX": "srm",
    "obriQD1zbpyLz95G5n7NJe6a445DPgAJ8YrimBURa": "openbook",
    "opnb2LAfJYbRMAHHvqjCwQxanZn7ReEHp1k81EohpZb": "openbook",
    "MERLuDFBMmsHnsBPZw2sDQZHvXFMwp8EdjudcU2HKky": "mercurial",
    "H8W3ctz92svYg6mkn1UtGfu2aQr2fnUFHM1RhScEtQDt": "lifinity",
    "2wT8Yq49kHgDzXuPxZSaeLaH1qbmGXtEyPy64bL7aD3c": "lifinity",
    "7YttLkHDoNjQwyarcYb95v6DhLtsDjeHVvKVtmvc2qgX": "cropper",
    "BSwp6bEBihVLdqJRKGgzjcGLHkcTuzmSo1TQkHepzH8p": "cropper",
}

#: Programs that route a trade on behalf of a user. When one of these appears we
#: keep looking for the venue that actually executed the fill.
ROUTER_PROGRAMS = frozenset(
    {
        "JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4",
        "JUP4Fb2cqiRUcaTNcLLudY6j1coNBbQ9jkH7QAaVeE",
        "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN",
        "routeUGWgWzqBWFcrCfv8tritsqukccJPu3q5GPP3xS",
    }
)

#: Human labels used for the ``source`` field of the emitted payload.
SOURCE_LABELS: Dict[str, str] = {
    "pumpfun": "pumpfun",
    "pumpswap": "pumpfun",
    "raydium": "raydium",
    "meteora": "meteora",
    "orca": "orca",
    "jupiter": "jupiter",
    "srm": "srm",
    "openbook": "openbook",
    "mercurial": "mercurial",
    "lifinity": "lifinity",
    "cropper": "cropper",
    SYSTEM_PROGRAM: "system program",
    TOKEN_PROGRAM: "solana program library",
    TOKEN_2022_PROGRAM: "solana program library",
    ASSOCIATED_TOKEN_PROGRAM: "associated token account",
}

# --------------------------------------------------------------------------- #
#  Mints
# --------------------------------------------------------------------------- #

WSOL = "So11111111111111111111111111111111111111112"
USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
USDT = "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"

#: Mints treated as "quote" currency when deciding whether a swap is a buy or a sell.
QUOTE_MINTS = frozenset({WSOL, USDC, USDT})

#: Stable fallback metadata for the majors, used when the price API has nothing.
STATIC_TOKENS: Dict[str, dict] = {
    WSOL: {
        "symbol": "SOL",
        "name": "Wrapped SOL",
        "decimals": 9,
        "supply": 0,
        "created": None,
        "image": None,
        "socials": {"twitter": None, "telegram": None, "website": None},
    },
    USDC: {
        "symbol": "USDC",
        "name": "USD Coin",
        "decimals": 6,
        "supply": 0,
        "created": None,
        "image": None,
        "socials": {"twitter": None, "telegram": None, "website": None},
    },
    USDT: {
        "symbol": "USDT",
        "name": "USDT",
        "decimals": 6,
        "supply": 0,
        "created": None,
        "image": None,
        "socials": {"twitter": None, "telegram": None, "website": None},
    },
}

# --------------------------------------------------------------------------- #
#  Anchor discriminators
# --------------------------------------------------------------------------- #

#: Anchor 0.30 emits events through a self-CPI; every event-carrying instruction
#: payload starts with this constant, and the real event discriminator follows.
ANCHOR_EVENT_PREFIX = "e445a52e51cb9a1d"

#: Explicit discriminators observed on mainnet for programs that do not use
#: Anchor's ``sha256("global:<name>")`` hashing.
EXPLICIT_DISCRIMINATORS: Dict[str, Dict[str, str]] = {
    "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo": {
        "cc02c391359191cd": "initialize_position",
        "70bf65ab1c907fbb": "add_liquidity",
        "3b7cd4765b986e9d": "claim_fee",
        "235613b94ed44bd3": "get_bin_ids",
    },
}


def explicit_disc(program_id: str, name: str) -> str | None:
    """Look up a hand-assigned discriminator by name, or ``None`` if absent."""
    for disc, label in EXPLICIT_DISCRIMINATORS.get(program_id, {}).items():
        if label == name:
            return disc
    return None


def anchor_discriminator(namespace: str, name: str) -> str:
    """``sha256(b"<namespace>:<name>")[:8]`` as lowercase hex."""
    return hashlib.sha256(f"{namespace}:{name}".encode()).digest()[:8].hex()


def anchor_ix(name: str) -> str:
    """Discriminator of an Anchor *instruction* named *name* (``global:`` namespace)."""
    return anchor_discriminator("global", name)


def anchor_event(name: str) -> str:
    """Discriminator of an Anchor *event* named *name* (``event:`` namespace)."""
    return anchor_discriminator("event", name)


#: Instruction names we resolve through Anchor hashing, per program.
ANCHOR_INSTRUCTIONS: Dict[str, Dict[str, str]] = {
    "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P": {
        "buy": "buy",
        "sell": "sell",
        "migrate": "migrate",
    },
    "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA": {
        "buy_exact_quote_in": "buy_exact_quote_in",
        "buy_exact_base_in": "buy_exact_base_in",
        "sell_exact_token_in": "sell_exact_token_in",
        "buy": "buy",
        "sell": "sell",
    },
    "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo": {
        "swap": "swap",
        "swap2": "swap2",
        "rebalance_liquidity": "rebalance_liquidity",
    },
}

#: Anchor events we understand, mapped to a canonical name.
ANCHOR_EVENTS: Dict[str, str] = {
    anchor_event("TradeEvent"): "trade",
    anchor_event("CompleteEvent"): "complete",
    anchor_event("BondingCurveComplete"): "complete",
    anchor_event("CompletePumpAmmMigration"): "complete",
    anchor_event("CreatorFeeSharing"): "creator_fee_sharing",
}


def source_for(program_id: str | None) -> str:
    """Label for the ``source`` field of an event payload."""
    if not program_id:
        return "solana"
    return SOURCE_LABELS.get(program_id) or DEX_PROGRAMS.get(program_id) or program_id


def is_dex_program(program_id: str | None) -> bool:
    return bool(program_id) and program_id in DEX_PROGRAMS


def iter_program_ids() -> Iterable[str]:
    return DEX_PROGRAMS.keys()