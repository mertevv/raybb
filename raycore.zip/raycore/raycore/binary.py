# -*- coding: utf-8 -*-
"""A tiny bounded reader for little-endian Solana instruction payloads.

Every read is bounds-checked and raises :class:`DecodeError`, so a layout that
drifts upstream degrades into "this decoder returned nothing" instead of
producing garbage amounts.
"""

from __future__ import annotations

import struct

from .b58 import b58encode


class DecodeError(ValueError):
    """Raised when a payload does not match the expected layout."""


class Reader:
    """Sequential little-endian reader over a byte string."""

    __slots__ = ("buf", "pos")

    def __init__(self, buf: bytes, pos: int = 0) -> None:
        self.buf = buf
        self.pos = pos

    # -- introspection ---------------------------------------------------

    def remaining(self) -> int:
        return len(self.buf) - self.pos

    def eof(self) -> bool:
        return self.pos >= len(self.buf)

    def at(self, offset: int) -> bytes:
        return self.buf[offset : offset + 32]

    # -- primitives ------------------------------------------------------

    def _take(self, n: int) -> bytes:
        end = self.pos + n
        if end > len(self.buf):
            raise DecodeError(
                f"payload too short: need {n} bytes at offset {self.pos}, have {self.remaining()}"
            )
        chunk = self.buf[self.pos : end]
        self.pos = end
        return chunk

    def skip(self, n: int) -> "Reader":
        self._take(n)
        return self

    def u8(self) -> int:
        return self._take(1)[0]

    def i8(self) -> int:
        return struct.unpack("<b", self._take(1))[0]

    def bool_(self) -> bool:
        return self._take(1)[0] != 0

    def u16(self) -> int:
        return struct.unpack("<H", self._take(2))[0]

    def i16(self) -> int:
        return struct.unpack("<h", self._take(2))[0]

    def u32(self) -> int:
        return struct.unpack("<I", self._take(4))[0]

    def i32(self) -> int:
        return struct.unpack("<i", self._take(4))[0]

    def u64(self) -> int:
        return struct.unpack("<Q", self._take(8))[0]

    def i64(self) -> int:
        return struct.unpack("<q", self._take(8))[0]

    def u128(self) -> int:
        return int.from_bytes(self._take(16), "little")

    def pubkey(self) -> str:
        return b58encode(self._take(32))

    def borsh_string(self) -> str:
        length = self.u32()
        if length > 4096:
            raise DecodeError(f"implausible borsh string length {length}")
        return self._take(length).decode("utf-8", "replace")

    def raw(self, n: int) -> bytes:
        return self._take(n)

    def rest(self) -> bytes:
        chunk = self.buf[self.pos :]
        self.pos = len(self.buf)
        return chunk


def u64_at(buf: bytes, offset: int) -> int:
    """Read a little-endian u64 at *offset*, raising on out-of-range access."""
    if offset + 8 > len(buf):
        raise DecodeError(f"u64 at {offset} out of range (len={len(buf)})")
    return struct.unpack_from("<Q", buf, offset)[0]


def i32_at(buf: bytes, offset: int) -> int:
    if offset + 4 > len(buf):
        raise DecodeError(f"i32 at {offset} out of range (len={len(buf)})")
    return struct.unpack_from("<i", buf, offset)[0]


def u16_at(buf: bytes, offset: int) -> int:
    if offset + 2 > len(buf):
        raise DecodeError(f"u16 at {offset} out of range (len={len(buf)})")
    return struct.unpack_from("<H", buf, offset)[0]