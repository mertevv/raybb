# -*- coding: utf-8 -*-
"""Per-(wallet, token) position tracking with average cost basis.

Denominated in the **quote asset actually used** — SOL for pump.fun trades,
USDC for a stablecoin pair — matching how the reference payload reports
``total_invested`` / ``realized_pnl``.

Accounting rules:

* a buy increases quantity and blends into the average cost basis;
* a sell realises PnL against that basis pro-rata and never lets it go negative;
* closing the position zeroes quantity and drops the average cost basis.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from .ids import STATIC_TOKENS, USDC, USDT, WSOL
from .store import Store

QUOTE_DECIMALS = {WSOL: 9, USDC: 6, USDT: 6}


@dataclass(slots=True)
class PositionSnapshot:
    wallet: str
    mint: str
    quote_mint: str
    quantity: float
    average_cost_basis: float | None
    total_invested: float
    realized_pnl: float
    is_new: bool
    is_closed: bool

    def to_payload(self, side: str, current_price: float | None) -> dict[str, Any]:
        """Render the ``position`` block of an event payload."""
        unrealized: float | None = None
        if not self.is_closed and self.average_cost_basis is not None and current_price is not None:
            unrealized = round(self.quantity * current_price - self.total_invested, 12)
        return {
            "side": side,
            "is_new_position": self.is_new,
            "is_closed": self.is_closed,
            "total_quantity": self.quantity,
            "average_cost_basis": None if self.is_closed else self.average_cost_basis,
            "current_price": current_price,
            "total_invested": self.total_invested,
            "realized_pnl": self.realized_pnl,
            "unrealized_pnl": None if self.is_closed else unrealized,
        }


class PositionTracker:
    """Reads and writes position rows in the store."""

    def __init__(self, store: Store) -> None:
        self._store = store

    async def apply(
        self,
        wallet: str,
        mint: str,
        quote_mint: str,
        decimals: int,
        quantity_raw: int,
        quote_raw: int,
        side: str,
        quote_decimals: int | None = None,
    ) -> PositionSnapshot:
        """Fold one fill into the stored position and return the resulting state.

        ``quantity_raw`` is the token amount traded, ``quote_raw`` the amount of
        quote asset that moved the other way. Both are pre-decimalisation
        integers taken from real balance deltas, so ``quote_decimals`` (or the
        built-in table for SOL/USDC/USDT) is what turns them into display units.
        """
        if quote_decimals is None:
            quote_decimals = QUOTE_DECIMALS.get(quote_mint)
        row = await self._store.get_position(wallet, mint)
        held = int(row["quantity_raw"]) if row else 0
        basis_total = int(row["cost_basis_raw"]) if row else 0
        invested = float(row["total_invested"]) if row else 0.0
        realized = float(row["realized_pnl"]) if row else 0.0
        opened_at = float(row["opened_at"]) if row and row["opened_at"] else None

        was_empty = held == 0 and invested == 0.0
        quote_scale = 10 ** (quote_decimals or 0)
        quantity = abs(quantity_raw)
        quote_amount = abs(quote_raw) / quote_scale

        if side == "buy":
            basis_total += abs(quote_raw)
            invested += quote_amount
            held += quantity
            if opened_at is None:
                opened_at = time.time()
        else:
            sold = min(quantity, held) if held else quantity
            if held:
                # basis_total is in raw quote units; quote_amount is decimal, so
                # the released slice has to be converted before it is subtracted.
                released = basis_total * (sold / held)
                realized += quote_amount - (released / quote_scale)
                basis_total -= released
                held -= sold
            if held <= 0:
                held = 0
                basis_total = 0
                invested = 0.0
                opened_at = None

        token_scale = 10 ** (decimals if decimals else STATIC_TOKENS.get(mint, {}).get("decimals", 0))
        # Cost basis is tracked in raw quote units against raw token units, so the
        # average has to be rescaled to whole quote per whole token before it is
        # reported — otherwise raw-per-raw leaks out as the basis.
        average = ((basis_total / quote_scale) / (held / token_scale)) if (held and quote_scale) else None
        if held:
            await self._store.upsert_position(
                wallet=wallet,
                mint=mint,
                quote_mint=quote_mint,
                quantity_raw=held,
                cost_basis_raw=basis_total,
                total_invested=round(invested, 12),
                realized_pnl=round(realized, 12),
                opened_at=opened_at,
            )
        elif row is not None:
            await self._store.delete_position(wallet, mint)

        return PositionSnapshot(
            wallet=wallet,
            mint=mint,
            quote_mint=quote_mint,
            quantity=(held / token_scale) if token_scale else float(held),
            average_cost_basis=average,
            total_invested=round(invested, 12),
            realized_pnl=round(realized, 12),
            is_new=was_empty and side == "buy",
            is_closed=side == "sell" and held == 0,
        )

    async def holdings(self, wallet: str) -> list[dict[str, Any]]:
        return [row for row in await self._store.positions(wallet) if row["quantity_raw"]]