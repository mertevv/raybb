# -*- coding: utf-8 -*-
"""Package marker for raycore — a self-contained RayBot-compatible Solana engine."""

from __future__ import annotations

__version__ = "1.0.0"

__all__ = ["__version__"]