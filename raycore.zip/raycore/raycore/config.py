# -*- coding: utf-8 -*-
"""Configuration, read from environment variables / a .env file."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from dotenv import load_dotenv

load_dotenv()


def _int(name: str, default: int) -> int:
    raw = os.getenv(name, "")
    try:
        return int(raw) if raw.strip() else default
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    raw = os.getenv(name, "")
    try:
        return float(raw) if raw.strip() else default
    except ValueError:
        return default


def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name, "").strip().lower()
    if not raw:
        return default
    return raw in ("1", "true", "yes", "on")


def _str_list(name: str) -> tuple[str, ...]:
    raw = os.getenv(name, "").replace(";", ",")
    return tuple(chunk.strip() for chunk in raw.split(",") if chunk.strip())


@dataclass(frozen=True)
class Settings:
    # --- storage ---
    db_path: str = os.getenv("DB_PATH", "data/raycore.sqlite3").strip()

    # --- Solana RPC ---
    rpc_urls: tuple[str, ...] = field(
        default_factory=lambda: _str_list("RPC_URLS")
        or ("https://api.mainnet-beta.solana.com",)
    )
    rpc_concurrency: int = _int("RPC_CONCURRENCY", 4)
    rpc_timeout: float = _float("RPC_TIMEOUT", 30.0)
    rpc_retries: int = _int("RPC_RETRIES", 5)
    commitment: str = os.getenv("COMMITMENT", "confirmed").strip()

    # --- polling ---
    poll_interval: float = _float("POLL_INTERVAL", 12.0)
    signature_page: int = _int("SIGNATURE_PAGE", 1000)
    tx_batch_size: int = _int("TX_BATCH_SIZE", 10)
    backfill_limit: int = _int("BACKFILL_LIMIT", 0)
    seen_retention_hours: float = _float("SEEN_RETENTION_HOURS", 48.0)

    # --- pricing ---
    prices_enabled: bool = _bool("PRICES_ENABLED", True)
    price_ttl: float = _float("PRICE_TTL", 20.0)

    # --- filters ---
    event_types: tuple[str, ...] = field(default_factory=lambda: _str_list("EVENT_TYPES"))
    min_value_usd: float = _float("MIN_VALUE_USD", 0.0)
    min_sol_amount: float = _float("MIN_SOL_AMOUNT", 0.0)
    include_failed: bool = _bool("INCLUDE_FAILED", False)
    tracked_mints: tuple[str, ...] = field(default_factory=lambda: _str_list("TRACKED_MINTS"))
    block_mints: tuple[str, ...] = field(default_factory=lambda: _str_list("BLOCK_MINTS"))

    # --- signals ---
    multi_buy_enabled: bool = _bool("MULTI_BUY_ENABLED", True)
    multi_buy_wallets: int = _int("MULTI_BUY_WALLETS", 2)
    multi_buy_window: float = _float("MULTI_BUY_WINDOW", 60.0)

    accumulation_enabled: bool = _bool("ACCUMULATION_ENABLED", True)
    accumulation_buys: int = _int("ACCUMULATION_BUYS", 3)
    accumulation_window: float = _float("ACCUMULATION_WINDOW", 3600.0)

    # --- webhook receiver ---
    receiver_enabled: bool = _bool("RECEIVER_ENABLED", False)
    receiver_host: str = os.getenv("RECEIVER_HOST", "127.0.0.1").strip()
    receiver_port: int = _int("RECEIVER_PORT", 8787)
    receiver_secret: str = os.getenv("RECEIVER_SECRET", "").strip()
    receiver_path: str = os.getenv("RECEIVER_PATH", "/hook").strip() or "/hook"

    # --- output ---
    emit_jsonl: str = os.getenv("EMIT_JSONL", "").strip()
    emit_console: bool = _bool("EMIT_CONSOLE", True)
    deliver_timeout: float = _float("DELIVER_TIMEOUT", 3.0)

    # --- logging ---
    log_level: str = os.getenv("LOG_LEVEL", "INFO").strip().upper()

    def validate(self) -> None:
        if not self.rpc_urls:
            raise SystemExit("RPC_URLS is empty — set at least one RPC endpoint.")
        if self.min_value_usd < 0 or self.min_sol_amount < 0:
            raise SystemExit("MIN_VALUE_USD and MIN_SOL_AMOUNT must be >= 0")
        for event_type in self.event_types:
            from .events import EVENT_TYPES

            if event_type not in EVENT_TYPES:
                raise SystemExit(
                    f"EVENT_TYPES contains unknown value {event_type!r}; "
                    f"allowed: {', '.join(EVENT_TYPES)}"
                )


settings = Settings()