# -*- coding: utf-8 -*-
"""SQLite storage: tracked wallets, token cache, positions, dedupe, signal history."""

from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass
from typing import Any, Iterable, Sequence

import aiosqlite

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;

CREATE TABLE IF NOT EXISTS wallets (
    address        TEXT PRIMARY KEY,
    name           TEXT,
    active         INTEGER NOT NULL DEFAULT 1,
    created_at     REAL NOT NULL,
    funded_at      REAL,
    last_signature TEXT,
    last_seen_at   REAL,
    last_error     TEXT
);

CREATE TABLE IF NOT EXISTS tokens (
    mint       TEXT PRIMARY KEY,
    symbol     TEXT,
    name       TEXT,
    decimals   INTEGER NOT NULL DEFAULT 0,
    price_usd  REAL NOT NULL DEFAULT 0,
    supply     REAL NOT NULL DEFAULT 0,
    created    TEXT,
    image      TEXT,
    twitter    TEXT,
    telegram   TEXT,
    website    TEXT,
    fetched_at REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS positions (
    wallet            TEXT NOT NULL,
    mint              TEXT NOT NULL,
    quote_mint        TEXT NOT NULL,
    quantity_raw      INTEGER NOT NULL DEFAULT 0,
    cost_basis_raw    INTEGER NOT NULL DEFAULT 0,
    total_invested    REAL NOT NULL DEFAULT 0,
    realized_pnl      REAL NOT NULL DEFAULT 0,
    opened_at         REAL,
    updated_at        REAL NOT NULL,
    PRIMARY KEY (wallet, mint)
);

CREATE TABLE IF NOT EXISTS seen (
    address   TEXT NOT NULL,
    signature TEXT NOT NULL,
    ts        REAL NOT NULL,
    PRIMARY KEY (address, signature)
);

CREATE TABLE IF NOT EXISTS buys (
    wallet     TEXT NOT NULL,
    mint       TEXT NOT NULL,
    signature  TEXT NOT NULL,
    ts         REAL NOT NULL,
    value_usd  REAL NOT NULL DEFAULT 0,
    PRIMARY KEY (wallet, signature)
);

CREATE TABLE IF NOT EXISTS emitted (
    signature TEXT PRIMARY KEY,
    ts        REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_seen_ts        ON seen(ts);
CREATE INDEX IF NOT EXISTS idx_buys_mint_ts  ON buys(mint, ts);
CREATE INDEX IF NOT EXISTS idx_buys_wallet_ts ON buys(wallet, ts);
CREATE INDEX IF NOT EXISTS idx_emitted_ts     ON emitted(ts);
"""


@dataclass(slots=True)
class TrackedWallet:
    address: str
    name: str | None = None
    active: bool = True
    funded_at: str | None = None
    last_signature: str | None = None


class Store:
    """Async SQLite wrapper. All statements serialised behind one lock."""

    def __init__(self, path: str) -> None:
        self.path = path
        self._db: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()

    async def connect(self) -> None:
        if self._db is not None:
            return
        parent = os.path.dirname(os.path.abspath(self.path))
        if parent:
            os.makedirs(parent, exist_ok=True)
        self._db = await aiosqlite.connect(self.path)
        self._db.row_factory = aiosqlite.Row
        await self._db.executescript(SCHEMA)
        await self._db.commit()

    async def close(self) -> None:
        if self._db is not None:
            await self._db.close()
            self._db = None

    def _db_or_die(self) -> aiosqlite.Connection:
        if self._db is None:
            raise RuntimeError("Store.connect() was not called")
        return self._db

    async def _all(self, sql: str, args: Sequence = ()) -> list[aiosqlite.Row]:
        async with self._lock:
            cur = await self._db_or_die().execute(sql, args)
            try:
                return list(await cur.fetchall())
            finally:
                await cur.close()

    async def _one(self, sql: str, args: Sequence = ()) -> aiosqlite.Row | None:
        async with self._lock:
            cur = await self._db_or_die().execute(sql, args)
            try:
                return await cur.fetchone()
            finally:
                await cur.close()

    async def _run(self, sql: str, args: Sequence = ()) -> int:
        async with self._lock:
            cur = await self._db_or_die().execute(sql, args)
            try:
                await self._db_or_die().commit()
                return cur.rowcount
            finally:
                await cur.close()

    # ------------------------------------------------------------------
    #  wallets
    # ------------------------------------------------------------------

    async def add_wallet(
        self,
        address: str,
        name: str | None = None,
        last_signature: str | None = None,
    ) -> None:
        await self._run(
            """
            INSERT INTO wallets (address, name, active, created_at, last_signature)
            VALUES (?, ?, 1, ?, ?)
            ON CONFLICT(address) DO UPDATE SET
                name = COALESCE(excluded.name, wallets.name),
                active = 1
            """,
            (address, name, time.time(), last_signature),
        )

    async def remove_wallet(self, address: str) -> int:
        return await self._run("DELETE FROM wallets WHERE address = ?", (address,))

    async def set_wallet_active(self, address: str, active: bool) -> int:
        return await self._run(
            "UPDATE wallets SET active = ? WHERE address = ?", (1 if active else 0, address)
        )

    async def set_last_signature(self, address: str, signature: str) -> None:
        await self._run(
            """
            UPDATE wallets
               SET last_signature = ?, last_seen_at = ?, last_error = NULL
             WHERE address = ?
            """,
            (signature, time.time(), address),
        )

    async def set_wallet_error(self, address: str, error: str) -> None:
        await self._run(
            "UPDATE wallets SET last_error = ? WHERE address = ?", (error[:500], address)
        )

    async def active_wallets(self) -> list[TrackedWallet]:
        rows = await self._all("SELECT * FROM wallets WHERE active = 1 ORDER BY created_at")
        return [
            TrackedWallet(
                address=r["address"],
                name=r["name"],
                active=bool(r["active"]),
                funded_at=_iso(r["funded_at"]),
                last_signature=r["last_signature"],
            )
            for r in rows
        ]

    async def all_wallets(self) -> list[TrackedWallet]:
        rows = await self._all("SELECT * FROM wallets ORDER BY created_at")
        return [
            TrackedWallet(
                address=r["address"],
                name=r["name"],
                active=bool(r["active"]),
                funded_at=_iso(r["funded_at"]),
                last_signature=r["last_signature"],
            )
            for r in rows
        ]

    async def names_for(self, addresses: Iterable[str]) -> dict[str, str | None]:
        rows = await self._all("SELECT address, name FROM wallets")
        known = {r["address"]: r["name"] for r in rows}
        return {a: known.get(a) for a in addresses}

    # ------------------------------------------------------------------
    #  token cache
    # ------------------------------------------------------------------

    async def get_token(self, mint: str) -> dict[str, Any] | None:
        row = await self._one("SELECT * FROM tokens WHERE mint = ?", (mint,))
        if row is None:
            return None
        return {
            "mint": row["mint"],
            "symbol": row["symbol"],
            "name": row["name"],
            "decimals": row["decimals"],
            "price_usd": row["price_usd"],
            "supply": row["supply"],
            "created": row["created"],
            "image": row["image"],
            "twitter": row["twitter"],
            "telegram": row["telegram"],
            "website": row["website"],
            "fetched_at": row["fetched_at"],
        }

    async def put_token(self, mint: str, row: dict[str, Any]) -> None:
        await self._run(
            """
            INSERT INTO tokens (mint, symbol, name, decimals, price_usd, supply,
                                created, image, twitter, telegram, website, fetched_at)
            VALUES (:mint, :symbol, :name, :decimals, :price_usd, :supply,
                    :created, :image, :twitter, :telegram, :website, :fetched_at)
            ON CONFLICT(mint) DO UPDATE SET
                symbol = excluded.symbol, name = excluded.name,
                decimals = excluded.decimals, price_usd = excluded.price_usd,
                supply = excluded.supply, created = excluded.created,
                image = excluded.image, twitter = excluded.twitter,
                telegram = excluded.telegram, website = excluded.website,
                fetched_at = excluded.fetched_at
            """,
            row,
        )

    # ------------------------------------------------------------------
    #  positions
    # ------------------------------------------------------------------

    async def get_position(self, wallet: str, mint: str) -> dict[str, Any] | None:
        row = await self._one(
            "SELECT * FROM positions WHERE wallet = ? AND mint = ?", (wallet, mint)
        )
        return dict(row) if row else None

    async def positions(self, wallet: str | None = None) -> list[dict[str, Any]]:
        if wallet is None:
            rows = await self._all("SELECT * FROM positions")
        else:
            rows = await self._all("SELECT * FROM positions WHERE wallet = ?", (wallet,))
        return [dict(r) for r in rows]

    async def upsert_position(
        self,
        wallet: str,
        mint: str,
        quote_mint: str,
        quantity_raw: int,
        cost_basis_raw: int,
        total_invested: float,
        realized_pnl: float,
        opened_at: float | None,
    ) -> None:
        await self._run(
            """
            INSERT INTO positions (wallet, mint, quote_mint, quantity_raw, cost_basis_raw,
                                   total_invested, realized_pnl, opened_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(wallet, mint) DO UPDATE SET
                quote_mint = excluded.quote_mint,
                quantity_raw = excluded.quantity_raw,
                cost_basis_raw = excluded.cost_basis_raw,
                total_invested = excluded.total_invested,
                realized_pnl = excluded.realized_pnl,
                opened_at = COALESCE(positions.opened_at, excluded.opened_at),
                updated_at = excluded.updated_at
            """,
            (
                wallet,
                mint,
                quote_mint,
                quantity_raw,
                cost_basis_raw,
                total_invested,
                realized_pnl,
                opened_at,
                time.time(),
            ),
        )

    async def delete_position(self, wallet: str, mint: str) -> None:
        await self._run("DELETE FROM positions WHERE wallet = ? AND mint = ?", (wallet, mint))

    # ------------------------------------------------------------------
    #  dedupe / signal history
    # ------------------------------------------------------------------

    async def mark_seen(self, address: str, signature: str) -> bool:
        """True when this ``(wallet, signature)`` pair is new."""
        async with self._lock:
            db = self._db_or_die()
            cur = await db.execute(
                "INSERT OR IGNORE INTO seen (address, signature, ts) VALUES (?, ?, ?)",
                (address, signature, time.time()),
            )
            await db.commit()
            inserted = cur.rowcount > 0
            await cur.close()
            return inserted

    async def mark_emitted(self, signature: str) -> bool:
        async with self._lock:
            db = self._db_or_die()
            cur = await db.execute(
                "INSERT OR IGNORE INTO emitted (signature, ts) VALUES (?, ?)",
                (signature, time.time()),
            )
            await db.commit()
            inserted = cur.rowcount > 0
            await cur.close()
            return inserted

    async def filter_unseen(self, address: str, signatures: Sequence[str]) -> list[str]:
        """Signatures of *address* that have not been processed yet."""
        if not signatures:
            return []
        out: list[str] = []
        for start in range(0, len(signatures), 500):  # SQLite parameter limit
            chunk = list(signatures[start : start + 500])
            placeholders = ",".join("?" * len(chunk))
            rows = await self._all(
                f"SELECT signature FROM seen WHERE address = ? AND signature IN ({placeholders})",
                (address, *chunk),
            )
            known = {r["signature"] for r in rows}
            out.extend(s for s in chunk if s not in known)
        return out

    async def record_buy(
        self, wallet: str, mint: str, signature: str, value_usd: float
    ) -> None:
        await self._run(
            "INSERT OR REPLACE INTO buys (wallet, mint, signature, ts, value_usd) VALUES (?, ?, ?, ?, ?)",
            (wallet, mint, signature, time.time(), value_usd),
        )

    async def recent_buys(self, mint: str, since: float) -> list[tuple[str, float, float]]:
        """``(wallet, ts, value_usd)`` for buys of *mint* inside the window."""
        rows = await self._all(
            "SELECT wallet, ts, value_usd FROM buys WHERE mint = ? AND ts >= ? ORDER BY ts",
            (mint, since),
        )
        return [(r["wallet"], r["ts"], r["value_usd"]) for r in rows]

    async def prune(self, keep_seconds: float = 172800.0) -> None:
        cutoff = time.time() - keep_seconds
        await self._run("DELETE FROM seen WHERE ts < ?", (cutoff,))
        await self._run("DELETE FROM emitted WHERE ts < ?", (cutoff,))
        await self._run("DELETE FROM buys WHERE ts < ?", (cutoff,))


def _iso(value: Any) -> str | None:
    if value in (None, ""):
        return None
    try:
        from datetime import datetime, timezone

        return (
            datetime.fromtimestamp(float(value), tz=timezone.utc)
            .isoformat()
            .replace("+00:00", "Z")
        )
    except (TypeError, ValueError, OSError, OverflowError):
        return None