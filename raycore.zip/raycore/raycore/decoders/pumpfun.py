# -*- coding: utf-8 -*-
"""pump.fun / PumpSwap.

Layouts below were taken from live mainnet traffic and verified numerically
against the tracked wallet's real balance deltas (see ``tests/test_pumpfun.py``):

* ``buy``      ``global:buy``      + ``u64 token_amount`` + ``u64 max_sol_cost``
* ``sell``     ``global:sell``     + ``u64 token_amount`` + ``u64 min_sol_output``
* ``migrate``  ``global:migrate``  + ``u64 token_amount``
* ``buy_exact_quote_in``  + ``u64 quote_amount`` + ``u64 min_base_out`` + ``bool``
* ``TradeEvent`` (Anchor event) ``mint``/``sol_amount``/``token_amount``/
  ``is_buy``/``is_maker``/``user``/``timestamp``

The Anchor event is the valuable one: it is emitted by every pump.fun program
version, so trades stay decodable when the bonding-curve program is replaced.
"""

from __future__ import annotations

from ..binary import DecodeError
from ..ids import WSOL, anchor_discriminator
from .base import DecodedContext, Instruction, TradeIntent, event_decoder, decoder

BONDING_CURVE_PROGRAM = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
SUCCESSOR_PROGRAM = "5kZmvKbaqNjSNEnQKEREEKu5r9JkaDRKrQMUvZagCMoz"
PUMPSWAP_PROGRAM = "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA"

PUMP_PROGRAMS = frozenset({BONDING_CURVE_PROGRAM, SUCCESSOR_PROGRAM, PUMPSWAP_PROGRAM})

#: Accounts on a pump instruction: the mint is always at a fixed index because it
#: is passed as a plain argument rather than resolved through the account list.
MINT_ACCOUNT_INDEX = 0
POOL_ACCOUNT_INDEX = 2

TRADE_EVENT_DISC = anchor_discriminator("event", "TradeEvent")
COMPLETE_EVENT_DISC = anchor_discriminator("event", "CompleteEvent")
ANCHOR_EVENT_PREFIX = bytes.fromhex("e445a52e51cb9a1d")


def _mint_from(ix: Instruction, ctx: DecodedContext) -> str | None:
    """Resolve the traded mint from the instruction's accounts.

    Verified against a live sell: ``accounts[0]`` was the bonding curve and the
    mint sat two slots further along, so we prefer a mint that we have observed
    balances for and otherwise fall back to the curve-adjacent slot.
    """
    if not ix.accounts:
        return None
    for address in ix.accounts[:6]:
        if address in ctx.mints:
            return address
    if len(ix.accounts) > POOL_ACCOUNT_INDEX:
        return ix.accounts[POOL_ACCOUNT_INDEX]
    return ix.accounts[MINT_ACCOUNT_INDEX]


def _pool_from(ix: Instruction) -> str | None:
    return ix.accounts[MINT_ACCOUNT_INDEX] if ix.accounts else None


@decoder(BONDING_CURVE_PROGRAM, "pumpfun.buy")
def _bonding_curve_buy(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    from ..ids import anchor_ix

    if ix.data[:8].hex() != anchor_ix("buy"):
        return None
    reader = _reader(ix)
    token_amount = reader.u64()
    max_sol_cost = reader.u64()
    mint = _mint_from(ix, ctx)
    return TradeIntent(
        kind="buy",
        program_id=ix.program_id,
        source="pumpfun",
        mint_in=WSOL,
        mint_out=mint,
        amount_in=max_sol_cost,
        amount_out=token_amount,
        pool=_pool_from(ix),
        extra={"max_sol_cost": max_sol_cost, "token_amount": token_amount},
    )


@decoder(BONDING_CURVE_PROGRAM, "pumpfun.sell")
def _bonding_curve_sell(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    from ..ids import anchor_ix

    if ix.data[:8].hex() != anchor_ix("sell"):
        return None
    reader = _reader(ix)
    token_amount = reader.u64()
    min_sol_output = reader.u64()
    mint = _mint_from(ix, ctx)
    return TradeIntent(
        kind="sell",
        program_id=ix.program_id,
        source="pumpfun",
        mint_in=mint,
        mint_out=WSOL,
        amount_in=token_amount,
        amount_out=min_sol_output,
        pool=_pool_from(ix),
        extra={"min_sol_output": min_sol_output, "token_amount": token_amount},
    )


@decoder(BONDING_CURVE_PROGRAM, "pumpfun.migrate")
def _bonding_curve_migrate(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    from ..ids import anchor_ix

    if ix.data[:8].hex() != anchor_ix("migrate"):
        return None
    amount = _reader(ix).u64()
    return TradeIntent(
        kind="migrate",
        program_id=ix.program_id,
        source="pumpfun",
        mint_out=_mint_from(ix, ctx),
        amount_in=amount,
        extra={"migrated_amount": amount},
    )


@decoder(PUMPSWAP_PROGRAM, "pumpswap.buy_exact_quote_in")
def _pumpswap_buy(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    from ..ids import anchor_ix

    if ix.data[:8].hex() != anchor_ix("buy_exact_quote_in"):
        return None
    reader = _reader(ix)
    quote_amount = reader.u64()
    min_base_out = reader.u64()
    mint = _mint_from(ix, ctx)
    return TradeIntent(
        kind="buy",
        program_id=ix.program_id,
        source="pumpfun",
        mint_in=WSOL,
        mint_out=mint,
        amount_in=quote_amount,
        amount_out=min_base_out,
        pool=_pool_from(ix),
        extra={"quote_amount": quote_amount, "min_base_out": min_base_out},
    )


@decoder(PUMPSWAP_PROGRAM, "pumpswap.sell")
def _pumpswap_sell(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    from ..ids import anchor_ix

    if ix.data[:8].hex() != anchor_ix("sell"):
        return None
    reader = _reader(ix)
    base_amount = reader.u64()
    min_quote_out = reader.u64()
    mint = _mint_from(ix, ctx)
    return TradeIntent(
        kind="sell",
        program_id=ix.program_id,
        source="pumpfun",
        mint_in=mint,
        mint_out=WSOL,
        amount_in=base_amount,
        amount_out=min_quote_out,
        pool=_pool_from(ix),
        extra={"base_amount": base_amount, "min_quote_out": min_quote_out},
    )


def _reader(ix: Instruction):
    from ..binary import Reader

    return Reader(ix.data, 8)


# --------------------------------------------------------------------------- #
#  Anchor events
# --------------------------------------------------------------------------- #


def iter_anchor_events(ctx: DecodedContext):
    """Yield ``(discriminator, body)`` for every Anchor event in the transaction."""
    for ix in ctx.instructions:
        data = ix.data
        if len(data) < 16 or not data.startswith(ANCHOR_EVENT_PREFIX):
            continue
        body = data[8:]
        yield body[:8].hex(), body[8:]


@event_decoder(BONDING_CURVE_PROGRAM, "pumpfun.TradeEvent")
@event_decoder(SUCCESSOR_PROGRAM, "pumpfun.TradeEvent")
@event_decoder(PUMPSWAP_PROGRAM, "pumpfun.TradeEvent")
def _trade_event(ctx: DecodedContext) -> list[TradeIntent]:
    """Decode ``TradeEvent``.

    A single fill can emit several events (one per maker/taker), so every event
    is returned and the caller picks the one belonging to a tracked wallet. The
    trade ``user`` is carried in ``extra`` for exactly that reason.
    """
    from ..binary import Reader

    out: list[TradeIntent] = []
    for disc, body in iter_anchor_events(ctx):
        if disc != TRADE_EVENT_DISC or len(body) < 32 + 8 + 8 + 2:
            continue
        reader = Reader(body)
        try:
            mint = reader.pubkey()
            sol_amount = reader.u64()
            token_amount = reader.u64()
            is_buy = reader.bool_()
            is_maker = reader.bool_()
            user = reader.pubkey()
            timestamp = reader.i64()
        except DecodeError:
            continue

        out.append(
            TradeIntent(
                kind="buy" if is_buy else "sell",
                program_id=BONDING_CURVE_PROGRAM,
                source="pumpfun",
                mint_in=WSOL if is_buy else mint,
                mint_out=mint if is_buy else WSOL,
                amount_in=sol_amount if is_buy else token_amount,
                amount_out=token_amount if is_buy else sol_amount,
                extra={
                    "user": user,
                    "is_maker": is_maker,
                    "event_timestamp": timestamp,
                    "token_amount": token_amount,
                    "sol_amount": sol_amount,
                },
            )
        )
    return out