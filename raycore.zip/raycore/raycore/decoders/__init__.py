# -*- coding: utf-8 -*-
"""Decoder registry.

Importing this package registers every venue decoder. Adding a new venue means
adding one module and one import line here — nothing else in the engine changes.
"""

from __future__ import annotations

from typing import Any

from ..deltas import TxView
from .base import (
    DecodedContext,
    DecoderRegistry,
    Instruction,
    TradeIntent,
    TransferIntent,
    normalise_instructions,
    registry,
)

# Importing for the registration side effect.
from . import meteora as _meteora  # noqa: F401
from . import pumpfun as _pumpfun  # noqa: F401
from . import raydium as _raydium  # noqa: F401
from . import spl as _spl  # noqa: F401

__all__ = [
    "DecodedContext",
    "DecoderRegistry",
    "Instruction",
    "TradeIntent",
    "TransferIntent",
    "analyse",
    "build_context",
    "corroborate",
    "normalise_instructions",
    "registry",
]


def build_context(
    view: TxView,
    tracked: frozenset[str],
    extra_mints: dict[str, int] | None = None,
) -> DecodedContext:
    """Assemble the decoder context for a parsed transaction."""
    mints: dict[str, int] = dict(extra_mints or {})
    for wallet_tokens in view.tokens.values():
        for mint, (_delta, _after, decimals) in wallet_tokens.items():
            mints.setdefault(mint, decimals)
    return DecodedContext(
        view=view,
        instructions=normalise_instructions(view.raw),
        mints=mints,
        tracked=tracked,
    )


def _observed_magnitudes(ctx: DecodedContext) -> list[int]:
    """Absolute size of every balance movement across the tracked wallets."""
    out: list[int] = []
    for wallet in ctx.tracked:
        for delta in ctx.view.deltas(wallet):
            if delta.raw_delta:
                out.append(abs(delta.raw_delta))
    return out


def corroborate(ctx: DecodedContext, intents: list[TradeIntent]) -> list[TradeIntent]:
    """Drop decoded intents whose amounts contradict the observed balance deltas.

    A venue instruction carries *requested* amounts, which may legitimately
    differ from what actually moved (partial fills, a different leg, an
    instruction shape we mis-read). Anything larger than every observed movement
    cannot describe this transaction, so it is discarded and the delta-driven
    classifier takes over. This is the guarantee that makes the enrichment layer
    safe: it can lose detail, never invent facts.
    """
    magnitudes = _observed_magnitudes(ctx)
    if not magnitudes:
        return intents
    ceiling = max(magnitudes)

    kept: list[TradeIntent] = []
    for intent in intents:
        for field in ("amount_in", "amount_out"):
            value = getattr(intent, field)
            if value is None or value <= 0:
                continue
            if value > ceiling and value not in magnitudes:
                intent = _drop_field(intent, field)
        kept.append(intent)
    return kept


def _drop_field(intent: TradeIntent, field: str) -> TradeIntent:
    setattr(intent, field, None)
    return intent


def analyse(
    view: TxView,
    tracked: frozenset[str],
    extra_mints: dict[str, int] | None = None,
) -> tuple[list[TradeIntent], list[TransferIntent]]:
    """Decode every instruction in *view* that belongs to a tracked wallet."""
    ctx = build_context(view, tracked, extra_mints)
    trades, transfers = registry.decode(ctx)
    transfers.extend(_spl.walk_parsed(ctx))
    return corroborate(ctx, trades), transfers