# -*- coding: utf-8 -*-
"""Raydium (AMM v4, AMM v2) and Orca Whirlpool / v2.

These venues are **not** Anchor programs, so there is no discriminator to hash —
their payloads are raw little-endian structs. Layouts below were read off live
mainnet instructions:

* Raydium AMM v4 ``swap``: ``u64 amount_in`` + ``u64 min_amount_out`` + ``u8 direction``
* Orca Whirlpool ``swap``:  ``u64 amount`` + ``u128 sqrt_price_limit`` + 2 flags
* Orca v2 (9W959…):          ``u8 variant`` + ``u64 amount_in`` + ``u64 min_out`` + ``u8``
"""

from __future__ import annotations

from ..binary import DecodeError, Reader
from .base import DecodedContext, Instruction, TradeIntent, decoder

RAYDIUM_AMM_V4 = "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8"
RAYDIUM_AMM_V2 = "5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j"
RAYDIUM_CLMM = "CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK"
ORCA_WHIRLPOOL = "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc"
ORCA_V2 = "9W959DqEETiGZocYWCQPaJ6sBmUzgfxXfqGeTEdp3aQP"
ORCA_V1 = "DjVE6JNiYqPL2QXyCUUh8rNjHrbz9hXHNYt99MQ59qw1"

#: On Raydium AMM v4 the pool authority (PDA) precedes the two vaults and the two
#: mints; the pool itself is the first account.
def _mints(ix: Instruction, idx_a: int, idx_b: int) -> tuple[str | None, str | None]:
    a = ix.accounts[idx_a] if len(ix.accounts) > idx_a else None
    b = ix.accounts[idx_b] if len(ix.accounts) > idx_b else None
    return a, b


@decoder(RAYDIUM_AMM_V4, "raydium.amm4.swap")
def _raydium_amm4(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    if len(ix.data) < 17:
        return None
    reader = Reader(ix.data)
    amount_in = reader.u64()
    min_amount_out = reader.u64()
    direction = reader.u8()
    if amount_in == 0 and min_amount_out == 0:
        return None
    # Accounts: 0 pool, 1 authority, 2 pool token0, 3 pool token1, 4 vaults,
    # 5 pool mint0, 6 pool mint1 on the live samples.
    base, quote = _mints(ix, 5, 6)
    if base is None or quote is None:
        base, quote = _mints(ix, 2, 3)
    if direction:
        mint_in, mint_out = quote, base
    else:
        mint_in, mint_out = base, quote
    return TradeIntent(
        kind="swap",
        program_id=ix.program_id,
        source="raydium",
        mint_in=mint_in,
        mint_out=mint_out,
        amount_in=amount_in,
        amount_out=min_amount_out,
        pool=ix.account,
        extra={"direction": direction},
    )


@decoder(RAYDIUM_AMM_V2, "raydium.amm2.swap")
def _raydium_amm2(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    if len(ix.data) < 9:
        return None
    reader = Reader(ix.data)
    amount_in = reader.u64()
    if amount_in == 0:
        return None
    mint_in = ix.accounts[6] if len(ix.accounts) > 6 else None
    mint_out = ix.accounts[8] if len(ix.accounts) > 8 else None
    return TradeIntent(
        kind="swap",
        program_id=ix.program_id,
        source="raydium",
        mint_in=mint_in,
        mint_out=mint_out,
        amount_in=amount_in,
        pool=ix.account,
    )


@decoder(ORCA_WHIRLPOOL, "orca.whirlpool.swap")
def _orca_whirlpool(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    if len(ix.data) < 35:
        return None
    reader = Reader(ix.data)
    amount = reader.u64()
    if amount == 0:
        return None
    try:
        reader.u128()  # sqrt_price_limit
        input_is_a = reader.bool_()
        a_to_b = reader.bool_()
    except DecodeError:
        input_is_a, a_to_b = True, True
    return TradeIntent(
        kind="swap",
        program_id=ix.program_id,
        source="orca",
        amount_in=amount,
        pool=ix.account,
        extra={"amount_specified_is_input": input_is_a, "a_to_b": a_to_b},
    )


@decoder(ORCA_V2, "orca.v2.swap")
def _orca_v2(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    if len(ix.data) < 18:
        return None
    reader = Reader(ix.data)
    variant = reader.u8()
    amount_in = reader.u64()
    if amount_in == 0:
        return None
    try:
        min_out = reader.u64()
    except DecodeError:
        min_out = None
    mint_in = ix.accounts[5] if len(ix.accounts) > 5 else None
    mint_out = ix.accounts[6] if len(ix.accounts) > 6 else None
    return TradeIntent(
        kind="swap",
        program_id=ix.program_id,
        source="orca",
        mint_in=mint_in,
        mint_out=mint_out,
        amount_in=amount_in,
        amount_out=min_out,
        pool=ix.account,
        extra={"variant": variant},
    )


@decoder(ORCA_V1, "orca.v1.swap")
def _orca_v1(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    if len(ix.data) < 17:
        return None
    amount_in = Reader(ix.data).u64()
    if amount_in == 0:
        return None
    return TradeIntent(
        kind="swap",
        program_id=ix.program_id,
        source="orca",
        amount_in=amount_in,
        pool=ix.account,
    )


@decoder(RAYDIUM_CLMM, "raydium.clmm.swap")
def _raydium_clmm(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    if len(ix.data) < 16:
        return None
    amount_in = Reader(ix.data).u64()
    if amount_in == 0:
        return None
    return TradeIntent(
        kind="swap",
        program_id=ix.program_id,
        source="raydium",
        amount_in=amount_in,
        pool=ix.account,
    )