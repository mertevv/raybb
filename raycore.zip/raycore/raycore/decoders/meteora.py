# -*- coding: utf-8 -*-
"""Meteora DLMM.

``swap`` and ``rebalance_liquidity`` are Anchor instructions and their
discriminators are computed from ``global:<name>``. The LP instructions use
hand-assigned discriminators, so the two that matter are keyed from live traffic
and verified against the wallet's real balance deltas:

* ``cc02c391359191cd``  ``i32 min_bin_id`` + ``i32 max_bin_id`` + … → new position
* ``70bf65ab1c907fbb``  ``i32 min_bin_id`` + ``i32 max_bin_id`` + … → liquidity in/out

``rebalance_liquidity`` carries the pool's ``bin_step`` directly
(``i32 min_bin_id`` followed by ``u16 bin_step``), which is how the emitted
``binStep`` / ``priceRange`` fields get a verified value without an extra RPC.
"""

from __future__ import annotations

from ..binary import DecodeError, Reader
from ..ids import anchor_ix, explicit_disc
from .base import DecodedContext, Instruction, TradeIntent, decoder

DLMM_PROGRAM = "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo"
DBC_PROGRAM = "dbcij3LWUppWqq96dh6gJWwBifmcGfLSB5D4Du3AQGU6"

ADD_LIQUIDITY_DISC = explicit_disc(DLMM_PROGRAM, "add_liquidity") or ""
INITIALIZE_POSITION_DISC = explicit_disc(DLMM_PROGRAM, "initialize_position") or ""

#: Plausible bin steps for a DLMM pool; used to reject nonsense reads.
_VALID_BIN_STEPS = frozenset({1, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000})


def read_bin_step(ctx: "DecodedContext") -> int | None:
    """Best-effort ``bin_step`` for a DLMM pool seen in this transaction.

    ``rebalance_liquidity`` carries it inline, so no extra account fetch is
    needed; the value is range-checked before being trusted.
    """
    for ix in ctx.instructions:
        if ix.program_id != DLMM_PROGRAM:
            continue
        if ix.data[:8].hex() != anchor_ix("rebalance_liquidity"):
            continue
        try:
            Reader(ix.data, 8).i32()  # min_bin_id
            step = Reader(ix.data, 12).u16()
        except DecodeError:
            continue
        if step in _VALID_BIN_STEPS:
            return step
    return None


def _bin_range(ix: Instruction) -> tuple[int, int] | None:
    """``(min_bin_id, max_bin_id)`` if the payload starts with a plausible range."""
    if len(ix.data) < 17:
        return None
    reader = Reader(ix.data, 8)
    try:
        low = reader.i32()
        high = reader.i32()
    except DecodeError:
        return None
    if low <= high and -1_000_000 < low < 1_000_000:
        return low, high
    return None


def _pool(ix: Instruction) -> str | None:
    return ix.account


@decoder(DLMM_PROGRAM, "meteora.dlmm.swap")
def _dlmm_swap(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    if ix.data[:8].hex() != anchor_ix("swap"):
        return None
    reader = Reader(ix.data, 8)
    amount_in = reader.u64()
    min_amount_out = reader.u64()
    if amount_in == 0:
        return None
    return TradeIntent(
        kind="swap",
        program_id=ix.program_id,
        source="meteora",
        amount_in=amount_in,
        amount_out=min_amount_out,
        pool=_pool(ix),
    )


@decoder(DLMM_PROGRAM, "meteora.dlmm.liquidity")
def _dlmm_liquidity(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    """Distinguish LP in/out from the shape of the payload and balance deltas."""
    disc = ix.data[:8].hex()
    if disc not in (ADD_LIQUIDITY_DISC, INITIALIZE_POSITION_DISC):
        return None
    bins = _bin_range(ix)
    if bins is None:
        return None

    wallet = next(iter(ctx.tracked), "")
    outs = [d for d in ctx.view.deltas(wallet) if d.raw_delta < 0]
    ins = [d for d in ctx.view.deltas(wallet) if d.raw_delta > 0]

    if disc == INITIALIZE_POSITION_DISC:
        # Opening a position mints an LP NFT and moves no base/quote tokens.
        if len(ins) == 1 and not outs:
            return None
        kind = "add_liquidity"
    else:
        # Depositing burns the base/quote tokens; withdrawing creates them.
        kind = "add_liquidity" if len(outs) >= 2 or (outs and not ins) else "remove_liquidity"

    extra: dict = {"minBinId": bins[0], "maxBinId": bins[1], "lbPair": _pool(ix)}
    return TradeIntent(
        kind=kind,
        program_id=ix.program_id,
        source="meteora",
        mint_in=outs[0].mint if outs else None,
        mint_out=ins[0].mint if ins else None,
        pool=_pool(ix),
        extra=extra,
    )


@decoder(DLMM_PROGRAM, "meteora.dlmm.rebalance")
def _dlmm_rebalance(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    """Rebalancing an LP position. Reports the pool's ``binStep`` as a side effect."""
    if ix.data[:8].hex() != anchor_ix("rebalance_liquidity"):
        return None
    reader = Reader(ix.data, 8)
    try:
        min_bin_id = reader.i32()
        bin_step = reader.u16()
    except DecodeError:
        return None
    extra: dict = {"minBinId": min_bin_id, "maxBinId": min_bin_id}
    if bin_step in _VALID_BIN_STEPS:
        extra["binStep"] = bin_step
    wallet = next(iter(ctx.tracked), "")
    got_base_and_quote = sum(
        1 for d in ctx.view.deltas(wallet) if d.raw_delta > 0
    ) >= 2
    return TradeIntent(
        kind="remove_liquidity" if got_base_and_quote else "other",
        program_id=ix.program_id,
        source="meteora",
        pool=_pool(ix),
        extra=extra,
    )


@decoder(DBC_PROGRAM, "meteora.dbc.swap")
def _dbc_swap(ctx: DecodedContext, ix: Instruction) -> TradeIntent | None:
    if len(ix.data) < 9:
        return None
    amount_in = Reader(ix.data).u64()
    if amount_in == 0:
        return None
    return TradeIntent(
        kind="swap",
        program_id=ix.program_id,
        source="meteora",
        amount_in=amount_in,
        pool=ix.account,
    )