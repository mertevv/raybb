# -*- coding: utf-8 -*-
"""Decoder plumbing: the intent types decoders produce and the context they get."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Optional, Protocol

from ..binary import DecodeError, Reader
from ..deltas import TxView


@dataclass(slots=True)
class Instruction:
    """A single unparsed instruction, normalised across jsonParsed shapes."""

    program_id: str
    data: bytes
    accounts: list[str]
    depth: int  # 0 = top level, >0 = CPI depth
    index: int  # position within the whole transaction

    @property
    def account(self) -> str | None:
        return self.accounts[0] if self.accounts else None


@dataclass(slots=True)
class TradeIntent:
    """What a decoder concluded about a swap-style instruction.

    ``amount_in`` / ``amount_out`` are the amounts the *venue* moved. They are
    cross-checked against real balance deltas by the event builder and only used
    when they agree, so a mis-decoded layout cannot fabricate a number.
    """

    kind: str  # "buy" | "sell" | "swap" | "add_liquidity" | "remove_liquidity" | "migrate"
    program_id: str
    source: str
    mint_in: str | None = None
    mint_out: str | None = None
    amount_in: int | None = None
    amount_out: int | None = None
    pool: str | None = None
    commission: float = 0.0
    extra: dict[str, Any] = field(default_factory=dict)
    instruction: Instruction | None = field(default=None, repr=False)


@dataclass(slots=True)
class TransferIntent:
    kind: str  # "transfer" | "mint" | "burn"
    program_id: str
    source: str
    mint: str | None = None
    authority: str | None = None
    from_: str | None = None
    to: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class DecodedContext:
    """Everything a decoder may look at."""

    view: TxView
    instructions: list[Instruction]
    mints: dict[str, int]  # mint -> decimals, learned from balances
    tracked: frozenset[str]

    def for_program(self, program_id: str) -> list[Instruction]:
        return [ix for ix in self.instructions if ix.program_id == program_id]


Decoder = Callable[[DecodedContext, Instruction], Optional[Any]]
EventDecoder = Callable[[DecodedContext], list[TradeIntent]]


class DecoderRegistry:
    """Maps a program id to the decoders registered for it."""

    def __init__(self) -> None:
        self._by_program: dict[str, list[tuple[str, Decoder]]] = {}
        self._events: list[tuple[str, str, EventDecoder]] = []
        self._global: list[tuple[str, Decoder]] = []

    def register(self, program_id: str, label: str, decoder: Decoder) -> None:
        self._by_program.setdefault(program_id, []).append((label, decoder))

    def register_global(self, label: str, decoder: Decoder) -> None:
        """Decoder tried for every program that has no specific one."""
        self._global.append((label, decoder))

    def register_events(self, program_id: str, label: str, decoder: EventDecoder) -> None:
        self._events.append((program_id, label, decoder))

    def known_programs(self) -> set[str]:
        return set(self._by_program)

    def decode(self, ctx: DecodedContext) -> tuple[list[TradeIntent], list[TransferIntent]]:
        """Run every applicable decoder, swallowing layout drift."""
        trades: list[TradeIntent] = []
        transfers: list[TransferIntent] = []
        for ix in ctx.instructions:
            handlers = self._by_program.get(ix.program_id) or self._global
            for _label, decoder in handlers:
                try:
                    result = decoder(ctx, ix)
                except DecodeError:
                    continue
                except Exception:  # noqa: BLE001 — a broken decoder must not kill the tx
                    continue
                if result is None:
                    continue
                if isinstance(result, TradeIntent):
                    result.instruction = ix
                    trades.append(result)
                    break
                if isinstance(result, TransferIntent):
                    transfers.append(result)
                    break
        for program_id, _label, event_decoder in self._events:
            if not ctx.for_program(program_id):
                continue
            try:
                trades.extend(t for t in event_decoder(ctx) if t is not None)
            except DecodeError:
                continue
            except Exception:  # noqa: BLE001
                continue
        return trades, transfers

    @staticmethod
    def read(ix: Instruction, offset: int = 0) -> Reader:
        return Reader(ix.data, offset)


registry = DecoderRegistry()


def decoder(program_id: str, label: str):
    """Decorator registering an instruction decoder for *program_id*."""

    def wrap(fn: Decoder) -> Decoder:
        registry.register(program_id, label, fn)
        return fn

    return wrap


def event_decoder(program_id: str, label: str):
    """Decorator registering an Anchor-event decoder for *program_id*."""

    def wrap(fn: EventDecoder) -> EventDecoder:
        registry.register_events(program_id, label, fn)
        return fn

    return wrap


def normalise_instructions(tx: Mapping[str, Any]) -> list[Instruction]:
    """Flatten top-level and CPI instructions into :class:`Instruction` records.

    jsonParsed mixes two shapes: fully-decoded instructions (``parsed``) and
    partially-decoded ones (``programId`` + base58 ``data`` + base58 ``accounts``).
    """
    message = tx.get("transaction", {}).get("message", {}) or {}
    meta = tx.get("meta") or {}
    out: list[Instruction] = []
    counter = 0

    def add(ix: Mapping[str, Any], depth: int) -> None:
        nonlocal counter
        if not isinstance(ix, Mapping):
            return
        if ix.get("parsed") is not None:
            return  # handled separately by the SPL decoder
        program_id = ix.get("programId") or ix.get("program")
        if not isinstance(program_id, str):
            return
        raw = ix.get("data")
        data = b""
        if isinstance(raw, str) and raw:
            from ..b58 import DecodeError as B58Error, b58decode

            try:
                data = b58decode(raw)
            except B58Error:
                data = b""
        accounts = [a for a in (ix.get("accounts") or []) if isinstance(a, str)]
        out.append(
            Instruction(
                program_id=program_id,
                data=data,
                accounts=accounts,
                depth=depth,
                index=counter,
            )
        )
        counter += 1

    for ix in message.get("instructions") or []:
        add(ix, 0)
    for group in meta.get("innerInstructions") or []:
        for ix in group.get("instructions") or []:
            add(ix, 1)
    return out