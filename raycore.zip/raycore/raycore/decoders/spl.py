# -*- coding: utf-8 -*-
"""System Program and SPL Token Program instructions (transfers, mints, burns).

These *are* fully parsed by ``jsonParsed``, so no binary work is needed — but the
parser output has to be walked manually, and it is the only way to learn
``authority`` / ``isDelegated`` on a delegated token transfer.
"""

from __future__ import annotations

from typing import Any, Mapping

from ..binary import DecodeError, Reader
from ..ids import ASSOCIATED_TOKEN_PROGRAM, SYSTEM_PROGRAM, TOKEN_2022_PROGRAM, TOKEN_PROGRAM, WSOL
from .base import DecodedContext, Instruction, TradeIntent, TransferIntent, decoder

_SPL_PROGRAMS = frozenset({TOKEN_PROGRAM, TOKEN_2022_PROGRAM})

_TRANSFER_TYPES = frozenset({"transfer", "transferChecked"})
_BURN_TYPES = frozenset({"burn", "burnChecked"})
_CLOSE_TYPES = frozenset({"closeAccount"})
_APPROVE_TYPES = frozenset({"approve", "approveChecked"})


def iter_parsed_instructions(tx: Mapping[str, Any]):
    """Yield ``(depth, parsed_payload)`` for every jsonParsed instruction."""
    message = tx.get("transaction", {}).get("message", {}) or {}
    meta = tx.get("meta") or {}
    for ix in message.get("instructions") or []:
        parsed = ix.get("parsed") if isinstance(ix, Mapping) else None
        if isinstance(parsed, Mapping):
            yield 0, parsed
    for group in meta.get("innerInstructions") or []:
        for ix in group.get("instructions") or []:
            parsed = ix.get("parsed") if isinstance(ix, Mapping) else None
            if isinstance(parsed, Mapping):
                yield 1, parsed


@decoder(SYSTEM_PROGRAM, "system.transfer")
def _system_transfer(ctx: DecodedContext, ix: Instruction) -> TransferIntent | None:
    if len(ix.data) < 12:
        return None
    reader = Reader(ix.data)
    if reader.u32() != 2:  # SystemInstruction::Transfer
        return None
    lamports = reader.u64()
    if lamports == 0:
        return None
    destination = ix.accounts[1] if len(ix.accounts) > 1 else None
    return TransferIntent(
        kind="transfer",
        program_id=ix.program_id,
        source="system program",
        mint=WSOL,
        from_=ix.account,
        to=destination,
        extra={"lamports": lamports},
    )


@decoder(SYSTEM_PROGRAM, "system.transfer_checked")
def _system_transfer_checked(ctx: DecodedContext, ix: Instruction) -> TransferIntent | None:
    if len(ix.data) < 12:
        return None
    reader = Reader(ix.data)
    if reader.u32() != 3:
        return None
    lamports = reader.u64()
    if lamports == 0:
        return None
    return TransferIntent(
        kind="transfer",
        program_id=ix.program_id,
        source="system program",
        mint=WSOL,
        from_=ix.account,
        to=ix.accounts[1] if len(ix.accounts) > 1 else None,
        extra={"lamports": lamports},
    )


def walk_parsed(ctx: DecodedContext) -> list[TransferIntent]:
    """Extract transfer / mint / burn intents from jsonParsed instructions."""
    out: list[TransferIntent] = []
    for depth, parsed in iter_parsed_instructions(ctx.view.raw):
        program = parsed.get("program") or ""
        info = parsed.get("info") or {}
        ptype = parsed.get("type") or ""

        if program == "system" and ptype in _TRANSFER_TYPES:
            lamports = int(info.get("lamports") or 0)
            out.append(
                TransferIntent(
                    kind="transfer",
                    program_id=SYSTEM_PROGRAM,
                    source="system program",
                    mint=WSOL,
                    from_=info.get("source"),
                    to=info.get("destination"),
                    extra={"lamports": lamports},
                )
            )
            continue

        if program in ("spl-token", "spl-token-2022"):
            source = "solana program library"
            program_id = TOKEN_PROGRAM if program == "spl-token" else TOKEN_2022_PROGRAM
            if ptype in _TRANSFER_TYPES:
                amount = _amount(info)
                out.append(
                    TransferIntent(
                        kind="transfer",
                        program_id=program_id,
                        source=source,
                        mint=info.get("mint"),
                        authority=info.get("authority"),
                        from_=info.get("source"),
                        to=info.get("destination"),
                        extra={
                            "amount": amount,
                            "isDelegated": bool(info.get("delegate")),
                            "delegate": info.get("delegate"),
                        },
                    )
                )
            elif ptype in _BURN_TYPES:
                out.append(
                    TransferIntent(
                        kind="burn",
                        program_id=program_id,
                        source=source,
                        mint=info.get("mint"),
                        authority=info.get("authority"),
                        from_=info.get("account"),
                        extra={"amount": _amount(info)},
                    )
                )
            elif ptype in ("mintTo", "mintToChecked"):
                out.append(
                    TransferIntent(
                        kind="mint",
                        program_id=program_id,
                        source=source,
                        mint=info.get("mint"),
                        authority=info.get("authority") or info.get("mintAuthority"),
                        to=info.get("account") or info.get("destination"),
                        extra={"amount": _amount(info)},
                    )
                )
            elif ptype in _CLOSE_TYPES:
                out.append(
                    TransferIntent(
                        kind="transfer",
                        program_id=program_id,
                        source=source,
                        mint=info.get("mint"),
                        from_=info.get("account"),
                        to=info.get("destination"),
                        extra={"closed": True},
                    )
                )
        elif program == "associated-token-account":
            continue

    return out


def _amount(info: Mapping[str, Any]) -> float:
    token_amount = info.get("tokenAmount") or {}
    raw = token_amount.get("uiAmountString")
    if raw is not None:
        try:
            return float(raw)
        except (TypeError, ValueError):
            return 0.0
    try:
        amount = int(token_amount.get("amount") or 0)
        decimals = int(token_amount.get("decimals") or 0)
    except (TypeError, ValueError):
        return 0.0
    return amount / (10 ** decimals) if decimals else float(amount)


__all__ = [
    "ASSOCIATED_TOKEN_PROGRAM",
    "iter_parsed_instructions",
    "register_parsed_decoders",
    "walk_parsed",
]