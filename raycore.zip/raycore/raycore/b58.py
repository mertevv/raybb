# -*- coding: utf-8 -*-
"""Base58 / base64 codecs used to read Solana instruction payloads.

Solana RPC hands back instruction ``data`` as base58 (log ``Program data:`` lines
use base64), so both are needed.
"""

from __future__ import annotations

import base64

ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_INDEX = {c: i for i, c in enumerate(ALPHABET)}


class DecodeError(ValueError):
    """Malformed base58/base64 payload."""


def b58decode(value: str) -> bytes:
    """Decode a base58 string into bytes."""
    if not value:
        return b""
    num = 0
    for ch in value:
        try:
            num = num * 58 + _INDEX[ch]
        except KeyError as exc:
            raise DecodeError(f"invalid base58 character: {ch!r}") from exc
    body = num.to_bytes((num.bit_length() + 7) // 8, "big") if num else b""
    pad = len(value) - len(value.lstrip("1"))
    return b"\x00" * pad + body


def b58encode(raw: bytes) -> str:
    """Encode bytes as base58."""
    num = int.from_bytes(raw, "big")
    out: list[str] = []
    while num:
        num, rem = divmod(num, 58)
        out.append(ALPHABET[rem])
    zeros = len(raw) - len(raw.lstrip(b"\x00"))
    return "1" * zeros + "".join(reversed(out))


def b64decode(value: str) -> bytes:
    """Decode base64, tolerating missing padding."""
    value = value.strip()
    if not value:
        return b""
    padding = (-len(value)) % 4
    try:
        return base64.b64decode(value + "=" * padding)
    except Exception as exc:  # noqa: BLE001
        raise DecodeError(f"invalid base64 payload: {value[:40]!r}") from exc


def is_pubkey(value: str) -> bool:
    """True when *value* looks like a base58-encoded 32-byte public key."""
    if not value or not (32 <= len(value) <= 44):
        return False
    try:
        return len(b58decode(value)) == 32
    except DecodeError:
        return False