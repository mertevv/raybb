# -*- coding: utf-8 -*-
"""The tracking engine: poll tracked wallets, build payloads, fan them out.

Loop shape, per wallet per tick:

1. ``getSignaturesForAddress`` from the stored cursor to now;
2. batch ``getTransaction`` for anything unseen;
3. build one payload per tracked wallet touched by a transaction;
4. run filters, record buys, run signal detectors;
5. hand survivors to every registered destination and advance the cursor.

The cursor only advances after processing, so a crash re-reads at most one page
instead of skipping activity.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Mapping, Sequence

from .config import Settings
from .deltas import build_view
from .events import EventBuilder
from .filters import FilterRules, matches
from .positions import PositionTracker
from .pricing import PriceOracle
from .rpc import RpcTransportError, SolanaRpc
from .signals import SignalConfig, detect, record_buy
from .store import Store, TrackedWallet

log = logging.getLogger("raycore.engine")

Destination = Callable[[Mapping[str, Any]], Awaitable[None]]


@dataclass(slots=True)
class EngineStats:
    ticks: int = 0
    transactions: int = 0
    payloads: int = 0
    delivered: int = 0
    filtered_out: int = 0
    errors: int = 0
    last_tick_at: float = 0.0

    def as_dict(self) -> dict[str, int | float]:
        return {
            "ticks": self.ticks,
            "transactions": self.transactions,
            "payloads": self.payloads,
            "delivered": self.delivered,
            "filtered_out": self.filtered_out,
            "errors": self.errors,
            "last_tick_at": self.last_tick_at,
        }


@dataclass
class Engine:
    settings: Settings
    store: Store
    rpc: SolanaRpc
    oracle: PriceOracle
    builder: EventBuilder
    tracker: PositionTracker
    rules: FilterRules = field(default_factory=FilterRules)
    signal_config: SignalConfig = field(default_factory=SignalConfig)
    destinations: list[Destination] = field(default_factory=list)
    stats: EngineStats = field(default_factory=EngineStats)
    _task: asyncio.Task | None = None
    _stopping: asyncio.Event = field(default_factory=asyncio.Event)

    # ------------------------------------------------------------------
    #  lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        self._stopping.clear()
        self._task = asyncio.create_task(self._loop(), name="raycore-engine")

    async def stop(self) -> None:
        self._stopping.set()
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
            self._task = None

    def add_destination(self, destination: Destination) -> None:
        self.destinations.append(destination)

    # ------------------------------------------------------------------
    #  main loop
    # ------------------------------------------------------------------

    async def _loop(self) -> None:
        import time

        log.info("engine started (poll=%.1fs wallets=%d)", self.settings.poll_interval, 0)
        while not self._stopping.is_set():
            try:
                wallets = await self.store.active_wallets()
                await self.tick(wallets)
            except RpcTransportError as exc:
                self.stats.errors += 1
                log.warning("tick failed: %s", exc)
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001 — never let one bad tick kill the loop
                self.stats.errors += 1
                log.exception("unexpected error during tick")

            self.stats.ticks += 1
            self.stats.last_tick_at = time.time()
            try:
                await asyncio.wait_for(
                    self._stopping.wait(), timeout=self.settings.poll_interval
                )
            except asyncio.TimeoutError:
                continue

    # ------------------------------------------------------------------
    #  one pass
    # ------------------------------------------------------------------

    async def tick(self, wallets: Sequence[TrackedWallet]) -> int:
        """Process one polling round. Returns the number of payloads delivered."""
        if not wallets:
            return 0
        results = await asyncio.gather(
            *(self._poll_wallet(w) for w in wallets), return_exceptions=True
        )
        delivered = 0
        for wallet, result in zip(wallets, results):
            if isinstance(result, BaseException):
                self.stats.errors += 1
                log.warning("wallet %s: %s", wallet.address, result)
                continue
            delivered += await self._handle(wallet, result or [])
        return delivered

    async def _poll_wallet(self, wallet: TrackedWallet) -> list[tuple[str, dict[str, Any]]]:
        """Fetch and parse unseen transactions for one wallet, newest last."""
        cursor = wallet.last_signature
        signatures: list[str] = []
        entries = await self.rpc.get_signatures_for_address(
            wallet.address,
            before=cursor,
            limit=self.settings.signature_page,
            commitment=self.settings.commitment,
        )
        signatures = [e["signature"] for e in entries if not e.get("err")]

        if cursor is None and self.settings.backfill_limit:
            signatures = signatures[: self.settings.backfill_limit]

        if not signatures:
            return []

        signatures.reverse()  # chronological
        fresh: list[str] = []
        for chunk_start in range(0, len(signatures), 500):
            chunk = signatures[chunk_start : chunk_start + 500]
            fresh.extend(await self.store.filter_unseen(wallet.address, chunk))
        if not fresh:
            return []

        out: list[tuple[str, dict[str, Any]]] = []
        batch_size = max(1, min(self.settings.tx_batch_size, 10))
        for start in range(0, len(fresh), batch_size):
            chunk = fresh[start : start + batch_size]
            for signature, tx in zip(
                chunk,
                await self.rpc.get_transactions(chunk, self.settings.commitment),
            ):
                view = build_view(tx, signature)
                if view is not None:
                    out.append((signature, view.raw))
        return out

    async def _handle(self, wallet: TrackedWallet, items: list[tuple[str, dict[str, Any]]]) -> int:
        delivered = 0
        for signature, raw in items:
            self.stats.transactions += 1
            view = build_view(raw, signature)
            if view is None:
                continue
            names = await self.store.names_for([wallet.address])
            try:
                payloads = await self.builder.build(view, [wallet.address], names)
            except Exception:  # noqa: BLE001
                self.stats.errors += 1
                log.exception("failed to build payload for %s", signature)
                continue
            self.stats.payloads += len(payloads)

            for payload in payloads:
                if not matches(payload, self.rules):
                    self.stats.filtered_out += 1
                    continue
                if not await self.store.mark_emitted(signature + ":" + payload["event_type"]):
                    continue
                mint = await record_buy(self.store, payload)
                if mint:
                    for signal in await detect(self.store, payload, self.signal_config):
                        if matches(signal, self.rules):
                            delivered += await self._deliver(signal)
                delivered += await self._deliver(payload)

            await self.store.mark_seen(wallet.address, signature)
            await self.store.set_last_signature(wallet.address, signature)
        return delivered

    async def _deliver(self, payload: Mapping[str, Any]) -> int:
        if not self.destinations:
            self.stats.delivered += 1
            return 0
        ok = 0
        for destination in self.destinations:
            try:
                await destination(payload)
                ok += 1
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 — one bad sink must not stop others
                self.stats.errors += 1
                log.warning("destination %s failed: %s", getattr(destination, "__name__", destination), exc)
        if ok:
            self.stats.delivered += 1
        return ok