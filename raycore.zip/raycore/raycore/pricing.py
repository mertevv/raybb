# -*- coding: utf-8 -*-
"""Token metadata and USD prices.

Two free, key-less APIs are used:

* Jupiter price  — ``https://lite-api.jup.ag/price/v3`` (batched, up to 100 ids)
* Jupiter tokens — ``https://lite-api.jup.ag/tokens/v2/search`` (symbol, name,
  decimals, supply, socials)

Both are backed by a SQLite cache with a TTL, so a burst of trades on the same
token costs one lookup. Price lookups degrade to ``0`` rather than blocking event
delivery: a payload with a zero ``price_usd`` is still useful, a stalled webhook
is not.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping

import aiohttp

from .ids import STATIC_TOKENS, WSOL

log = logging.getLogger("raycore.pricing")

PRICE_URL = "https://lite-api.jup.ag/price/v3"
TOKEN_URL = "https://lite-api.jup.ag/tokens/v2/search"
PRICE_FALLBACK_URL = "https://price.jup.ag/v6"

PRICE_TTL = 20.0  # seconds — prices move fast; refresh aggressively for hot tokens
META_TTL = 3600.0


@dataclass(slots=True)
class TokenInfo:
    """Metadata for one mint, in the shape the emitted payload expects."""

    mint: str
    symbol: str | None = None
    name: str | None = None
    decimals: int = 0
    price_usd: float = 0.0
    supply: float = 0.0
    created: str | None = None
    image: str | None = None
    twitter: str | None = None
    telegram: str | None = None
    website: str | None = None
    fetched_at: float = field(default=0.0, repr=False)

    def to_payload(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "name": self.name,
            "decimals": self.decimals,
            "price_usd": self.price_usd,
            "supply": self.supply,
            "created": self.created,
            "image": self.image,
            "socials": {
                "twitter": self.twitter,
                "telegram": self.telegram,
                "website": self.website,
            },
        }


class PriceOracle:
    """Cached price + metadata lookups over Jupiter's public API."""

    def __init__(
        self,
        cache,
        session: aiohttp.ClientSession | None = None,
        timeout: float = 8.0,
        enabled: bool = True,
    ) -> None:
        self._cache = cache  # raycore.store.Store
        self._session = session
        self._owns_session = session is None
        self._timeout = aiohttp.ClientTimeout(total=timeout)
        self._enabled = enabled
        self._meta_cache: dict[str, TokenInfo] = {}
        self._price_locks: dict[str, asyncio.Lock] = {}

    async def __aenter__(self) -> "PriceOracle":
        if self._session is None:
            self._session = aiohttp.ClientSession(timeout=self._timeout)
            self._owns_session = True
        return self

    async def __aexit__(self, *exc: object) -> None:
        if self._owns_session and self._session is not None:
            await self._session.close()
            self._session = None

    # ------------------------------------------------------------------
    #  public API
    # ------------------------------------------------------------------

    async def get_many(self, mints: Iterable[str]) -> dict[str, TokenInfo]:
        """Return metadata + a USD price for every mint, using whatever is cached."""
        wanted = [m for m in dict.fromkeys(mints) if m]
        if not wanted:
            return {}

        out: dict[str, TokenInfo] = {}
        to_fetch_meta: list[str] = []
        to_fetch_price: list[str] = []

        now = time.time()
        for mint in wanted:
            cached = self._meta_cache.get(mint)
            if cached is None:
                row = await self._cache.get_token(mint)
                if row is not None:
                    cached = TokenInfo(**row)
                else:
                    static = STATIC_TOKENS.get(mint)
                    if static is not None:
                        # Decimals matter for amount maths, so a static entry is
                        # better than nothing while the API is consulted.
                        cached = TokenInfo(
                            mint=mint,
                            symbol=static["symbol"],
                            name=static["name"],
                            decimals=static["decimals"],
                            supply=static["supply"],
                            created=static["created"],
                            fetched_at=0.0,
                        )
                if cached is not None:
                    self._meta_cache[mint] = cached

            if cached is None:
                to_fetch_meta.append(mint)
                to_fetch_price.append(mint)
                continue

            if now - cached.fetched_at < PRICE_TTL:
                out[mint] = cached
                continue

            out[mint] = cached  # a stale price still beats no price
            to_fetch_price.append(mint)
            if not cached.image and not cached.twitter:
                # Static metadata covers symbol and decimals only; supply, image
                # and socials still need one lookup.
                to_fetch_meta.append(mint)

        if self._enabled and to_fetch_meta:
            await self._load_metadata(to_fetch_meta)

        if self._enabled and to_fetch_price:
            await self._load_prices(to_fetch_price)

        # Re-read from the cache rather than trusting the references collected above:
        # a metadata or price fetch replaces the cached TokenInfo, and the
        # caller's entry has to be the object now holding the fresh values. Every
        # requested mint also gets an entry even if both lookups came back empty —
        # a missing key is an outage, a zero price is just less detail.
        for mint in wanted:
            info = self._meta_cache.get(mint)
            if info is None:
                info = TokenInfo(mint=mint, fetched_at=0.0)
                self._meta_cache[mint] = info
            out[mint] = info

        return out

    async def price_of(self, mint: str) -> float:
        info = (await self.get_many([mint])).get(mint)
        return float(info.price_usd) if info else 0.0

    async def sol_price(self) -> float:
        return await self.price_of(WSOL)

    # ------------------------------------------------------------------
    #  network
    # ------------------------------------------------------------------

    async def _load_metadata(self, mints: list[str]) -> None:
        for mint in mints:
            try:
                payload = await self._get_json(
                    f"{TOKEN_URL}?query={mint}&limit=10&solana={mint}"
                )
            except Exception as exc:  # noqa: BLE001
                log.debug("token metadata failed for %s: %s", mint, exc)
                continue
            for entry in _token_entries(payload):
                if entry.get("id") != mint:
                    continue
                info = self._info_from_search(entry, mint)
                if info is None:
                    break
                # Metadata refreshes must not clobber a price we already have.
                previous = self._meta_cache.get(mint)
                if previous is not None:
                    info.price_usd = previous.price_usd
                await self._store(info)
                break

    def _info_from_search(self, entry: Mapping[str, Any], mint: str) -> TokenInfo | None:
        # The search endpoint answers a bare object for a query that resolves to
        # one token, and a list when several match. Symbol/name/links live at the
        # top level here; the richer nested "info" object appears on list hits.
        info = entry.get("info") if isinstance(entry.get("info"), Mapping) else {}
        source: Mapping[str, Any] = {**entry, **info}

        extensions = source.get("extensions")
        extensions = extensions if isinstance(extensions, Mapping) else {}
        website = source.get("website") or source.get("uri") or None
        twitter = source.get("twitter") or extensions.get("twitter") or extensions.get("x")
        telegram = source.get("telegram") or extensions.get("telegram") or source.get("discord")

        stats = entry.get("stats") if isinstance(entry.get("stats"), Mapping) else {}
        supply = (stats or {}).get("circulatingSupply")
        try:
            supply_value = float(supply) if supply is not None else 0.0
        except (TypeError, ValueError):
            supply_value = 0.0
        try:
            decimals = int(entry.get("decimals") or source.get("decimals") or 0)
        except (TypeError, ValueError):
            decimals = 0

        content = entry.get("content")
        image = None
        if isinstance(content, Mapping):
            metadata = content.get("metadata")
            if isinstance(metadata, Mapping):
                image = metadata.get("image_uri")
        image = image or source.get("icon")

        return TokenInfo(
            mint=mint,
            symbol=source.get("symbol") or None,
            name=source.get("name") or None,
            decimals=decimals,
            supply=supply_value,
            created=_created_at(entry) or _created_at(info),
            image=image,
            twitter=twitter,
            telegram=telegram,
            website=website,
            fetched_at=time.time(),
        )

    async def _load_prices(self, mints: list[str]) -> None:
        wanted = set(mints)
        batches = [mints[i : i + 100] for i in range(0, len(mints), 100)]
        for batch in batches:
            ids = ",".join(batch)
            data = None
            for url in (f"{PRICE_URL}?ids={ids}", f"{PRICE_FALLBACK_URL}?ids={ids}"):
                try:
                    data = await self._get_json(url)
                except Exception as exc:  # noqa: BLE001
                    log.debug("price lookup failed (%s): %s", url, exc)
                    continue
                if data:
                    break
            if not data:
                continue

            now = time.time()
            for key, fields in _price_entries(data):
                # The response is keyed by mint, but only trust that key when it
                # is one we asked about; otherwise fall back to the entry's own id.
                resolved = key if key in wanted else (_entry_mint(fields) or "")
                if resolved not in wanted:
                    continue
                price = _extract_price(fields)
                if price is None:
                    continue
                info = self._meta_cache.get(resolved)
                if info is None:
                    info = TokenInfo(mint=resolved, fetched_at=now)
                    self._meta_cache[resolved] = info
                info.price_usd = price
                info.fetched_at = now
                if not info.decimals:
                    try:
                        info.decimals = int(fields.get("decimals") or 0)
                    except (TypeError, ValueError):
                        pass
                await self._store(info)

    async def _store(self, info: TokenInfo) -> None:
        self._meta_cache[info.mint] = info
        try:
            await self._cache.put_token(
                info.mint,
                {
                    "mint": info.mint,
                    "symbol": info.symbol,
                    "name": info.name,
                    "decimals": info.decimals,
                    "price_usd": info.price_usd,
                    "supply": info.supply,
                    "created": info.created,
                    "image": info.image,
                    "twitter": info.twitter,
                    "telegram": info.telegram,
                    "website": info.website,
                    "fetched_at": info.fetched_at,
                },
            )
        except Exception as exc:  # noqa: BLE001 — cache writes must not break a delivery
            log.debug("token cache write failed for %s: %s", info.mint, exc)

    async def _get_json(self, url: str) -> Any:
        if self._session is None:
            raise RuntimeError("PriceOracle used outside of its async context")
        async with self._session.get(url, headers={"Accept": "application/json"}) as resp:
            if resp.status >= 400:
                raise RuntimeError(f"HTTP {resp.status} from {url}")
            return await resp.json(content_type=None)


#: Keys a price figure may appear under, in priority order. The live v3 endpoint
#: uses ``usdPrice``; older shapes used ``price`` or ``priceData[0].price``.
_PRICE_KEYS = ("usdPrice", "price", "priceUsd", "usd_price")


def _price_entries(data: Any) -> list[tuple[str, Mapping[str, Any]]]:
    """Normalise the price endpoint's shapes into ``(mint, fields)`` pairs.

    Observed live: ``{"data": {"<mint>": {..., "usdPrice": ...}}}`` from a
    ``data``-wrapped response, and a bare ``{"<mint>": {...}}`` otherwise. Some
    deployments key the entry by its own ``id``/``mint`` field instead.
    """
    if not isinstance(data, Mapping):
        return []
    payload: Any = data.get("data") if isinstance(data.get("data"), (Mapping, list)) else data

    out: list[tuple[str, Mapping[str, Any]]] = []
    if isinstance(payload, Mapping):
        if _entry_mint(payload):
            mint = _entry_mint(payload) or ""
            out.append((mint, payload))
            return out
        for key, value in payload.items():
            if isinstance(value, Mapping):
                out.append((str(key), value))
        return out
    if isinstance(payload, list):
        for item in payload:
            if isinstance(item, Mapping):
                mint = _entry_mint(item)
                if mint:
                    out.append((mint, item))
    return out


def _entry_mint(entry: Mapping[str, Any]) -> str | None:
    for key in ("id", "mint", "address", "token"):
        value = entry.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def _extract_price(entry: Mapping[str, Any]) -> float | None:
    for key in _PRICE_KEYS:
        if entry.get(key) is not None:
            try:
                value = float(entry[key])
            except (TypeError, ValueError):
                continue
            return value if value >= 0 else None
    price_data = entry.get("priceData")
    if isinstance(price_data, list) and price_data:
        first = price_data[0]
        if isinstance(first, Mapping):
            try:
                value = float(first.get("price"))
            except (TypeError, ValueError):
                return None
            return value if value >= 0 else None
    return None


def _token_entries(payload: Any) -> list[Mapping[str, Any]]:
    """The search endpoint returns a bare object or a list depending on the query."""
    if isinstance(payload, Mapping):
        return [payload]
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, Mapping)]
    return []


def _created_at(source: Mapping[str, Any]) -> str | None:
    """Creation timestamp, wherever the API happened to put it."""
    for key in ("firstPool", "created"):
        nested = source.get(key)
        if isinstance(nested, Mapping):
            raw = nested.get("createdAt") or nested.get("createdTime")
            if raw:
                stamp = _iso_from_timestamp(raw)
                if stamp:
                    return stamp
    return _iso_from_timestamp(source.get("created_at"))


def _first_link(website: Any, extensions: Any) -> str | None:
    """Pick a social link out of a website field that sometimes holds a profile."""
    if isinstance(website, str) and "twitter.com" in website:
        return website
    if isinstance(extensions, Mapping):
        for key in ("twitter", "telegram", "x"):
            value = extensions.get(key)
            if isinstance(value, str) and value:
                return value
    return None


def _iso_from_timestamp(raw: Any) -> str | None:
    from datetime import datetime, timezone

    try:
        seconds = float(raw)
    except (TypeError, ValueError):
        return None
    if seconds > 1e12:  # milliseconds
        seconds /= 1000.0
    try:
        return datetime.fromtimestamp(seconds, tz=timezone.utc).isoformat().replace("+00:00", "Z")
    except (OverflowError, OSError, ValueError):
        return None