# -*- coding: utf-8 -*-
"""Async JSON-RPC client with batching, backoff and node failover.

Two behaviours matter here and were both learned the hard way against public
mainnet nodes: HTTP 429 must back off rather than retry immediately, and the
request batch has to stay small (``TX_BATCH_SIZE``) because public endpoints
throttle large batches hardest.
"""

from __future__ import annotations

import asyncio
import itertools
import logging
import random
from typing import Any, Sequence

import aiohttp

log = logging.getLogger("raycore.rpc")

TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
TOKEN_2022_PROGRAM = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"


class RpcError(Exception):
    """Non-retryable RPC error (bad params, unknown account)."""

    def __init__(self, message: str, code: int | None = None) -> None:
        super().__init__(message)
        self.code = code


class RpcTransportError(Exception):
    """Retryable network / HTTP failure."""


class SolanaRpc:
    def __init__(
        self,
        urls: Sequence[str],
        concurrency: int = 4,
        timeout: float = 30.0,
        max_retries: int = 5,
        min_gap: float = 0.08,
        max_gap: float = 5.0,
    ) -> None:
        if not urls:
            raise ValueError("at least one RPC URL is required")
        self._urls = list(dict.fromkeys(urls))
        self._timeout = timeout
        self._max_retries = max_retries
        self._min_gap = min_gap
        self._min_gap_floor = min_gap
        self._max_gap = max(max_gap, min_gap)
        self._ids = itertools.count()
        self._sem = asyncio.Semaphore(concurrency)
        self._session: aiohttp.ClientSession | None = None
        self._rr = 0
        self._lock = asyncio.Lock()
        self._last_call = 0.0
        # Nodes that have refused a batch at least once.
        self._no_batch: set[str] = set()
        self._last_penalty: float | None = None
        self._throttled_until = 0.0

    def _penalise(self, retry_after: float | None) -> None:
        """Widen the inter-request gap after a 429, then let it relax again."""
        # Escalate the gap, but stay inside the configured ceiling so one 429
        # cannot stall the engine for a minute.
        current = max(self._min_gap, self._min_gap_floor)
        target = min(
            self._max_gap,
            max(retry_after or 0.0, current * 2.0, self._min_gap * 4.0),
        )
        self._min_gap = target
        self._last_penalty = target
        loop = asyncio.get_running_loop()
        self._throttled_until = max(self._throttled_until, loop.time() + target)

    # -- lifecycle -------------------------------------------------------

    async def __aenter__(self) -> "SolanaRpc":
        connector = aiohttp.TCPConnector(limit=32, ttl_dns_cache=300)
        self._session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=self._timeout),
            connector=connector,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if self._session is not None:
            await self._session.close()
            self._session = None

    # -- transport -------------------------------------------------------

    def _next_url(self, offset: int = 0) -> str:
        index = (self._rr + offset) % len(self._urls)
        if offset == 0:
            self._rr = (self._rr + 1) % len(self._urls)
        return self._urls[index]

    async def _throttle(self) -> None:
        """Space out requests, honouring any active rate-limit penalty."""
        loop = asyncio.get_running_loop()
        async with self._lock:
            now = loop.time()
            if now < self._throttled_until:
                wait = self._throttled_until - now
            else:
                # No penalty active: relax the gap gradually so a sustained rate
                # limit settles at an acceptable rate instead of oscillating.
                self._min_gap = max(self._min_gap_floor, self._min_gap * 0.8)
                wait = max(0.0, self._min_gap - (now - self._last_call))
            self._last_call = loop.time() + wait
        if wait > 0:
            await asyncio.sleep(wait)

    async def _post(self, url: str, payload: Any) -> Any:
        if self._session is None:
            raise RpcTransportError("RPC session is not open")
        await self._throttle()
        async with self._sem:
            try:
                async with self._session.post(url, json=payload) as resp:
                    text = await resp.text()
                    if resp.status == 429:
                        # Back off globally, not just for this call: a node that
                        # throttles is usually throttling the whole client, and a
                        # fixed gap just walks into the same 429 on the next call.
                        self._penalise(_retry_after(resp.headers.get("Retry-After")))
                        raise _Retryable("HTTP 429", self._last_penalty)
                    if resp.status >= 500:
                        raise _Retryable(
                            f"HTTP {resp.status}", _retry_after(resp.headers.get("Retry-After"))
                        )
                    if resp.status >= 400:
                        raise RpcError(f"HTTP {resp.status}: {text[:200]}", resp.status)
                    try:
                        import json

                        return json.loads(text)
                    except ValueError as exc:
                        raise _Retryable(f"invalid JSON: {text[:120]}", None) from exc
            except aiohttp.ClientError as exc:
                raise _Retryable(f"network error: {exc}", None) from exc
            except asyncio.TimeoutError as exc:
                raise _Retryable("timeout", None) from exc

    async def _post_with_retry(self, url: str, payload: Any, what: str) -> Any:
        delay = 0.8
        last: Exception | None = None
        for attempt in range(1, self._max_retries + 1):
            try:
                return await self._post(url, payload)
            except _Retryable as exc:
                last = exc
                if attempt == self._max_retries:
                    break
                wait = min(exc.retry_after if exc.retry_after else delay, 30.0)
                wait = max(wait, self._min_gap)
                wait *= 1.0 + random.uniform(0, 0.3)
                log.warning("%s: %s — retry %d/%d in %.1fs", what, exc.message, attempt, self._max_retries, wait)
                await asyncio.sleep(wait)
                delay = min(delay * 2, 30.0)
        raise RpcTransportError(f"{what}: {last}")

    # -- public API ------------------------------------------------------

    async def call(self, method: str, params: list[Any] | None = None) -> Any:
        payload = {
            "jsonrpc": "2.0",
            "id": next(self._ids),
            "method": method,
            "params": params or [],
        }
        last: Exception | None = None
        for offset in range(len(self._urls)):
            url = self._next_url(offset)
            try:
                data = await self._post_with_retry(url, payload, method)
            except RpcTransportError as exc:
                last = exc
                log.warning("%s failed via node: %s", method, exc)
                continue
            if isinstance(data, dict) and data.get("error"):
                error = data["error"]
                code = error.get("code") if isinstance(error, dict) else None
                message = error.get("message") if isinstance(error, dict) else str(error)
                raise RpcError(f"{method}: {message}", code)
            return data.get("result") if isinstance(data, dict) else None
        raise RpcTransportError(f"{method}: all RPC nodes unavailable ({last})")

    async def batch(self, calls: Sequence[tuple[str, list[Any]]]) -> list[Any]:
        """Batch calls, preserving input order. Falls back to sequential on refusal."""
        if not calls:
            return []
        payload = [
            {"jsonrpc": "2.0", "id": i, "method": method, "params": params}
            for i, (method, params) in enumerate(calls)
        ]
        last: Exception | None = None
        for offset in range(len(self._urls)):
            url = self._next_url(offset)
            if url in self._no_batch:
                continue
            try:
                data = await self._post_with_retry(url, payload, "batch")
            except RpcTransportError as exc:
                last = exc
                continue
            except RpcError as exc:
                # Public nodes advertise a hard cap on getTransaction batch size
                # and answer a larger batch with HTTP 400. Remember that per node
                # instead of retrying the same refusal every tick.
                self._no_batch.add(url)
                log.info("node refuses batches (%s); using sequential calls there", exc)
                last = exc
                continue
            if isinstance(data, list):
                return _align(data, len(calls))
            log.info("node returned an unexpected batch shape (%s); using sequential calls", data)
            break

        if last is not None:
            log.warning("falling back to sequential RPC calls (%s)", last)
        out: list[Any] = []
        for method, params in calls:
            try:
                out.append(await self.call(method, params))
            except RpcError as exc:
                out.append(exc)
        return out

    # -- Solana wrappers -------------------------------------------------

    async def get_slot(self, commitment: str) -> int:
        return int(await self.call("getSlot", [{"commitment": commitment}]) or 0)

    async def get_signatures_for_address(
        self,
        address: str,
        before: str | None = None,
        until: str | None = None,
        limit: int = 1000,
        commitment: str = "confirmed",
    ) -> list[dict[str, Any]]:
        """Signatures touching *address*, newest first."""
        opts: dict[str, Any] = {"limit": min(limit, 1000), "commitment": commitment}
        if before:
            opts["before"] = before
        if until:
            opts["until"] = until
        try:
            result = await self.call("getSignaturesForAddress", [address, opts])
        except RpcError as exc:
            log.warning("getSignaturesForAddress(%s) error: %s", address, exc)
            return []
        return result or []

    async def get_transactions(
        self, signatures: Sequence[str], commitment: str = "confirmed"
    ) -> list[dict[str, Any] | None]:
        calls = [
            (
                "getTransaction",
                [
                    sig,
                    {
                        "encoding": "jsonParsed",
                        "commitment": commitment,
                        "maxSupportedTransactionVersion": 0,
                    },
                ],
            )
            for sig in signatures
        ]
        return await self.batch(calls)

    async def get_balance_lamports(self, address: str, commitment: str = "confirmed") -> int:
        result = await self.call("getBalance", [address, {"commitment": commitment}])
        return int((result or {}).get("value") or 0)

    async def get_multiple_accounts(
        self, addresses: Sequence[str], commitment: str = "confirmed"
    ) -> list[dict[str, Any] | None]:
        if not addresses:
            return []
        result = await self.call(
            "getMultipleAccounts",
            [list(addresses), {"encoding": "base64", "commitment": commitment}],
        )
        return (result or {}).get("value") or []


class _Retryable(Exception):
    def __init__(self, message: str, retry_after: float | None) -> None:
        super().__init__(message)
        self.message = message
        self.retry_after = retry_after


def _retry_after(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return float(value)
    except ValueError:
        return None


def _align(data: list[Any], expected: int) -> list[Any]:
    by_id: dict[int, Any] = {}
    for item in data:
        if isinstance(item, dict) and "id" in item:
            try:
                by_id[int(item["id"])] = item.get("result")
            except (TypeError, ValueError):
                continue
    return [by_id.get(i) for i in range(expected)]