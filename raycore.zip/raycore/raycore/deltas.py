# -*- coding: utf-8 -*-
"""Balance-delta extraction: the authoritative view of what actually moved.

Every event this engine emits is derived from ``preBalances/postBalances`` and
``preTokenBalances/postTokenBalances``. Instruction decoding only ever *enriches*
that picture (venue name, pool, bin range, realised swap direction); it is never
the source of an amount. That is what makes the engine work for aggregators,
router-wrapped routes and brand-new program versions without a code change.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping

from .ids import WSOL

LAMPORTS_PER_SOL = 1_000_000_000


@dataclass(slots=True)
class BalanceDelta:
    """Movement of one asset for one wallet."""

    wallet: str
    mint: str
    raw_delta: int
    decimals: int
    raw_after: int | None = None
    sol_after: float | None = None

    @property
    def amount(self) -> float:
        return self.raw_delta / (10 ** self.decimals) if self.decimals else float(self.raw_delta)

    @property
    def direction(self) -> str:
        return "in" if self.raw_delta > 0 else "out"

    @property
    def is_native(self) -> bool:
        return self.mint == WSOL


@dataclass(slots=True)
class TxView:
    """A transaction prepared for event extraction."""

    signature: str
    slot: int
    block_time: int | None
    fee_lamports: int
    fee_payer: str | None
    failed: bool
    error: str | None
    raw: dict[str, Any] = field(repr=False, default_factory=dict)
    #: wallet -> native SOL delta (lamports) and post balance
    lamports: dict[str, tuple[int, int]] = field(default_factory=dict)
    #: wallet -> mint -> (raw_delta, raw_after, decimals)
    tokens: dict[str, dict[str, tuple[int, int | None, int]]] = field(default_factory=dict)

    # -- accessors -------------------------------------------------------

    def sol_delta(self, wallet: str) -> int:
        entry = self.lamports.get(wallet)
        return entry[0] if entry else 0

    def sol_after(self, wallet: str) -> int | None:
        entry = self.lamports.get(wallet)
        return entry[1] if entry else None

    def token_delta(self, wallet: str, mint: str) -> int:
        entry = self.tokens.get(wallet, {}).get(mint)
        return entry[0] if entry else 0

    def deltas(self, wallet: str) -> list[BalanceDelta]:
        out: list[BalanceDelta] = []
        for mint, (raw_delta, raw_after, decimals) in (self.tokens.get(wallet) or {}).items():
            out.append(
                BalanceDelta(
                    wallet=wallet,
                    mint=mint,
                    raw_delta=raw_delta,
                    decimals=decimals,
                    raw_after=raw_after,
                )
            )
        sol_raw = self.sol_delta(wallet)
        if sol_raw:
            after = self.sol_after(wallet)
            out.append(
                BalanceDelta(
                    wallet=wallet,
                    mint=WSOL,
                    raw_delta=sol_raw,
                    decimals=9,
                    raw_after=after,
                    sol_after=None if after is None else after / LAMPORTS_PER_SOL,
                )
            )
        out.sort(key=lambda d: abs(d.raw_delta), reverse=True)
        return out

    def touched(self) -> set[str]:
        """Every wallet whose SOL or token balances moved."""
        names = set(self.tokens)
        names.update(self.lamports)
        return names

    @property
    def timestamp(self) -> float | None:
        return None if self.block_time is None else float(self.block_time)


def resolve_account_keys(tx: Mapping[str, Any]) -> list[str]:
    """All account pubkeys of a transaction in ``accountIndex`` order."""
    message = tx.get("transaction", {}).get("message", {}) or {}
    keys: list[str] = []
    for entry in message.get("accountKeys") or []:
        if isinstance(entry, dict) and entry.get("pubkey"):
            keys.append(entry["pubkey"])
        elif isinstance(entry, str):
            keys.append(entry)
    loaded = message.get("loadedAddresses") or {}
    extra = list(loaded.get("writable") or []) + list(loaded.get("readonly") or [])
    if extra:
        known = set(keys)
        for address in extra:
            if address not in known:
                keys.append(address)
                known.add(address)
    return keys


def _ui_amount(entry: Mapping[str, Any] | None) -> tuple[int, int]:
    """(raw amount, decimals) from a jsonParsed token balance entry."""
    if not entry:
        return 0, 0
    ui = entry.get("uiTokenAmount") or {}
    try:
        raw = int(ui.get("amount") or 0)
    except (TypeError, ValueError):
        raw = 0
    try:
        decimals = int(ui.get("decimals") or 0)
    except (TypeError, ValueError):
        decimals = 0
    return raw, decimals


def build_view(tx: Mapping[str, Any] | None, signature: str = "") -> TxView | None:
    """Build a :class:`TxView` from a ``jsonParsed`` ``getTransaction`` result."""
    if not tx:
        return None
    meta = tx.get("meta") or {}
    message = tx.get("transaction", {}).get("message", {}) or {}
    keys = resolve_account_keys(tx)

    sig = signature or (message.get("signatures") or [""])[0]
    view = TxView(
        signature=sig,
        slot=int(tx.get("slot") or 0),
        block_time=tx.get("blockTime"),
        fee_lamports=int(meta.get("fee") or 0),
        fee_payer=keys[0] if keys else None,
        failed=bool(meta.get("err")),
        error=_error_text(meta),
        raw=dict(tx),
    )

    pre_balances = meta.get("preBalances") or []
    post_balances = meta.get("postBalances") or []
    for index, (pre, post) in enumerate(zip(pre_balances, post_balances)):
        if index >= len(keys):
            break
        delta = int(post) - int(pre)
        if delta:
            view.lamports[keys[index]] = (delta, int(post))

    pre_tokens: dict[tuple[int, str], Mapping[str, Any]] = {}
    for entry in meta.get("preTokenBalances") or []:
        pre_tokens[(entry.get("accountIndex"), entry.get("mint"))] = entry
    post_tokens: dict[tuple[int, str], Mapping[str, Any]] = {}
    for entry in meta.get("postTokenBalances") or []:
        post_tokens[(entry.get("accountIndex"), entry.get("mint"))] = entry

    # owner -> mint -> (delta, after, decimals)
    by_owner: dict[str, dict[str, tuple[int, int | None, int]]] = {}
    for composite in set(pre_tokens) | set(post_tokens):
        entry = post_tokens.get(composite) or pre_tokens.get(composite)
        if not entry:
            continue
        owner = entry.get("owner")
        mint = entry.get("mint")
        if not owner or not mint:
            continue
        pre_raw, decimals = _ui_amount(pre_tokens.get(composite))
        post_raw, decimals_post = _ui_amount(post_tokens.get(composite))
        decimals = decimals or decimals_post
        delta = post_raw - pre_raw
        after: int | None = post_raw if composite in post_tokens else None

        bucket = by_owner.setdefault(owner, {})
        if mint in bucket:
            # Same mint held in several token accounts: sum them.
            old_delta, old_after, old_dec = bucket[mint]
            bucket[mint] = (
                old_delta + delta,
                None if old_after is None or after is None else old_after + after,
                old_dec or decimals,
            )
        else:
            bucket[mint] = (delta, after, decimals)

    for owner, mints in by_owner.items():
        changed = {m: v for m, v in mints.items() if v[0] != 0}
        if changed:
            view.tokens[owner] = changed

    return view


def _error_text(meta: Mapping[str, Any]) -> str | None:
    err = meta.get("err")
    if not err:
        return None
    if isinstance(err, dict):
        if "InstructionError" in err:
            parts = err["InstructionError"]
            detail = parts[1] if isinstance(parts, list) and len(parts) > 1 else parts
            return f"InstructionError: {detail}"
        return next(iter(err), "error")
    return str(err)


def first_incoming_sol(view: TxView, wallet: str) -> int | None:
    """Largest positive SOL delta for *wallet*, ignoring rent-only dust."""
    deltas = [d.raw_delta for d in view.deltas(wallet) if d.is_native and d.raw_delta > 0]
    return max(deltas) if deltas else None


def split_deltas(
    deltas: Iterable[BalanceDelta],
) -> tuple[list[BalanceDelta], list[BalanceDelta]]:
    """(incoming, outgoing) split."""
    items = list(deltas)
    return ([d for d in items if d.raw_delta > 0], [d for d in items if d.raw_delta < 0])