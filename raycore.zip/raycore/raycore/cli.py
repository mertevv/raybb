# -*- coding: utf-8 -*-
"""Command line entry point.

    python -m raycore track --wallet <addr> [--name label] [--wallet <addr2>]
    python -m raycore wallets
    python -m raycore positions --wallet <addr>
    python -m raycore inspect <signature>
    python -m raycore selftest

``track`` runs the poller; ``inspect`` re-derives a payload for a signature you
already know about, which is the fastest way to check decoder output against a
transaction you can see in an explorer.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
from typing import Any, Mapping

from .config import Settings, settings as default_settings
from .deltas import build_view
from .engine import Engine
from .events import EventBuilder
from .filters import FilterRules, describe_rules, event_summary
from .positions import PositionTracker
from .pricing import PriceOracle
from .rpc import SolanaRpc
from .signals import SignalConfig
from .store import Store

log = logging.getLogger("raycore")


def _configure_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)-18s %(message)s",
        datefmt="%H:%M:%S",
    )


def _make_stack(settings: Settings) -> tuple[Store, SolanaRpc, PriceOracle, PositionTracker, EventBuilder]:
    store = Store(settings.db_path)
    rpc = SolanaRpc(
        settings.rpc_urls,
        concurrency=settings.rpc_concurrency,
        timeout=settings.rpc_timeout,
        max_retries=settings.rpc_retries,
    )
    oracle = PriceOracle(store, enabled=settings.prices_enabled)
    tracker = PositionTracker(store)
    builder = EventBuilder(store, oracle, tracker)
    return store, rpc, oracle, tracker, builder


# --------------------------------------------------------------------------- #
#  commands
# --------------------------------------------------------------------------- #


async def cmd_track(args: argparse.Namespace, settings: Settings) -> int:
    store, rpc, oracle, _tracker, builder = _make_stack(settings)
    await store.connect()

    for entry in args.wallet or []:
        address, _, name = entry.partition(":")
        await store.add_wallet(address.strip(), name.strip() or None)
        log.info("tracking %s%s", address.strip(), f" as {name.strip()!r}" if name.strip() else "")

    if args.clear:
        for wallet in await store.all_wallets():
            await store.remove_wallet(wallet.address)
        log.info("cleared tracked wallets")

    if not await store.all_wallets():
        log.error("no wallets tracked — pass --wallet <address[:name]>")
        await store.close()
        return 2

    rules = FilterRules.from_settings(settings)
    log.info("filters: %s", ", ".join(describe_rules(rules)))
    log.info("RPC nodes: %s", ", ".join(settings.rpc_urls))
    log.info("commitment: %s | poll: %.1fs", settings.commitment, settings.poll_interval)

    jsonl = None
    if settings.emit_jsonl:
        jsonl = open(settings.emit_jsonl, "a", encoding="utf-8")
        log.info("also writing payloads to %s", settings.emit_jsonl)

    async def destination(payload: Mapping[str, Any]) -> None:
        if settings.emit_console:
            print(event_summary(payload), flush=True)
        if jsonl is not None:
            jsonl.write(json.dumps(payload, ensure_ascii=False) + "\n")
            jsonl.flush()

    async with rpc, oracle:
        engine = Engine(
            settings=settings,
            store=store,
            rpc=rpc,
            oracle=oracle,
            builder=builder,
            tracker=_tracker,
            rules=rules,
            signal_config=SignalConfig.from_settings(settings),
            destinations=[destination],
        )
        receiver = None
        if settings.receiver_enabled:
            from .server import WebhookReceiver

            receiver = WebhookReceiver(settings, stats=lambda: engine.stats.as_dict())
            await receiver.start()

        await engine.start()
        try:
            await asyncio.Event().wait()
        except (KeyboardInterrupt, asyncio.CancelledError):
            pass
        finally:
            await engine.stop()
            if receiver is not None:
                await receiver.stop()
            if jsonl is not None:
                jsonl.close()
            await store.prune(settings.seen_retention_hours * 3600.0)
            await store.close()
    return 0


async def cmd_wallets(args: argparse.Namespace, settings: Settings) -> int:
    store = Store(settings.db_path)
    await store.connect()
    wallets = await store.all_wallets()
    if not wallets:
        print("no wallets tracked")
    for wallet in wallets:
        state = "active" if wallet.active else "paused"
        label = wallet.name or "-"
        cursor = (wallet.last_signature or "-")[:12]
        print(f"{wallet.address}  {label:<20} {state:<7} cursor={cursor}")
    await store.close()
    return 0


async def cmd_positions(args: argparse.Namespace, settings: Settings) -> int:
    store = Store(settings.db_path)
    await store.connect()
    tracker = PositionTracker(store)
    wallet = args.wallet[0] if args.wallet else None
    rows = await tracker.holdings(wallet) if wallet else [
        row
        for w in await store.active_wallets()
        for row in await tracker.holdings(w.address)
    ]
    if not rows:
        print("no open positions")
    for row in rows:
        avg = row["cost_basis_raw"] / row["quantity_raw"] if row["quantity_raw"] else 0
        print(
            f"{row['wallet'][:12]}  {row['mint'][:14]}  qty={row['quantity_raw']}  "
            f"avg={avg:.6g}  invested={row['total_invested']:.6f} {row['quote_mint'][:6]}  "
            f"realised={row['realized_pnl']:.6f}"
        )
    await store.close()
    return 0


async def cmd_inspect(args: argparse.Namespace, settings: Settings) -> int:
    """Rebuild the payload for one signature — the decoder's debug surface."""
    store, rpc, oracle, _tracker, builder = _make_stack(settings)
    await store.connect()
    tracked = [args.wallet[0]] if args.wallet else [
        w.address for w in await store.active_wallets()
    ]
    if not tracked:
        print("nothing to attribute the transaction to — pass --wallet <address>")
        await store.close()
        return 2

    # The oracle owns an HTTP session, so it has to stay open while payloads are
    # being built — that is where the price and metadata lookups happen.
    async with rpc, oracle:
        txs = await rpc.get_transactions([args.signature], settings.commitment)
        tx = next((t for t in txs if t), None)
        if tx is None:
            print("transaction not found on this RPC (wrong cluster, or the node pruned it)")
            await store.close()
            return 1

        view = build_view(tx, args.signature)
        names = await store.names_for(tracked)
        payloads = await builder.build(view, tracked, names)

    print(json.dumps(payloads, indent=2, ensure_ascii=False))
    await store.close()
    return 0 if payloads else 1


async def cmd_selftest(args: argparse.Namespace, settings: Settings) -> int:
    """Connectivity check: RPC reachable, price API reachable, store writable."""
    store, rpc, oracle, _tracker, builder = _make_stack(settings)
    await store.connect()
    ok = True
    async with rpc, oracle:
        try:
            slot = await rpc.get_slot(settings.commitment)
            print(f"rpc      OK   slot={slot} node={settings.rpc_urls[0]}")
        except Exception as exc:  # noqa: BLE001
            print(f"rpc      FAIL {exc}")
            ok = False

        sol = await oracle.sol_price()
        if sol:
            print(f"pricing  OK   SOL=${sol:,.2f}")
        else:
            print("pricing  WARN no SOL price returned (payloads will carry price_usd=0)")

        wallets = await store.active_wallets()
        print(f"store    OK   {settings.db_path} wallets={len(wallets)}")
    await store.close()
    return 0 if ok else 1


# --------------------------------------------------------------------------- #
#  parser
# --------------------------------------------------------------------------- #


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="raycore", description=__doc__)
    parser.add_argument("--log-level", default=None, help="override LOG_LEVEL")
    sub = parser.add_subparsers(dest="command", required=True)

    track = sub.add_parser("track", help="run the polling engine")
    track.add_argument(
        "--wallet",
        action="append",
        metavar="ADDRESS[:NAME]",
        help="wallet to track; repeatable",
    )
    track.add_argument("--clear", action="store_true", help="remove all tracked wallets first")
    track.set_defaults(func=cmd_track)

    wallets = sub.add_parser("wallets", help="list tracked wallets")
    wallets.set_defaults(func=cmd_wallets)

    positions = sub.add_parser("positions", help="show open positions")
    positions.add_argument("--wallet", action="append", help="restrict to one wallet")
    positions.set_defaults(func=cmd_positions)

    inspect = sub.add_parser("inspect", help="print the payload built for one signature")
    inspect.add_argument("signature")
    inspect.add_argument("--wallet", action="append", help="attribute the tx to this wallet")
    inspect.set_defaults(func=cmd_inspect)

    selftest = sub.add_parser("selftest", help="check RPC, pricing and storage")
    selftest.set_defaults(func=cmd_selftest)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    settings = default_settings
    _configure_logging(args.log_level or settings.log_level)
    settings.validate()
    try:
        return asyncio.run(args.func(args, settings))
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())