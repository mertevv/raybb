# -*- coding: utf-8 -*-
"""Notification filters.

Ray-style: a payload has to survive the filter pipeline to reach a destination.
Everything is evaluated against the payload, so filters compose with signals
without either knowing about the other.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from .ids import WSOL


@dataclass(frozen=True, slots=True)
class FilterRules:
    event_types: frozenset[str] = frozenset()
    min_value_usd: float = 0.0
    min_sol_amount: float = 0.0
    include_failed: bool = False
    tracked_mints: frozenset[str] = frozenset()
    block_mints: frozenset[str] = frozenset()

    @classmethod
    def from_settings(cls, settings) -> "FilterRules":
        return cls(
            event_types=frozenset(settings.event_types),
            min_value_usd=settings.min_value_usd,
            min_sol_amount=settings.min_sol_amount,
            include_failed=settings.include_failed,
            tracked_mints=frozenset(settings.tracked_mints),
            block_mints=frozenset(settings.block_mints),
        )

    @property
    def is_noop(self) -> bool:
        return not (
            self.event_types
            or self.min_value_usd
            or self.min_sol_amount
            or not self.include_failed
            or self.tracked_mints
            or self.block_mints
        )


def _mints(payload: Mapping[str, Any]) -> set[str]:
    out = {c["mint"] for c in payload.get("token_changes") or [] if c.get("mint")}
    out |= set((payload.get("tokens") or {}).keys())
    return out


def _max_value_usd(payload: Mapping[str, Any]) -> float:
    values = [float(c.get("value_usd") or 0.0) for c in payload.get("token_changes") or []]
    return max(values) if values else 0.0


def _sol_leg(payload: Mapping[str, Any]) -> float:
    total = 0.0
    for change in payload.get("token_changes") or []:
        if change.get("mint") == WSOL:
            total += abs(float(change.get("amount") or 0.0))
    return total


def matches(payload: Mapping[str, Any], rules: FilterRules) -> bool:
    """True when *payload* passes every configured rule."""
    if payload.get("failed") and not rules.include_failed:
        return False

    if rules.event_types and payload.get("event_type") not in rules.event_types:
        return False

    mints = _mints(payload)
    if rules.block_mints and (mints & rules.block_mints):
        return False
    if rules.tracked_mints and not (mints & rules.tracked_mints):
        return False

    if rules.min_value_usd and _max_value_usd(payload) < rules.min_value_usd:
        return False
    if rules.min_sol_amount and _sol_leg(payload) < rules.min_sol_amount:
        return False

    return True


def describe_rules(rules: FilterRules) -> list[str]:
    """Human-readable summary for the startup banner."""
    out: list[str] = []
    if rules.event_types:
        out.append(f"event_types={sorted(rules.event_types)}")
    if rules.min_value_usd:
        out.append(f"min_value_usd={rules.min_value_usd}")
    if rules.min_sol_amount:
        out.append(f"min_sol_amount={rules.min_sol_amount}")
    if rules.tracked_mints:
        out.append(f"tracked_mints={len(rules.tracked_mints)}")
    if rules.block_mints:
        out.append(f"block_mints={len(rules.block_mints)}")
    if not rules.include_failed:
        out.append("failed=dropped")
    return out or ["no filters"]


def event_summary(payload: Mapping[str, Any]) -> str:
    """One-line rendering used by console output."""
    wallet = payload.get("followed_wallets") or [{}]
    name = wallet[0].get("wallet_name") or (wallet[0].get("address") or "?")[:8]
    event = payload.get("event") or {}
    mints = _mints(payload)
    token = next((m for m in mints if m != WSOL), None)
    from .ids import STATIC_TOKENS

    symbol = (payload.get("tokens", {}).get(token) or {}).get("symbol") if token else None
    symbol = symbol or (STATIC_TOKENS.get(token, {}).get("symbol") if token else None)
    symbol = symbol or (token[:6] + "…" if token else "SOL")
    usd = _max_value_usd(payload)
    return (
        f"[{payload.get('event_type')}] {name} {symbol} "
        f"${usd:,.2f} via {payload.get('source')} "
        f"({payload.get('id', '')[:12]}…)"
    )


def iter_leaf_events(payloads: Iterable[Mapping[str, Any]]):
    for payload in payloads:
        yield payload