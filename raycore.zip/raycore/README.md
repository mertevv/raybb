# raycore

A self-contained Solana wallet-tracking engine that emits the same payload
schema as the RayBot webhook API — built from the chain up, with no RayBot
dependency.

```
pip install -r requirements.txt
cp .env.example .env

python -m raycore selftest
python -m raycore track --wallet <address>:<label>
```

## What it does

Polls tracked wallets, decodes each transaction, and emits one structured
payload per wallet per event:

```json
{
  "id": "3HAGuENhbuCtuGsMGVA5sAL3jCrpvctUNhKKT78uuBm6pS8RmtP8vdbFMJkVvK…",
  "event_type": "sell",
  "timestamp": "2026-10-03T22:25:22.000Z",
  "chain": "solana",
  "failed": false,
  "source": "pumpfun",
  "fee_payer": "443tKAP…",
  "followed_wallets": [{"address": "443tKAP…", "wallet_name": "drainer-test",
                        "funded_at": null, "sol_balance": 0.005278562}],
  "token_changes": [
    {"address": "443tKAP…", "direction": "out", "mint": "HmkiLg8B…pump",
     "amount_raw": "-1738165090724", "amount": -1738165.090724,
     "price_usd": 0.000171, "value_usd": -296.99},
    {"address": "443tKAP…", "direction": "in", "mint": "So111…1112",
     "amount_raw": "2478907986", "amount": 2.478908,
     "price_usd": 119.80, "value_usd": 296.99}
  ],
  "tokens": { "HmkiLg8B…pump": {"symbol": "PAYR", "decimals": 6, "…": "…"} },
  "fees": {"priority_fee": 0.05, "jito_tip": 0.0, "total_tip": 0.05},
  "position": {"side": "sell", "is_closed": true, "realized_pnl": 0.0, "…": "…"},
  "event": {"type": "sell", "mintIn": "HmkiLg8B…pump", "mintOut": "So111…1112",
            "programId": "pAMMBay6oceH9f…", "pool": "BeS6PZpnnfuG…"}
}
```

`event_type` is one of `buy`, `sell`, `swap`, `transfer_in`, `transfer_out`,
`token_mint`, `add_liquidity`, `remove_liquidity`, `migrate`, `other`, plus the
composite signals `multi_buy` and `accumulation`. `position` appears only on
buy/sell.

## The one design decision that matters

**Amounts come from balance deltas. Instruction decoding only adds labels.**

`preBalances`/`postBalances` and the token-balance snapshots are the ground truth
for what moved. The decoders are an enrichment layer on top: they identify the
venue, the pool, the direction and the bin range. Any decoded amount that
contradicts an observed delta is discarded (`decoders.corroborate`), and the
delta-driven classifier takes over.

This is what lets the engine keep working across:

- **routers** — a Jupiter route wrapping a Raydium fill reports the venue that
  executed the fill, not the aggregator
- **new program versions** — pump.fun has already replaced its bonding-curve
  program; the `TradeEvent` anchor event is emitted by every version, so trades
  stay decodable
- **unknown venues** — an unrecognised program still yields a correct `swap` from
  the shape of the movement

The enrichment layer can lose detail. It cannot invent facts.

## Verifying decoders against the chain

Anchor discriminators are **computed**, never hard-coded: `global:sell` is
`sha256(b"global:sell")[:8]`, evaluated at import. No magic bytes to mistype.

Programs that don't use Anchor hashing (Meteora DLMM's LP instructions) carry
hand-assigned discriminators in `ids.EXPLICIT_DISCRIMINATORS`, taken from live
mainnet traffic.

Every decoder is tested against a corpus of real `getTransaction` responses
captured from mainnet-beta (`tests/fixtures/`). The bar is not "doesn't crash" —
decoded amounts are checked against the delta the chain recorded:

```
tests/test_decoders.py::TestPumpFunTradeEvent
    decoded token_amount == |observed balance delta|
    is_buy          == sign of the observed delta
```

Run them with:

```
python -m unittest discover -s tests
```

123 tests, no network access required.

## Commands

| Command | Purpose |
| --- | --- |
| `track --wallet ADDR[:NAME]` | run the polling engine (repeat `--wallet`) |
| `track --clear` | drop all tracked wallets |
| `wallets` | list tracked wallets and cursors |
| `positions [--wallet ADDR]` | open positions with cost basis and realised PnL |
| `inspect <SIGNATURE> [--wallet ADDR]` | print the payload built for one signature |
| `selftest` | check RPC, pricing API and storage |

`inspect` is the decoder's debug surface: give it a signature you can see in an
explorer and it prints exactly what the engine would emit, with no wallet state
required.

## Layout

| Module | Responsibility |
| --- | --- |
| `deltas.py` | balance-delta extraction — the ground truth |
| `binary.py`, `b58.py` | bounds-checked little-endian reader, base58/base64 |
| `ids.py` | program ids, Anchor helpers, discriminators, quote mints |
| `decoders/` | per-venue decoders, pluggable and independently registered |
| `events.py` | payload assembly, classification, trade pricing |
| `positions.py` | average cost basis, realised/unrealised PnL |
| `pricing.py` | Jupiter price + metadata, SQLite-cached |
| `filters.py`, `signals.py` | notification filters, multi-buy / accumulation |
| `engine.py`, `rpc.py` | polling loop, batching, backoff, node failover |
| `server.py` | webhook receiver serving the same contract |

## Webhook receiver

Set `RECEIVER_ENABLED=true` to expose `POST /hook` and accept payloads in the
same format, with `Authorization` validation and an immediate `204` before any
processing. `GET /health` reports engine counters.

## Notes on public RPC

Public mainnet endpoints throttle hard and cap `getTransaction` batch size (the
one tested here allows exactly 1 per batch). The client:

- remembers which nodes refuse batches and drops them from batch rotation
- widens its inter-request gap on HTTP 429, then relaxes it gradually
- round-robins across `RPC_URLS` and fails over on transport errors

This keeps it functional on free endpoints. A dedicated provider is
substantially faster and is what `RPC_URLS` is for.

## Configuration

Every setting is an environment variable, documented in `.env.example`. The ones
worth knowing:

| Variable | Default | Notes |
| --- | --- | --- |
| `POLL_INTERVAL` | `12` | seconds between passes |
| `TX_BATCH_SIZE` | `10` | keep small on public endpoints |
| `BACKFILL_LIMIT` | `0` | history fetched when a wallet is added |
| `EVENT_TYPES` | all | e.g. `buy,sell` to mute transfers |
| `MIN_SOL_AMOUNT` | `0` | e.g. `0.5` to ignore dust |
| `MULTI_BUY_WALLETS` | `2` | wallets buying the same token within the window |
| `ACCUMULATION_BUYS` | `3` | buys by one wallet inside the window |
| `EMIT_JSONL` | — | append every payload to a file |