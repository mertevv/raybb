# -*- coding: utf-8 -*-
"""Engine, store, positions, signals and receiver tests against a fake RPC."""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from typing import Any

from helpers import corpus, owner_of

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from raycore.config import Settings
from raycore.engine import Engine
from raycore.events import EventBuilder
from raycore.filters import FilterRules, event_summary, matches
from raycore.positions import PositionTracker
from raycore.signals import SignalConfig, detect, record_buy
from raycore.store import Store

from test_payload import StubOracle

WALLET_A = "5tCAwakc5gSNjeKtYJCu4STTSyWYoHVRsvQXQ1Y7CML8"
WALLET_B = "9W959DqEETiGZocYWCQPaJ6sBmUzgfxXfqGeTEdp3aQP"


def _settings(tmpdir: str, **overrides) -> Settings:
    base = dict(
        db_path=os.path.join(tmpdir, "e.sqlite3"),
        poll_interval=0.01,
        prices_enabled=False,
        emit_console=False,
        receiver_enabled=False,
    )
    base.update(overrides)
    # Settings is a frozen dataclass with env-backed defaults; build it explicitly.
    import dataclasses

    defaults = {f.name for f in dataclasses.fields(Settings)}
    kwargs = {}
    for name in defaults:
        if name in base:
            kwargs[name] = base[name]
    return Settings(**kwargs)


class FakeRpc:
    """Serves the fixture corpus as if it were a node."""

    def __init__(self, txs: list[dict[str, Any]]) -> None:
        self.txs = txs
        self.by_signature = {tx["transaction"]["signatures"][0]: tx for tx in txs}
        self.signature_calls: list[str] = []
        self.batch_sizes: list[int] = []

    async def get_slot(self, commitment: str = "confirmed") -> int:
        return 1

    async def get_signatures_for_address(
        self,
        address: str,
        before: str | None = None,
        until: str | None = None,
        limit: int = 1000,
        commitment: str = "confirmed",
    ) -> list[dict[str, Any]]:
        self.signature_calls.append(address)
        out = []
        for tx in self.txs:
            sig = tx["transaction"]["signatures"][0]
            if before and sig == before:
                break
            out.append({"signature": sig, "err": tx["meta"].get("err")})
        return out[:limit]

    async def get_transactions(self, signatures, commitment: str = "confirmed"):
        self.batch_sizes.append(len(signatures))
        return [self.by_signature.get(sig) for sig in signatures]


class BaseAsync(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.settings = _settings(self._tmp.name)
        self.store = Store(self.settings.db_path)
        await self.store.connect()
        self.oracle = StubOracle()
        self.tracker = PositionTracker(self.store)
        self.builder = EventBuilder(self.store, self.oracle, self.tracker)

    async def asyncTearDown(self) -> None:
        await self.store.close()
        self._tmp.cleanup()

    async def make_engine(self, txs, **overrides) -> tuple[Engine, list]:
        rpc = FakeRpc(txs)
        delivered: list[dict] = []

        async def sink(payload):
            delivered.append(payload)

        options: dict[str, Any] = {
            "rules": FilterRules.from_settings(self.settings),
            "signal_config": SignalConfig.from_settings(self.settings),
            "destinations": [sink],
        }
        options.update(overrides)

        engine = Engine(
            settings=self.settings,
            store=self.store,
            rpc=rpc,  # type: ignore[arg-type]
            oracle=self.oracle,  # type: ignore[arg-type]
            builder=self.builder,
            tracker=self.tracker,
            **options,
        )
        return engine, delivered


class TestStore(BaseAsync):
    async def test_wallet_lifecycle(self):
        await self.store.add_wallet(WALLET_A, "alpha")
        await self.store.add_wallet(WALLET_B, "beta")
        self.assertEqual(len(await self.store.active_wallets()), 2)
        self.assertEqual((await self.store.names_for([WALLET_A, WALLET_B]))[WALLET_A], "alpha")

        await self.store.set_wallet_active(WALLET_A, False)
        self.assertEqual([w.address for w in await self.store.active_wallets()], [WALLET_B])

        await self.store.add_wallet(WALLET_A)
        self.assertIn(WALLET_A, [w.address for w in await self.store.active_wallets()])

        self.assertEqual(await self.store.remove_wallet(WALLET_B), 1)
        self.assertEqual(len(await self.store.all_wallets()), 1)

    async def test_seen_deduplication(self):
        self.assertTrue(await self.store.mark_seen(WALLET_A, "sig1"))
        self.assertFalse(await self.store.mark_seen(WALLET_A, "sig1"))
        self.assertTrue(await self.store.mark_seen(WALLET_B, "sig1"))

    async def test_filter_unseen(self):
        await self.store.mark_seen(WALLET_A, "a")
        result = await self.store.filter_unseen(WALLET_A, ["a", "b", "c"])
        self.assertEqual(result, ["b", "c"])

    async def test_filter_unseen_handles_large_pages(self):
        signatures = [f"sig{i}" for i in range(1200)]
        self.assertEqual(len(await self.store.filter_unseen(WALLET_A, signatures)), 1200)

    async def test_emitted_deduplication(self):
        self.assertTrue(await self.store.mark_emitted("buy:1"))
        self.assertFalse(await self.store.mark_emitted("buy:1"))
        self.assertTrue(await self.store.mark_emitted("sell:1"))

    async def test_token_cache_roundtrip(self):
        row = {
            "mint": "MINT1",
            "symbol": "S",
            "name": "N",
            "decimals": 6,
            "price_usd": 1.5,
            "supply": 10.0,
            "created": None,
            "image": None,
            "twitter": None,
            "telegram": None,
            "website": None,
            "fetched_at": 1.0,
        }
        await self.store.put_token("MINT1", row)
        loaded = await self.store.get_token("MINT1")
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded["symbol"], "S")
        self.assertEqual(loaded["price_usd"], 1.5)


class TestPositions(BaseAsync):
    async def test_average_cost_basis_blends(self):
        snap = await self.tracker.apply(WALLET_A, "M1", WSOL := "So11111111111111111111111111111111111111112", 6, 1_000_000, 2_000_000_000, "buy")
        self.assertTrue(snap.is_new)
        self.assertEqual(snap.quantity, 1.0)
        self.assertAlmostEqual(snap.average_cost_basis or 0, 2.0)

        snap = await self.tracker.apply(WALLET_A, "M1", WSOL, 6, 1_000_000, 4_000_000_000, "buy")
        self.assertFalse(snap.is_new)
        self.assertEqual(snap.quantity, 2.0)
        # (2 SOL + 4 SOL) / 2 tokens = 3 SOL per token
        self.assertAlmostEqual(snap.average_cost_basis or 0, 3.0)

    async def test_partial_sell_realises_pro_rata(self):
        quote = "So11111111111111111111111111111111111111112"
        await self.tracker.apply(WALLET_A, "M1", quote, 6, 2_000_000, 2_000_000_000, "buy")
        snap = await self.tracker.apply(WALLET_A, "M1", quote, 6, -1_000_000, 1_500_000_000, "sell")
        self.assertFalse(snap.is_closed)
        self.assertEqual(snap.quantity, 1.0)
        # basis 2 SOL over 2 tokens; selling 1 token releases 1 SOL for 1.5 SOL
        self.assertAlmostEqual(snap.realized_pnl, 0.5, places=9)
        # 2 tokens bought for 2 SOL = 1 SOL/token. Selling 1 token releases 1 SOL
        # of basis, leaving 1 token carrying 1 SOL.
        self.assertAlmostEqual(snap.average_cost_basis or 0, 1.0, places=9)

    async def test_full_sell_closes_position(self):
        quote = "So11111111111111111111111111111111111111112"
        await self.tracker.apply(WALLET_A, "M1", quote, 6, 1_000_000, 2_000_000_000, "buy")
        snap = await self.tracker.apply(WALLET_A, "M1", quote, 6, -1_000_000, 3_000_000_000, "sell")
        self.assertTrue(snap.is_closed)
        self.assertEqual(snap.quantity, 0)
        self.assertIsNone(snap.average_cost_basis)
        self.assertAlmostEqual(snap.realized_pnl, 1.0, places=9)
        self.assertEqual(await self.tracker.holdings(WALLET_A), [])

    async def test_unrealised_pnl_uses_current_price(self):
        quote = "So11111111111111111111111111111111111111112"
        snap = await self.tracker.apply(WALLET_A, "M1", quote, 6, 1_000_000, 2_000_000_000, "buy")
        block = snap.to_payload("buy", 5.0)
        self.assertAlmostEqual(block["unrealized_pnl"], 3.0, places=9)

    async def test_oversell_does_not_go_negative(self):
        quote = "So11111111111111111111111111111111111111112"
        await self.tracker.apply(WALLET_A, "M1", quote, 6, 1_000_000, 2_000_000_000, "buy")
        snap = await self.tracker.apply(WALLET_A, "M1", quote, 6, -5_000_000, 3_000_000_000, "sell")
        self.assertTrue(snap.is_closed)
        self.assertEqual(snap.quantity, 0)

    async def test_quote_decimals_are_right(self):
        usdc = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
        snap = await self.tracker.apply(WALLET_A, "M1", usdc, 6, 1_000_000, 2_000_000, "buy")
        self.assertAlmostEqual(snap.total_invested, 2.0, places=9)


class TestFilters(unittest.TestCase):
    def _payload(self, **overrides):
        payload = {
            "id": "sig",
            "event_type": "buy",
            "failed": False,
            "source": "pumpfun",
            "token_changes": [
                {"mint": "So11111111111111111111111111111111111111112", "amount": 1.0, "value_usd": 100.0, "direction": "out"},
                {"mint": "TOKMINT", "amount": 500.0, "value_usd": 99.0, "direction": "in"},
            ],
            "tokens": {"TOKMINT": {"symbol": "TOK"}},
        }
        payload.update(overrides)
        return payload

    def test_noop_rules_pass_everything(self):
        self.assertTrue(matches(self._payload(), FilterRules()))

    def test_failed_dropped_by_default(self):
        rules = FilterRules(include_failed=False)
        self.assertFalse(matches(self._payload(failed=True), rules))
        self.assertTrue(matches(self._payload(failed=True), FilterRules(include_failed=True)))

    def test_event_type_filter(self):
        rules = FilterRules(event_types=frozenset({"sell"}))
        self.assertFalse(matches(self._payload(), rules))
        self.assertTrue(matches(self._payload(event_type="sell"), rules))

    def test_min_value_filter(self):
        self.assertFalse(matches(self._payload(), FilterRules(min_value_usd=150.0)))
        self.assertTrue(matches(self._payload(), FilterRules(min_value_usd=50.0)))

    def test_min_sol_filter(self):
        # The fixture moves 1.0 SOL.
        self.assertFalse(matches(self._payload(), FilterRules(min_sol_amount=2.0)))
        self.assertTrue(matches(self._payload(), FilterRules(min_sol_amount=0.5)))

    def test_mint_allow_and_block(self):
        self.assertTrue(matches(self._payload(), FilterRules(tracked_mints=frozenset({"TOKMINT"}))))
        self.assertFalse(matches(self._payload(), FilterRules(block_mints=frozenset({"TOKMINT"}))))

    def test_summary_renders(self):
        summary = event_summary(self._payload())
        self.assertIn("buy", summary)
        self.assertIn("TOK", summary)


class TestSignals(BaseAsync):
    def _buy(self, wallet: str, mint: str, value: float) -> dict[str, Any]:
        return {
            "id": f"sig-{wallet}-{mint}-{value}",
            "event_type": "buy",
            "chain": "solana",
            "failed": False,
            "source": "pumpfun",
            "fee_payer": wallet,
            "followed_wallets": [{"address": wallet, "wallet_name": wallet[:6]}],
            "token_changes": [
                {"mint": "So11111111111111111111111111111111111111112", "amount": 1.0, "value_usd": value, "direction": "out"},
                {"mint": mint, "amount": 10.0, "value_usd": value, "direction": "in"},
            ],
            "tokens": {mint: {"symbol": "TOK", "decimals": 6, "price_usd": 1.0}},
            "position": {"total_invested": 1.0},
            "fees": {},
            "event": {"type": "buy"},
        }

    async def test_multi_buy_fires_on_distinct_wallets(self):
        cfg = SignalConfig(multi_buy_wallets=2, multi_buy_window=600, accumulation_enabled=False)
        mint = "MINTMULTI"
        await record_buy(self.store, self._buy(WALLET_A, mint, 100.0))
        await record_buy(self.store, self._buy(WALLET_B, mint, 120.0))
        signals = await detect(self.store, self._buy(WALLET_B, mint, 120.0), cfg)
        kinds = [s["event_type"] for s in signals]
        self.assertIn("multi_buy", kinds)
        signal = next(s for s in signals if s["event_type"] == "multi_buy")
        self.assertEqual(signal["multi_buy"]["mint"], mint)
        self.assertGreaterEqual(signal["multi_buy"]["wallet_count"], 2)

    async def test_multi_buy_does_not_fire_for_one_wallet(self):
        cfg = SignalConfig(multi_buy_wallets=2, accumulation_enabled=False)
        mint = "MINTONE"
        await record_buy(self.store, self._buy(WALLET_A, mint, 100.0))
        signals = await detect(self.store, self._buy(WALLET_A, mint, 100.0), cfg)
        self.assertEqual([s for s in signals if s["event_type"] == "multi_buy"], [])

    async def test_multi_buy_respects_the_window(self):
        """A buy outside the window must not count towards a multi-buy."""
        import time

        cfg = SignalConfig(multi_buy_wallets=2, multi_buy_window=60.0, accumulation_enabled=False)
        mint = "MINTWIN"
        await record_buy(self.store, self._buy(WALLET_A, mint, 100.0))
        # Backdate the recorded buy well outside the window.
        await self.store._run(
            "UPDATE buys SET ts = ? WHERE mint = ?", (time.time() - 3600.0, mint)
        )
        signals = await detect(self.store, self._buy(WALLET_B, mint, 100.0), cfg)
        self.assertEqual([s for s in signals if s["event_type"] == "multi_buy"], [])

    async def test_accumulation_fires_after_threshold(self):
        cfg = SignalConfig(
            multi_buy_enabled=False, accumulation_buys=3, accumulation_window=3600
        )
        mint = "MINTACC"
        for i in range(2):
            await record_buy(self.store, self._buy(WALLET_A, mint, 10.0 * (i + 1)))
        self.assertEqual(
            [s for s in await detect(self.store, self._buy(WALLET_A, mint, 30.0), cfg) if s["event_type"] == "accumulation"],
            [],
        )
        await record_buy(self.store, self._buy(WALLET_A, mint, 40.0))
        signals = await detect(self.store, self._buy(WALLET_A, mint, 40.0), cfg)
        signal = next(s for s in signals if s["event_type"] == "accumulation")
        self.assertGreaterEqual(signal["accumulation"]["buy_count"], 3)

    async def test_non_buy_payloads_emit_nothing(self):
        cfg = SignalConfig()
        payload = self._buy(WALLET_A, "M", 1.0)
        payload["event_type"] = "sell"
        self.assertEqual(await detect(self.store, payload, cfg), [])


class TestEngine(BaseAsync):
    async def test_tick_emits_and_advances_cursor(self):
        txs = corpus("pumpfun")
        wallet = owner_of(txs[0])
        await self.store.add_wallet(wallet, "w")
        engine, delivered = await self.make_engine(txs)

        count = await engine.tick(await self.store.active_wallets())
        self.assertGreater(count, 0)
        self.assertTrue(delivered)
        for payload in delivered:
            self.assertEqual(payload["followed_wallets"][0]["address"], wallet)

        cursor = (await self.store.get_wallet(wallet) if hasattr(self.store, "get_wallet") else None)
        wallet_row = (await self.store.all_wallets())[0]
        self.assertIsNotNone(wallet_row.last_signature)

        # Second tick sees the same page but must not re-deliver.
        before = len(delivered)
        await engine.tick(await self.store.active_wallets())
        self.assertEqual(len(delivered), before, "a signature was delivered twice")

    async def test_tick_is_idempotent_across_restarts(self):
        txs = corpus("raydium_amm4")
        wallet = owner_of(txs[0])
        await self.store.add_wallet(wallet)
        engine, delivered = await self.make_engine(txs)
        await engine.tick(await self.store.active_wallets())
        first = len(delivered)

        # Simulate a restart: fresh engine, same store.
        engine2, delivered2 = await self.make_engine(txs)
        await engine2.tick(await self.store.active_wallets())
        self.assertEqual(len(delivered2), 0)
        self.assertEqual(len(delivered), first)

    async def test_batches_are_size_capped(self):
        txs = corpus("pumpswap")[:12]
        wallet = owner_of(txs[0])
        await self.store.add_wallet(wallet)
        engine, _ = await self.make_engine(txs)
        await engine.tick(await self.store.active_wallets())
        for size in engine.rpc.batch_sizes:
            self.assertLessEqual(size, 10)

    async def test_filter_rules_are_applied(self):
        txs = corpus("raydium_amm4")
        wallet = owner_of(txs[0])
        await self.store.add_wallet(wallet)
        engine, delivered = await self.make_engine(txs, rules=FilterRules(event_types=frozenset({"sell"})))
        await engine.tick(await self.store.active_wallets())
        for payload in delivered:
            self.assertEqual(payload["event_type"], "sell")

    async def test_failing_destination_does_not_stop_others(self):
        txs = corpus("pumpfun")
        wallet = owner_of(txs[0])
        await self.store.add_wallet(wallet)
        rpc = FakeRpc(txs)
        ok: list = []

        async def boom(_payload):
            raise RuntimeError("sink is down")

        async def fine(payload):
            ok.append(payload)

        engine = Engine(
            settings=self.settings,
            store=self.store,
            rpc=rpc,  # type: ignore[arg-type]
            oracle=self.oracle,  # type: ignore[arg-type]
            builder=self.builder,
            tracker=self.tracker,
            destinations=[boom, fine],
        )
        await engine.tick(await self.store.active_wallets())
        self.assertTrue(ok, "the healthy destination received nothing")

    async def test_stats_are_counted(self):
        txs = corpus("pumpfun")
        wallet = owner_of(txs[0])
        await self.store.add_wallet(wallet)
        engine, delivered = await self.make_engine(txs)
        await engine.tick(await self.store.active_wallets())
        stats = engine.stats.as_dict()
        self.assertGreater(stats["transactions"], 0)
        self.assertGreater(stats["payloads"], 0)
        self.assertEqual(stats["delivered"], len(delivered))
        self.assertEqual(stats["errors"], 0)

    async def test_no_wallets_is_a_noop(self):
        engine, _ = await self.make_engine(corpus("pumpfun"))
        self.assertEqual(await engine.tick([]), 0)


class TestConfigValidation(unittest.TestCase):
    def test_unknown_event_type_is_rejected(self):
        settings = _settings(tempfile.gettempdir(), event_types=("not_a_type",))
        with self.assertRaises(SystemExit):
            settings.validate()

    def test_valid_settings_pass(self):
        _settings(tempfile.gettempdir(), event_types=("buy", "sell")).validate()

    def test_defaults_are_sane(self):
        _settings(tempfile.gettempdir()).validate()


class TestEndToEndPayload(BaseAsync):
    async def test_a_real_pumpfun_sell_produces_a_coherent_payload(self):
        """Full pipeline on a live-captured transaction, prices stubbed."""
        from raycore.deltas import build_view

        txs = corpus("pumpfun")
        for tx in txs:
            owner = owner_of(tx)
            await self.store.add_wallet(owner, "smart money")
            view = build_view(tx)
            payloads = await self.builder.build(view, [owner], {owner: "smart money"})
            if not payloads:
                continue
            payload = payloads[0]
            json.dumps(payload, allow_nan=False)
            if payload["event_type"] in ("buy", "sell"):
                self.assertIn("position", payload)
                self.assertIn(payload["source"], {"pumpfun", "pumpfun", "solana program library"})
            self.assertTrue(payload["token_changes"])
            return
        self.fail("no pump.fun payload was produced from the corpus")


if __name__ == "__main__":
    unittest.main(verbosity=2)