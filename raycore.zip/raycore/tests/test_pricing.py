# -*- coding: utf-8 -*-
"""Pricing tests with a stubbed HTTP layer — no network required."""

from __future__ import annotations

import os
import sys
import tempfile
import unittest
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from raycore.ids import USDC, WSOL
from raycore.pricing import PriceOracle, TokenInfo
from raycore.store import Store

WSOL_FULL = WSOL
TOKEN_URL_PREFIX = "https://lite-api.jup.ag/tokens/v2/search"


class FakeResponse:
    def __init__(self, payload: Any, status: int = 200) -> None:
        self._payload = payload
        self.status = status
        self.headers: dict[str, str] = {}

    async def __aenter__(self) -> "FakeResponse":
        return self

    async def __aexit__(self, *exc: object) -> None:
        return None

    async def json(self, content_type: str | None = None) -> Any:
        return self._payload


class FakeSession:
    """Answers the two Jupiter endpoints and records what was asked for."""

    def __init__(self, price_payload=None, token_payload=None, price_status: int = 200) -> None:
        self.price_payload = price_payload
        self.token_payload = token_payload
        self.price_status = price_status
        self.price_urls: list[str] = []
        self.token_urls: list[str] = []

    def get(self, url: str, headers: dict | None = None) -> FakeResponse:
        # aiohttp's session.get() returns a context manager, not a coroutine.
        if TOKEN_URL_PREFIX in url:
            self.token_urls.append(url)
            if self.token_payload is None:
                return FakeResponse([], status=200)
            return FakeResponse(self.token_payload)
        self.price_urls.append(url)
        if self.price_payload is None:
            return FakeResponse({}, status=self.price_status)
        return FakeResponse(self.price_payload, status=self.price_status)

    async def close(self) -> None:
        return None


class TestPriceOracle(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.store = Store(os.path.join(self._tmp.name, "p.sqlite3"))
        await self.store.connect()

    async def asyncTearDown(self) -> None:
        await self.store.close()
        self._tmp.cleanup()

    async def _oracle(self, session: FakeSession) -> PriceOracle:
        return PriceOracle(self.store, session=session)  # type: ignore[arg-type]

    async def test_price_is_parsed_and_cached(self):
        session = FakeSession(
            price_payload={"data": {WSOL: {"id": WSOL, "price": "150.25"}}}
        )
        oracle = await self._oracle(session)
        result = await oracle.get_many([WSOL])
        self.assertAlmostEqual(result[WSOL].price_usd, 150.25, places=6)
        self.assertEqual(result[WSOL].symbol, "SOL")

        # Second call is served from memory: no extra HTTP.
        before = len(session.price_urls)
        await oracle.get_many([WSOL])
        self.assertEqual(len(session.price_urls), before)

    async def test_list_style_price_payload(self):
        session = FakeSession(price_payload={"data": [{"id": WSOL, "price": 99.5}]})
        oracle = await self._oracle(session)
        self.assertAlmostEqual(await oracle.sol_price(), 99.5, places=6)

    async def test_live_v3_shape(self):
        """The exact shape lite-api.jup.ag/price/v3 returns today."""
        session = FakeSession(
            price_payload={
                WSOL: {
                    "createdAt": "2024-06-05T08:55:25.527Z",
                    "liquidity": 986214962.71,
                    "usdPrice": 119.60376265853203,
                    "blockId": 453060903,
                    "decimals": 9,
                }
            }
        )
        oracle = await self._oracle(session)
        self.assertAlmostEqual(await oracle.sol_price(), 119.60376265853203, places=9)
        self.assertEqual((await oracle.get_many([WSOL]))[WSOL].decimals, 9)

    async def test_usd_price_key_is_preferred(self):
        session = FakeSession(price_payload={"data": {WSOL: {"id": WSOL, "usdPrice": 42.0, "price": 1.0}}})
        oracle = await self._oracle(session)
        self.assertAlmostEqual(await oracle.sol_price(), 42.0, places=6)

    async def test_response_keyed_by_mint_wins_over_entry_id(self):
        session = FakeSession(
            price_payload={"data": {WSOL: {"id": "SOMETHINGELSE", "usdPrice": 5.0}}}
        )
        oracle = await self._oracle(session)
        # The key matches a requested mint, so it is trusted over the entry's id.
        self.assertAlmostEqual(await oracle.sol_price(), 5.0, places=6)

    async def test_unrelated_response_is_ignored(self):
        session = FakeSession(
            price_payload={"data": {"WRONGKEY": {"id": "ALSOWRONG", "usdPrice": 5.0}}}
        )
        oracle = await self._oracle(session)
        self.assertEqual(await oracle.sol_price(), 0.0)

    async def test_bare_token_search_object(self):
        """A search that resolves to one token answers a bare object, not a list."""
        mint = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
        session = FakeSession(
            price_payload={mint: {"usdPrice": 0.9998}},
            token_payload={
                "id": mint,
                "name": "USD Coin",
                "symbol": "USDC",
                "decimals": 6,
                "twitter": "https://twitter.com/circle",
                "icon": "https://example/usdc.png",
            },
        )
        oracle = await self._oracle(session)
        info = (await oracle.get_many([mint]))[mint]
        self.assertEqual(info.symbol, "USDC")
        self.assertEqual(info.name, "USD Coin")
        self.assertEqual(info.decimals, 6)
        self.assertEqual(info.twitter, "https://twitter.com/circle")
        self.assertEqual(info.image, "https://example/usdc.png")
        self.assertAlmostEqual(info.price_usd, 0.9998, places=6)

    async def test_metadata_is_fetched_and_persisted(self):
        mint = "So1111111111111111111111111111111111111111TEST"
        session = FakeSession(
            price_payload={"data": {mint: {"id": mint, "price": "0.5"}}},
            token_payload=[
                {
                    "id": mint,
                    "decimals": 6,
                    "info": {"symbol": "TEST", "name": "Test Token", "website": "https://x.com/t"},
                    "stats": {"circulatingSupply": 1000.0},
                    "created": {"createdAt": 1700000000},
                    "content": {"metadata": {"image_uri": "https://img"}},
                }
            ],
        )
        oracle = await self._oracle(session)
        result = await oracle.get_many([mint])
        info = result[mint]
        self.assertEqual(info.symbol, "TEST")
        self.assertEqual(info.decimals, 6)
        self.assertEqual(info.image, "https://img")
        self.assertAlmostEqual(info.price_usd, 0.5)
        self.assertTrue(info.created.endswith("Z"))

        stored = await self.store.get_token(mint)
        self.assertIsNotNone(stored)
        self.assertEqual(stored["symbol"], "TEST")

    async def test_price_failure_degrades_to_zero(self):
        session = FakeSession(price_payload=None, price_status=500)
        oracle = await self._oracle(session)
        self.assertEqual(await oracle.sol_price(), 0.0)

    async def test_static_metadata_is_used_when_the_api_is_silent(self):
        session = FakeSession(price_payload={"data": {USDC: {"id": USDC, "price": "1.0"}}})
        oracle = await self._oracle(session)
        info = (await oracle.get_many([USDC]))[USDC]
        self.assertEqual(info.symbol, "USDC")
        self.assertEqual(info.decimals, 6)

    async def test_unknown_token_still_returns_an_entry(self):
        mint = "TotallyUnknownMint111111111111111111111111111"
        session = FakeSession(price_payload={"data": {}})
        oracle = await self._oracle(session)
        result = await oracle.get_many([mint])
        self.assertIn(mint, result)
        self.assertEqual(result[mint].price_usd, 0.0)

    async def test_disabled_oracle_makes_no_requests(self):
        session = FakeSession(price_payload={"data": {WSOL: {"id": WSOL, "price": "10"}}})
        oracle = PriceOracle(self.store, session=session, enabled=False)  # type: ignore[arg-type]
        await oracle.get_many([WSOL])
        self.assertEqual(session.price_urls, [])
        self.assertEqual(session.token_urls, [])

    async def test_price_data_variant(self):
        session = FakeSession(
            price_payload={"data": {WSOL: {"id": WSOL, "priceData": [{"price": "77.7"}]}}}
        )
        oracle = await self._oracle(session)
        self.assertAlmostEqual(await oracle.sol_price(), 77.7, places=6)

    async def test_zero_and_negative_prices_are_handled(self):
        session = FakeSession(price_payload={"data": {WSOL: {"id": WSOL, "price": "0"}}})
        oracle = await self._oracle(session)
        self.assertEqual(await oracle.sol_price(), 0.0)

    async def test_payload_shape_matches_the_contract(self):
        session = FakeSession(price_payload={"data": {WSOL: {"id": WSOL, "price": "150"}}})
        oracle = await self._oracle(session)
        payload = (await oracle.get_many([WSOL]))[WSOL].to_payload()
        self.assertEqual(
            set(payload),
            {"symbol", "name", "decimals", "price_usd", "supply", "created", "image", "socials"},
        )
        self.assertEqual(set(payload["socials"]), {"twitter", "telegram", "website"})

    async def test_empty_request_is_a_noop(self):
        session = FakeSession()
        oracle = await self._oracle(session)
        self.assertEqual(await oracle.get_many([]), {})
        self.assertEqual(session.price_urls, [])

    async def test_cache_is_reused_across_oracle_instances(self):
        session = FakeSession(price_payload={"data": {WSOL: {"id": WSOL, "price": "123.0"}}})
        oracle = await self._oracle(session)
        await oracle.get_many([WSOL])
        count = len(session.price_urls)

        second = await self._oracle(session)
        info = (await second.get_many([WSOL]))[WSOL]
        self.assertAlmostEqual(info.price_usd, 123.0, places=6)
        self.assertEqual(len(session.price_urls), count, "second oracle re-fetched a cached price")


if __name__ == "__main__":
    unittest.main(verbosity=2)