# -*- coding: utf-8 -*-
"""Decoder assertions against the harvested mainnet corpus.

The bar for these tests is deliberately higher than "does not crash": every
decoded amount is checked against the balance delta the chain actually recorded.
A decoder that starts returning plausible-but-wrong numbers fails here.
"""

from __future__ import annotations

import unittest

from helpers import (
    WSOL,
    corpus,
    instructions,
    owner_deltas,
    owner_of,
    sol_delta,
)

from raycore.b58 import b58decode, b58encode
from raycore.binary import DecodeError, Reader
from raycore.deltas import build_view
from raycore.decoders import analyse, normalise_instructions
from raycore.ids import (
    ANCHOR_EVENT_PREFIX,
    DEX_PROGRAMS,
    QUOTE_MINTS,
    anchor_discriminator,
    anchor_ix,
)


class TestCodecs(unittest.TestCase):
    def test_b58_roundtrip(self):
        for payload in (b"", b"\x00", b"\x00\x00\x01", bytes(range(32))):
            self.assertEqual(b58decode(b58encode(payload)), payload)

    def test_b58_leading_zero_bytes_survive(self):
        raw = bytes(31) + b"\x07"
        self.assertEqual(b58decode(b58encode(raw)), raw)

    def test_reader_is_bounds_checked(self):
        reader = Reader(b"\x01")
        reader.u8()
        with self.assertRaises(DecodeError):
            reader.u8()

    def test_reader_rejects_short_payload(self):
        with self.assertRaises(DecodeError):
            Reader(b"\x01\x02").u64()


class TestAnchorDiscriminators(unittest.TestCase):
    def test_known_values(self):
        # Values observed on mainnet, so a hashing regression is caught.
        self.assertEqual(anchor_ix("sell"), "33e685a4017f83ad")
        self.assertEqual(anchor_ix("buy"), "66063d1201daebea")
        self.assertEqual(anchor_ix("swap"), "f8c69e91e17587c8")
        self.assertEqual(anchor_ix("rebalance_liquidity"), "5c04b0c177b95309")
        self.assertEqual(anchor_discriminator("event", "TradeEvent"), "bddb7fd34ee661ee")
        self.assertEqual(anchor_ix("buy_exact_quote_in"), "c62e1552b4d9e870")


class TestPumpFunTradeEvent(unittest.TestCase):
    """The TradeEvent decoder is verified against real balance deltas."""

    def test_trade_event_matches_observed_delta(self):
        checked = 0
        for name in ("pumpfun", "pumpswap", "pumpfun_new"):
            for tx in corpus(name):
                owner = owner_of(tx)
                deltas = owner_deltas(tx, owner)
                view = build_view(tx)
                trades, _ = analyse(view, frozenset({owner}))
                events = [t for t in trades if t.kind in ("buy", "sell") and "user" in t.extra]
                for intent in events:
                    token_amount = intent.extra["token_amount"]
                    mint = intent.mint_out if intent.kind == "buy" else intent.mint_in
                    observed = deltas.get(mint)
                    if observed is None:
                        continue
                    self.assertEqual(
                        abs(observed[0]),
                        token_amount,
                        f"{name}: decoded token_amount disagrees with the chain",
                    )
                    self.assertEqual(
                        observed[0] > 0,
                        intent.kind == "buy",
                        f"{name}: is_buy disagrees with the direction of the delta",
                    )
                    checked += 1
        self.assertGreater(checked, 0, "no pump.fun TradeEvent was validated")

    def test_sell_instruction_layout(self):
        """``sell`` = u64 token amount + u64 minimum SOL output, 24 bytes total."""
        found = 0
        for tx in corpus("pumpfun") + corpus("pumpswap"):
            for _tag, ix in instructions(tx):
                if ix.get("programId") not in (
                    "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P",
                    "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA",
                ):
                    continue
                if not ix.get("data"):
                    continue
                raw = b58decode(ix["data"])
                if raw[:8].hex() != anchor_ix("sell") or len(raw) != 24:
                    continue
                reader = Reader(raw, 8)
                token_amount = reader.u64()
                min_sol = reader.u64()
                self.assertGreater(token_amount, 0)
                self.assertGreater(min_sol, 0)
                self.assertEqual(reader.remaining(), 0, "sell payload has trailing bytes")
                found += 1
        self.assertGreater(found, 0, "no sell instruction found in the corpus")

    def test_buy_exact_quote_in_layout(self):
        found = 0
        for tx in corpus("pumpswap"):
            for _tag, ix in instructions(tx):
                if ix.get("programId") != "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA":
                    continue
                if not ix.get("data"):
                    continue
                raw = b58decode(ix["data"])
                if raw[:8].hex() != anchor_ix("buy_exact_quote_in"):
                    continue
                self.assertEqual(len(raw), 25, "buy_exact_quote_in should be 8+8+8+1 bytes")
                reader = Reader(raw, 8)
                self.assertGreater(reader.u64(), 0)  # quote amount
                self.assertGreater(reader.u64(), 0)  # min base out
                reader.bool_()
                self.assertEqual(reader.remaining(), 0)
                found += 1
        self.assertGreater(found, 0, "no buy_exact_quote_in found in the corpus")

    def test_anchor_event_prefix_is_the_documented_constant(self):
        self.assertEqual(ANCHOR_EVENT_PREFIX, "e445a52e51cb9a1d")


class TestPumpSwapEventNameInPayload(unittest.TestCase):
    def test_instruction_name_is_recoverable(self):
        """PumpSwap's event blob carries its own instruction name as a borsh string.

        Not needed for the payload, but it is how the venue was confirmed to be
        PumpSwap rather than the bonding curve, so it is pinned by a test.
        """
        import struct

        needle_names = ("buy_exact_quote_in",)
        found: list[str] = []
        for tx in corpus("pumpswap"):
            for _tag, ix in instructions(tx):
                if not ix.get("data"):
                    continue
                raw = b58decode(ix["data"])
                if len(raw) < 17 or raw[:8].hex() != "e445a52e51cb9a1d":
                    continue
                for name in needle_names:
                    encoded = struct.pack("<I", len(name)) + name.encode()
                    if encoded in raw:
                        found.append(name)
        self.assertIn("buy_exact_quote_in", found)


class TestRaydium(unittest.TestCase):
    def test_amm4_swap_layout(self):
        found = 0
        for tx in corpus("raydium_amm4"):
            for _tag, ix in instructions(tx):
                if ix.get("programId") != "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8":
                    continue
                if not ix.get("data"):
                    continue
                raw = b58decode(ix["data"])
                if len(raw) != 17:
                    continue
                reader = Reader(raw)
                amount_in = reader.u64()
                min_out = reader.u64()
                direction = reader.u8()
                self.assertGreater(amount_in, 0)
                self.assertGreater(min_out, 0)
                self.assertIn(direction, (0, 1))
                found += 1
        self.assertGreater(found, 0, "no Raydium AMM v4 swap found in the corpus")

    def test_amount_in_never_exceeds_observed_outflow(self):
        for tx in corpus("raydium_amm4"):
            owner = owner_of(tx)
            deltas = owner_deltas(tx, owner)
            view = build_view(tx)
            trades, _ = analyse(view, frozenset({owner}))
            for intent in trades:
                if intent.program_id != "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8":
                    continue
                spent = [abs(v[0]) for m, v in deltas.items() if v[0] < 0]
                if not spent or intent.amount_in is None:
                    continue
                self.assertLessEqual(
                    intent.amount_in,
                    max(spent) * 2,
                    "decoded amount_in wildly exceeds the observed outflow",
                )


class TestMeteoraDLMM(unittest.TestCase):
    def test_swap_layout(self):
        found = 0
        for tx in corpus("meteora_dlmm"):
            for _tag, ix in instructions(tx):
                if ix.get("programId") != "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo":
                    continue
                if not ix.get("data"):
                    continue
                raw = b58decode(ix["data"])
                if raw[:8].hex() != anchor_ix("swap"):
                    continue
                reader = Reader(raw, 8)
                amount_in = reader.u64()
                reader.u64()  # minimum out
                self.assertEqual(reader.remaining(), 0)
                found += 1
                self.assertGreaterEqual(amount_in, 0)
        self.assertGreater(found, 0, "no DLMM swap found in the corpus")

    def test_bin_ranges_are_ordered(self):
        from raycore.decoders.meteora import ADD_LIQUIDITY_DISC, INITIALIZE_POSITION_DISC

        found = 0
        for tx in corpus("meteora_dlmm"):
            for _tag, ix in instructions(tx):
                if ix.get("programId") != "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo":
                    continue
                if not ix.get("data"):
                    continue
                raw = b58decode(ix["data"])
                disc = raw[:8].hex()
                if disc not in (ADD_LIQUIDITY_DISC, INITIALIZE_POSITION_DISC):
                    continue
                low, high = Reader(raw, 8).i32(), Reader(raw, 12).i32()
                self.assertLessEqual(low, high, "min_bin_id must not exceed max_bin_id")
                found += 1
        self.assertGreater(found, 0, "no DLMM liquidity instruction found in the corpus")

    def test_bin_step_is_recovered_from_rebalance(self):
        from raycore.decoders import build_context
        from raycore.decoders.meteora import read_bin_step

        checked = 0
        for tx in corpus("meteora_dlmm"):
            view = build_view(tx)
            ctx = build_context(view, frozenset({owner_of(tx)}))
            step = read_bin_step(ctx)
            if step is not None:
                self.assertIn(step, {1, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000})
                checked += 1
        self.assertGreater(checked, 0, "no bin_step was recovered from any rebalance")


class TestGracefulDegradation(unittest.TestCase):
    """A decoder must never invent a number the chain did not record."""

    def test_truncated_payloads_do_not_raise(self):
        for name in ("pumpfun", "pumpswap", "meteora_dlmm", "raydium_amm4"):
            for tx in corpus(name):
                view = build_view(tx)
                analyse(view, frozenset({owner_of(tx)}))  # must not raise

    def test_garbage_payloads_are_ignored(self):
        from raycore.decoders.base import DecodedContext, Instruction
        from raycore.decoders.base import registry

        view = build_view(corpus("pumpfun")[0])
        ix = Instruction(
            program_id="6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P",
            data=b"\x00" * 4,
            accounts=[],
            depth=0,
            index=0,
        )
        ctx = DecodedContext(
            view=view,
            instructions=[ix],
            mints={},
            tracked=frozenset(),
        )
        trades, _ = registry.decode(ctx)
        self.assertEqual(trades, [])

    def test_normalise_keeps_cpi_instructions(self):
        for tx in corpus("pumpfun"):
            instructions_found = normalise_instructions(tx)
            self.assertTrue(instructions_found)
            for ix in instructions_found:
                self.assertIsInstance(ix.data, bytes)
                self.assertIn(ix.depth, (0, 1))


class TestDeltaLayer(unittest.TestCase):
    def test_deltas_match_manual_computation(self):
        for name in ("pumpfun", "raydium_amm4"):
            for tx in corpus(name):
                owner = owner_of(tx)
                view = build_view(tx)
                expected = owner_deltas(tx, owner)
                for delta in view.deltas(owner):
                    if delta.mint == WSOL:
                        continue
                    self.assertIn(delta.mint, expected)
                    self.assertEqual(delta.raw_delta, expected[delta.mint][0])
                    self.assertEqual(delta.decimals, expected[delta.mint][1])

    def test_sol_delta_matches_manually(self):
        for tx in corpus("pumpfun"):
            owner = owner_of(tx)
            view = build_view(tx)
            self.assertEqual(view.sol_delta(owner), sol_delta(tx, owner))

    def test_touched_only_lists_moving_wallets(self):
        for tx in corpus("raydium_amm4"):
            view = build_view(tx)
            for wallet in view.touched():
                self.assertTrue(view.deltas(wallet), "touched wallet must have deltas")


class TestVenueCoverage(unittest.TestCase):
    def test_every_fixture_venue_is_registered(self):
        from raycore.decoders import registry

        registered = registry.known_programs()
        expected = {
            "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P",  # pump.fun
            "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA",  # PumpSwap
            "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8",  # Raydium AMM v4
            "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo",  # Meteora DLMM
            "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc",  # Orca Whirlpool
            "9W959DqEETiGZocYWCQPaJ6sBmUzgfxXfqGeTEdp3aQP",  # Orca v2
        }
        self.assertTrue(
            expected <= registered,
            f"unregistered venues: {sorted(expected - registered)}",
        )

    def test_quote_mints_are_the_majors(self):
        self.assertIn(WSOL, QUOTE_MINTS)
        self.assertIn("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", QUOTE_MINTS)
        self.assertTrue(set(DEX_PROGRAMS) >= {p for p in DEX_PROGRAMS if p.startswith("6EF")})


if __name__ == "__main__":
    unittest.main(verbosity=2)