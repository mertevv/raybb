# -*- coding: utf-8 -*-
"""Shared test helpers and the harvested mainnet corpus.

The fixtures in ``fixtures/`` are real ``getTransaction`` responses captured from
mainnet-beta for each venue, so every decoder assertion below is checked against
data the chain actually produced.
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Iterator

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

FIXTURES = os.path.join(HERE, "fixtures")

WSOL = "So11111111111111111111111111111111111111112"


def corpus(name: str) -> list[dict[str, Any]]:
    path = os.path.join(FIXTURES, f"{name}.json")
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def iter_corpus(*names: str) -> Iterator[tuple[str, dict[str, Any]]]:
    for name in names:
        for tx in corpus(name):
            yield name, tx


def message(tx: dict[str, Any]) -> dict[str, Any]:
    return tx["transaction"]["message"]


def meta(tx: dict[str, Any]) -> dict[str, Any]:
    return tx["meta"]


def account_keys(tx: dict[str, Any]) -> list[str]:
    message_ = message(tx)
    keys = [k["pubkey"] for k in message_["accountKeys"] if isinstance(k, dict)]
    loaded = message_.get("loadedAddresses") or {}
    return keys + list(loaded.get("writable") or []) + list(loaded.get("readonly") or [])


def instructions(tx: dict[str, Any]) -> Iterator[tuple[str, dict[str, Any]]]:
    for ix in message(tx).get("instructions") or []:
        yield "top", ix
    for group in meta(tx).get("innerInstructions") or []:
        for ix in group.get("instructions") or []:
            yield "inner", ix


def owner_deltas(tx: dict[str, Any], owner: str) -> dict[str, tuple[int, int]]:
    """``mint -> (raw delta, decimals)`` for one owner, from balance snapshots."""
    result: dict[str, tuple[int, int]] = {}
    pre = {e["accountIndex"]: e for e in meta(tx).get("preTokenBalances") or []}
    post = {e["accountIndex"]: e for e in meta(tx).get("postTokenBalances") or []}
    for index in set(pre) | set(post):
        entry = post.get(index) or pre.get(index)
        if entry.get("owner") != owner:
            continue
        after = int(((post.get(index) or {}).get("uiTokenAmount") or {}).get("amount") or 0)
        before = int(((pre.get(index) or {}).get("uiTokenAmount") or {}).get("amount") or 0)
        if after != before:
            result[entry["mint"]] = (after - before, entry["uiTokenAmount"]["decimals"])
    return result


def sol_delta(tx: dict[str, Any], owner: str) -> int:
    keys = account_keys(tx)
    if owner not in keys:
        return 0
    index = keys.index(owner)
    return meta(tx)["postBalances"][index] - meta(tx)["preBalances"][index]


def owner_of(tx: dict[str, Any]) -> str:
    return account_keys(tx)[0]