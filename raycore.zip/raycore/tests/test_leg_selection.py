# -*- coding: utf-8 -*-
"""Tests for how the two legs of a trade are identified.

These are the decisions that decide what a position is denominated in, so they
are pinned individually — the live-captured fixtures cover only a few shapes.
"""

from __future__ import annotations

import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from raycore.deltas import BalanceDelta
from raycore.events import EventBuilder, classify
from raycore.ids import USDC, WSOL
from raycore.pricing import TokenInfo
from raycore.store import Store

PAY = "PAYmint11111111111111111111111111111111111"
SPEC = "SPECmint11111111111111111111111111111111111"
JUNK = "JUNKmint1111111111111111111111111111111111"


def delta(mint: str, raw: int, decimals: int) -> BalanceDelta:
    return BalanceDelta(wallet="W", mint=mint, raw_delta=raw, decimals=decimals)


class TestLegSelection(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.store = Store(os.path.join(self._tmp.name, "l.sqlite3"))
        await self.store.connect()
        self.builder = EventBuilder(self.store, object(), object())  # type: ignore[arg-type]

    async def asyncTearDown(self) -> None:
        await self.store.close()
        self._tmp.cleanup()

    def _tokens(self, **prices) -> dict[str, TokenInfo]:
        """``_tokens(PAY=0.5)`` builds a price entry for the PAY mint."""
        out = {}
        for label, price in prices.items():
            mint = globals().get(label, label)
            decimals = 9 if mint == WSOL else 6
            out[mint] = TokenInfo(mint=mint, symbol=label, decimals=decimals, price_usd=price)
        return out

    async def test_sol_buy_pays_with_sol(self):
        deltas = [delta(PAY, 1_000_000, 6), delta(WSOL, -2_000_000_000, 9)]
        quote = self.builder._pick_quote_leg(
            [d for d in deltas if d.raw_delta < 0],
            self.builder._pick_base_leg([deltas[0]], [deltas[1]], {}),
            self._tokens(PAY=0.5, **{WSOL: 100.0}),
        )
        self.assertIsNotNone(quote)
        self.assertEqual(quote.mint, WSOL)

    async def test_fee_only_sol_is_not_the_payment(self):
        """A token-for-token buy carries a small SOL fee leg; it must be ignored."""
        deltas = [
            delta(PAY, 1_000_000_000, 6),  # 1000 tokens
            delta(SPEC, -2_000_000_000, 6),  # 2000 tokens
            delta(WSOL, -5_000_000, 9),  # $0.50 fee against a ~$600 payment
        ]
        base = self.builder._pick_base_leg([deltas[0]], deltas[1:], {})
        quote = self.builder._pick_quote_leg(deltas[1:], base, self._tokens(PAY=0.5, SPEC=0.3, **{WSOL: 100.0}))
        self.assertEqual(quote.mint, SPEC, "the fee leg was booked as the payment")

    async def test_substantial_sol_is_still_the_payment(self):
        """When SOL is a real share of a token-for-token trade, it is the quote."""
        deltas = [
            delta(PAY, 100_000_000, 6),  # 100 tokens
            delta(SPEC, -100_000_000, 6),  # 100 tokens
            delta(WSOL, -10_000_000, 9),  # $1 fee against a $30 token leg
        ]
        base = self.builder._pick_base_leg([deltas[0]], deltas[1:], {})
        quote = self.builder._pick_quote_leg(deltas[1:], base, self._tokens(PAY=0.5, SPEC=0.3, **{WSOL: 100.0}))
        self.assertEqual(quote.mint, WSOL)

    async def test_stablecoin_quote(self):
        deltas = [delta(PAY, 1_000_000, 6), delta(USDC, -500_000, 6), delta(WSOL, -3_000_000, 9)]
        base = self.builder._pick_base_leg([deltas[0]], deltas[1:], {})
        quote = self.builder._pick_quote_leg(deltas[1:], base, self._tokens(PAY=0.5, USDC=1.0, **{WSOL: 100.0}))
        self.assertEqual(quote.mint, USDC)

    async def test_no_quote_leg(self):
        self.assertIsNone(self.builder._pick_quote_leg([], delta(PAY, 1, 6), {}))

    def test_base_leg_prefers_the_non_counterparty(self):
        incoming = [delta(PAY, 5_000_000, 6), delta(JUNK, 1_000, 6)]
        outgoing = [delta(SPEC, -5_000_000, 6)]
        base = self.builder._pick_base_leg(incoming, outgoing, {})
        self.assertEqual(base.mint, PAY)

    def test_base_leg_falls_back_to_the_decoder_hint(self):
        incoming = [delta(SPEC, 5_000_000, 6), delta(PAY, 5_000_000, 6)]
        outgoing = [delta(SPEC, -5_000_000, 6)]
        base = self.builder._pick_base_leg(incoming, outgoing, {"mintOut": PAY})
        self.assertEqual(base.mint, PAY)

    def test_base_leg_ignores_native_fee_when_every_leg_crosses(self):
        incoming = [delta(WSOL, 1_000_000, 9), delta(PAY, 5_000_000, 6)]
        outgoing = [delta(SPEC, -5_000_000, 6)]
        base = self.builder._pick_base_leg(incoming, outgoing, {})
        self.assertEqual(base.mint, PAY, "the SOL leg is a fee, not the subject")

    def test_swap_classification_from_shape_alone(self):
        incoming = [delta(PAY, 100, 6)]
        outgoing = [delta(SPEC, -100, 6)]
        event_type, detail = classify(incoming + outgoing, None, [])
        self.assertEqual(event_type, "swap")
        self.assertEqual(detail["mintIn"], PAY)
        self.assertEqual(detail["mintOut"], SPEC)

    def test_buy_classification_when_a_stablecoin_paid(self):
        incoming = [delta(PAY, 100, 6)]
        outgoing = [delta(USDC, -100, 6)]
        event_type, _ = classify(incoming + outgoing, None, [])
        self.assertEqual(event_type, "buy")

    def test_sell_classification_when_a_stablecoin_was_received(self):
        incoming = [delta(USDC, 100, 6)]
        outgoing = [delta(PAY, -100, 6)]
        event_type, _ = classify(incoming + outgoing, None, [])
        self.assertEqual(event_type, "sell")

    def test_transfer_in_when_only_one_leg_moved(self):
        event_type, _ = classify([delta(USDC, 100, 6)], None, [])
        self.assertEqual(event_type, "transfer_in")

    def test_transfer_out_when_only_one_leg_moved(self):
        event_type, _ = classify([delta(USDC, -100, 6)], None, [])
        self.assertEqual(event_type, "transfer_out")

    def test_implied_price_is_derived_from_the_priced_leg(self):
        """An unpriced token next to a priced one yields the implied price."""
        deltas = [delta(PAY, 1_000_000, 6), delta(WSOL, -2_000_000_000, 9)]
        tokens = {PAY: TokenInfo(mint=PAY, decimals=6, price_usd=0.0), WSOL: TokenInfo(mint=WSOL, decimals=9, price_usd=100.0)}
        price = EventBuilder._price_for(deltas[0], deltas, tokens)
        # 2 SOL at $100 = $200 for 1 token.
        self.assertAlmostEqual(price, 200.0, places=6)

    def test_fetched_price_wins_over_the_implied_one(self):
        deltas = [delta(PAY, 1_000_000, 6), delta(WSOL, -2_000_000_000, 9)]
        tokens = {PAY: TokenInfo(mint=PAY, decimals=6, price_usd=0.25), WSOL: TokenInfo(mint=WSOL, decimals=9, price_usd=100.0)}
        self.assertAlmostEqual(EventBuilder._price_for(deltas[0], deltas, tokens), 0.25, places=9)

    def test_trade_price_covers_both_legs(self):
        """Both sides of one swap must agree on the price they traded at."""
        deltas = [delta(PAY, 1_000_000, 6), delta(WSOL, -2_000_000_000, 9)]
        tokens = {PAY: TokenInfo(mint=PAY, decimals=6, price_usd=0.5), WSOL: TokenInfo(mint=WSOL, decimals=9, price_usd=100.0)}
        price = EventBuilder._trade_price(deltas, tokens)
        # 2 SOL at $100 is $200 for 1 PAYR — not PAYR's $0.50 spot price.
        self.assertAlmostEqual(price, 200.0, places=6)

    def test_trade_price_for_a_sell(self):
        """A sell moves the token out; the price must still be per unit of it."""
        deltas = [delta(PAY, -1_000_000, 6), delta(WSOL, 2_000_000_000, 9)]
        tokens = {PAY: TokenInfo(mint=PAY, decimals=6, price_usd=0.5), WSOL: TokenInfo(mint=WSOL, decimals=9, price_usd=100.0)}
        # 2 SOL at $100 is $200 for 1 PAYR sold.
        self.assertAlmostEqual(EventBuilder._trade_price(deltas, tokens), 200.0, places=6)

    def test_trade_price_applies_only_to_the_traded_token(self):
        """A SOL leg must keep its own price, not the memecoin's unit price.

        Live soak test caught this: a 2.4 SOL leg priced at a $0.00016 memecoin
        unit reported value_usd of ~0, so every trade looked worthless.
        """
        deltas = [delta(PAY, 1_000_000_000, 6), delta(WSOL, -2_474_100_000, 9)]
        tokens = {PAY: TokenInfo(mint=PAY, decimals=6, price_usd=0.00013369), WSOL: TokenInfo(mint=WSOL, decimals=9, price_usd=119.72)}
        trade_price = EventBuilder._trade_price(deltas, tokens)
        traded = EventBuilder._traded_mint(deltas, tokens, trade_price)
        self.assertEqual(traded, PAY)
        # Only the PAY leg takes the trade price.
        self.assertAlmostEqual(
            trade_price, 2.4741 * 119.72 / 1000.0, places=6
        )
        # The SOL leg keeps its real price, so its value is the payment itself.
        self.assertAlmostEqual(EventBuilder._price_for(deltas[1], deltas, tokens), 119.72, places=6)
        self.assertAlmostEqual(
            EventBuilder._price_for(deltas[1], deltas, tokens) * abs(deltas[1].amount),
            296.23,
            places=1,
        )

    def test_traded_mint_is_none_without_a_trade_price(self):
        deltas = [delta(PAY, 1_000_000, 6), delta(WSOL, -2_000_000_000, 9)]
        tokens = {PAY: TokenInfo(mint=PAY, decimals=6, price_usd=0.0), WSOL: TokenInfo(mint=WSOL, decimals=9, price_usd=100.0)}
        self.assertIsNone(EventBuilder._traded_mint(deltas, tokens, None))

    def test_trade_price_is_none_for_a_one_sided_transfer(self):
        deltas = [delta(USDC, 1_000_000, 6)]
        tokens = {USDC: TokenInfo(mint=USDC, decimals=6, price_usd=1.0)}
        self.assertIsNone(EventBuilder._trade_price(deltas, tokens))

    def test_trade_price_is_none_when_nothing_is_priced(self):
        deltas = [delta(PAY, 1_000_000, 6), delta(SPEC, -1_000_000, 6)]
        tokens = {m: TokenInfo(mint=m, decimals=6, price_usd=0.0) for m in (PAY, SPEC)}
        self.assertIsNone(EventBuilder._trade_price(deltas, tokens))

    def test_trade_price_ignores_the_fee_leg(self):
        """A SOL fee leg must not drag the reported trade price down."""
        deltas = [
            delta(PAY, 1_000_000_000, 6),
            delta(SPEC, -2_000_000_000, 6),
            delta(WSOL, -5_000_000, 9),
        ]
        tokens = {PAY: TokenInfo(mint=PAY, decimals=6, price_usd=0.0), SPEC: TokenInfo(mint=SPEC, decimals=6, price_usd=0.3), WSOL: TokenInfo(mint=WSOL, decimals=9, price_usd=100.0)}
        # 2000 SPEC at $0.30 = $600 for 1000 PAYR, not $600 minus the $0.50 fee.
        self.assertAlmostEqual(EventBuilder._trade_price(deltas, tokens), 0.6, places=9)

    def test_no_legs_priced_yields_zero(self):
        deltas = [delta(PAY, 1_000_000, 6), delta(SPEC, -1_000_000, 6)]
        tokens = {m: TokenInfo(mint=m, decimals=6, price_usd=0.0) for m in (PAY, SPEC)}
        self.assertEqual(EventBuilder._price_for(deltas[0], deltas, tokens), 0.0)

    def test_implausible_implied_price_is_rejected(self):
        """A zero-priced leg beside a dust leg must not invent a huge price."""
        deltas = [delta(PAY, 1_000_000, 6), delta(JUNK, 1, 6)]
        tokens = {PAY: TokenInfo(mint=PAY, decimals=6, price_usd=0.0), JUNK: TokenInfo(mint=JUNK, decimals=6, price_usd=1.0)}
        price = EventBuilder._price_for(deltas[0], deltas, tokens)
        self.assertLess(price, 1e6, "an absurd implied price was accepted")

    def test_zero_amount_leg_has_no_price(self):
        deltas = [delta(PAY, 0, 6)]
        self.assertEqual(EventBuilder._price_for(deltas[0], deltas, {}), 0.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)