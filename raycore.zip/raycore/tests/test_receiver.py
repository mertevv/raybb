# -*- coding: utf-8 -*-
"""Webhook receiver tests: auth, ack timing, queueing, health."""

from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

from raycore.config import Settings
from raycore.server import WebhookReceiver

SECRET = "Bearer unit-test-secret"


def _settings(tmpdir: str, **overrides) -> Settings:
    import dataclasses

    base = {
        "db_path": os.path.join(tmpdir, "r.sqlite3"),
        "receiver_port": 0,  # let the OS choose
        "receiver_path": "/hook",
        "receiver_secret": SECRET,
    }
    base.update(overrides)
    fields = {f.name for f in dataclasses.fields(Settings)}
    return Settings(**{k: v for k, v in base.items() if k in fields})


class TestReceiver(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.settings = _settings(self._tmp.name)
        self.received: list[dict] = []
        self._workers: list[WebhookReceiver] = []

    async def asyncTearDown(self) -> None:
        for receiver in self._workers:
            await self._teardown_worker(receiver)
        self._tmp.cleanup()

    async def _client(self, receiver: WebhookReceiver) -> TestClient:
        # Expose the aiohttp app directly; the runner is not needed for routing.
        server = TestServer(receiver._app)
        client = TestClient(server)
        await client.start_server()
        # Mirrors WebhookReceiver.start(): the drain worker has to be running for
        # queued deliveries to reach the handler.
        receiver._worker = asyncio.create_task(receiver._drain())
        self._workers.append(receiver)
        return client

    async def _teardown_worker(self, receiver: WebhookReceiver) -> None:
        worker = receiver._worker
        if worker is None:
            return
        worker.cancel()
        try:
            await worker
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
        receiver._worker = None

    def _delivery(self, signature: str = "sig-1", event: str = "buy") -> dict:
        return {
            "id": signature,
            "event_type": event,
            "chain": "solana",
            "token_changes": [],
            "tokens": {},
        }

    def _headers(self, auth: str | None = SECRET) -> dict:
        headers = {"Content-Type": "application/json", "User-Agent": "RayBot-Webhook/1.0"}
        if auth is not None:
            headers["Authorization"] = auth
        return headers

    async def test_accepts_a_valid_delivery(self):
        receiver = WebhookReceiver(self.settings, handler=self.received.append)
        client = await self._client(receiver)
        try:
            resp = await client.post(
                "/hook",
                data=json.dumps(self._delivery()),
                headers={**self._headers(), "X-RayBot-Event": "buy"},
            )
            self.assertEqual(resp.status, 204)
            await asyncio.sleep(0.05)
            self.assertEqual(len(self.received), 1)
            self.assertEqual(self.received[0]["id"], "sig-1")
        finally:
            await client.close()

    async def test_rejects_a_bad_authorization_header(self):
        receiver = WebhookReceiver(self.settings, handler=self.received.append)
        client = await self._client(receiver)
        try:
            resp = await client.post(
                "/hook", data=json.dumps(self._delivery()), headers=self._headers("Bearer wrong")
            )
            self.assertEqual(resp.status, 401)
            body = await resp.json()
            self.assertEqual(body["error"]["code"], "UNAUTHORIZED")
            await asyncio.sleep(0.05)
            self.assertEqual(self.received, [])
        finally:
            await client.close()

    async def test_missing_authorization_is_rejected_when_a_secret_is_set(self):
        receiver = WebhookReceiver(self.settings, handler=self.received.append)
        client = await self._client(receiver)
        try:
            resp = await client.post(
                "/hook", data=json.dumps(self._delivery()), headers=self._headers(auth=None)
            )
            self.assertEqual(resp.status, 401)
        finally:
            await client.close()

    async def test_open_endpoint_when_no_secret_configured(self):
        receiver = WebhookReceiver(_settings(self._tmp.name, receiver_secret=""))
        client = await self._client(receiver)
        try:
            resp = await client.post(
                "/hook", data=json.dumps(self._delivery()), headers=self._headers(auth=None)
            )
            self.assertEqual(resp.status, 204)
        finally:
            await client.close()

    async def test_test_ping_is_acked_without_queueing(self):
        receiver = WebhookReceiver(self.settings, handler=self.received.append)
        client = await self._client(receiver)
        try:
            resp = await client.post(
                "/hook",
                data=json.dumps({"event_type": "test", "message": "verification"}),
                headers=self._headers(),
            )
            self.assertEqual(resp.status, 204)
            self.assertEqual(receiver._queue.qsize(), 0)
        finally:
            await client.close()

    async def test_malformed_json_is_rejected(self):
        receiver = WebhookReceiver(self.settings, handler=self.received.append)
        client = await self._client(receiver)
        try:
            resp = await client.post("/hook", data="{not json", headers=self._headers())
            self.assertEqual(resp.status, 400)
        finally:
            await client.close()

    async def test_non_object_body_is_rejected(self):
        receiver = WebhookReceiver(self.settings, handler=self.received.append)
        client = await self._client(receiver)
        try:
            resp = await client.post("/hook", data=json.dumps([1, 2, 3]), headers=self._headers())
            self.assertEqual(resp.status, 400)
        finally:
            await client.close()

    async def test_ack_does_not_wait_for_the_handler(self):
        """A slow handler must not delay the response."""
        release = asyncio.Event()

        async def slow(payload):
            await release.wait()

        receiver = WebhookReceiver(self.settings, handler=slow)
        client = await self._client(receiver)
        try:
            resp = await client.post("/hook", data=json.dumps(self._delivery()), headers=self._headers())
            self.assertEqual(resp.status, 204)
            release.set()
        finally:
            receiver._worker.cancel()
            await client.close()

    async def test_full_queue_reports_503(self):
        receiver = WebhookReceiver(self.settings, handler=self.received.append)
        client = await self._client(receiver)
        try:
            # Fill the queue after the client is up, so the worker cannot drain it.
            drain = receiver._worker
            receiver._worker = None  # stop the drain loop
            if drain is not None:
                drain.cancel()
                try:
                    await drain
                except asyncio.CancelledError:
                    pass
            self._workers.remove(receiver)
            for _ in range(receiver._queue.maxsize):
                receiver._queue.put_nowait({})
            self.assertTrue(receiver._queue.full())

            resp = await client.post("/hook", data=json.dumps(self._delivery()), headers=self._headers())
            self.assertEqual(resp.status, 503)
        finally:
            await client.close()

    async def test_health_reports_queue_depth(self):
        receiver = WebhookReceiver(self.settings, handler=self.received.append)
        client = await self._client(receiver)
        try:
            resp = await client.get("/health")
            self.assertEqual(resp.status, 200)
            body = await resp.json()
            self.assertTrue(body["ok"])
            self.assertEqual(body["queue"], 0)
        finally:
            await client.close()

    async def test_handler_exception_does_not_kill_the_worker(self):
        calls: list[int] = []

        async def flaky(payload):
            calls.append(1)
            if len(calls) == 1:
                raise RuntimeError("boom")

        receiver = WebhookReceiver(self.settings, handler=flaky)
        client = await self._client(receiver)
        try:
            receiver._queue.put_nowait({"id": "a"})
            receiver._queue.put_nowait({"id": "b"})
            await asyncio.sleep(0.1)
            self.assertEqual(len(calls), 2)
        finally:
            await client.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)