# -*- coding: utf-8 -*-
"""Payload-schema tests.

The emitted object must satisfy the documented contract exactly: required keys
present, types correct, ``event_type`` drawn from the known set, ``position`` only
on buy/sell, no ``NaN`` leaking into JSON.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

from helpers import corpus, owner_of

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from raycore.deltas import build_view
from raycore.events import CHAIN, EVENT_TYPES, EventBuilder
from raycore.positions import PositionTracker
from raycore.pricing import TokenInfo
from raycore.store import Store

REQUIRED_TOP_LEVEL = (
    "id",
    "event_type",
    "timestamp",
    "chain",
    "failed",
    "source",
    "fee_payer",
    "followed_wallets",
    "token_changes",
    "tokens",
    "fees",
)

POSITION_KEYS = {
    "side",
    "is_new_position",
    "is_closed",
    "total_quantity",
    "average_cost_basis",
    "current_price",
    "total_invested",
    "realized_pnl",
    "unrealized_pnl",
}


class StubOracle:
    """Deterministic prices: $1 for stablecoins, $100 for everything else."""

    def __init__(self) -> None:
        self.calls: list[list[str]] = []

    async def get_many(self, mints):
        mints = [m for m in mints]
        self.calls.append(mints)
        from raycore.ids import STATIC_TOKENS

        out: dict[str, TokenInfo] = {}
        for mint in mints:
            static = STATIC_TOKENS.get(mint, {})
            symbol = static.get("symbol") or f"TOK{mint[:3]}"
            decimals = static.get("decimals") or 6
            out[mint] = TokenInfo(
                mint=mint,
                symbol=symbol,
                name=symbol,
                decimals=decimals,
                price_usd=1.0 if symbol in ("USDC", "USDT") else 100.0,
                supply=1_000_000.0,
                fetched_at=1.0,
            )
        return out

    async def sol_price(self) -> float:
        return 100.0


class PayloadTestCase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.store = Store(os.path.join(self._tmp.name, "t.sqlite3"))
        await self.store.connect()
        self.oracle = StubOracle()
        self.builder = EventBuilder(self.store, self.oracle, PositionTracker(self.store))

    async def asyncTearDown(self) -> None:
        await self.store.close()
        self._tmp.cleanup()

    async def build_all(self, name: str) -> list[dict]:
        out: list[dict] = []
        for tx in corpus(name):
            owner = owner_of(tx)
            await self.store.add_wallet(owner, "test-wallet")
            view = build_view(tx)
            out.extend(await self.builder.build(view, [owner], {owner: "test-wallet"}))
        return out


class TestPayloadSchema(PayloadTestCase):
    async def test_required_keys_present_for_every_venue(self):
        for venue in ("pumpfun", "pumpswap", "meteora_dlmm", "raydium_amm4", "orca_amm2"):
            payloads = await self.build_all(venue)
            self.assertTrue(payloads, f"{venue}: no payload produced")
            for payload in payloads:
                for key in REQUIRED_TOP_LEVEL:
                    self.assertIn(key, payload, f"{venue}: missing {key}")
                self.assertEqual(payload["chain"], CHAIN)
                self.assertIn(payload["event_type"], EVENT_TYPES)
                self.assertIsInstance(payload["token_changes"], list)
                self.assertIsInstance(payload["tokens"], dict)
                self.assertIsInstance(payload["fees"], dict)

    async def test_token_changes_shape(self):
        for payload in await self.build_all("pumpfun"):
            for change in payload["token_changes"]:
                self.assertIn("address", change)
                self.assertIn(change["direction"], ("in", "out"))
                self.assertIn("mint", change)
                # amount_raw must be a string so large integers survive JSON.
                self.assertIsInstance(change["amount_raw"], str)
                int(change["amount_raw"])
                self.assertIsInstance(change["amount"], float)
                self.assertIsInstance(change["price_usd"], float)
                self.assertIsInstance(change["value_usd"], float)

    async def test_tokens_entries_have_socials(self):
        for payload in await self.build_all("raydium_amm4"):
            for mint, meta in payload["tokens"].items():
                self.assertEqual(set(meta["socials"]), {"twitter", "telegram", "website"})
                self.assertIsInstance(meta["decimals"], int)
                self.assertIn("price_usd", meta)

    async def test_position_only_on_trades(self):
        for venue in ("pumpfun", "pumpswap"):
            for payload in await self.build_all(venue):
                if payload["event_type"] in ("buy", "sell"):
                    self.assertIn("position", payload)
                    self.assertEqual(set(payload["position"]), POSITION_KEYS)
                else:
                    self.assertNotIn("position", payload)

    async def test_position_arithmetic_is_internally_consistent(self):
        for payload in await self.build_all("pumpfun"):
            position = payload.get("position")
            if not position:
                continue
            invested = position["total_invested"]
            quantity = position["total_quantity"]
            basis = position["average_cost_basis"]
            if position["is_closed"]:
                self.assertEqual(quantity, 0)
                self.assertIsNone(basis)
                self.assertIsNone(position["unrealized_pnl"])
            else:
                self.assertGreater(quantity, 0)
                self.assertIsNotNone(basis)
                self.assertGreaterEqual(basis, 0)
                # average_cost_basis * quantity tracks total_invested.
                self.assertAlmostEqual(basis * quantity, invested, places=6)

    async def test_failed_transactions_are_flagged(self):
        saw_failure = False
        for venue in ("pumpfun", "pumpfun_new", "meteora_dlmm"):
            for tx in corpus(venue):
                owner = owner_of(tx)
                view = build_view(tx)
                payloads = await self.builder.build(view, [owner], {})
                for payload in payloads:
                    self.assertEqual(payload["failed"], bool(tx["meta"].get("err")))
                    if payload["failed"]:
                        saw_failure = True
                        self.assertIn("error", payload)
        self.assertTrue(saw_failure, "corpus contained no failed transaction to check")

    async def test_payload_is_json_serialisable(self):
        for venue in ("pumpfun", "meteora_dlmm", "orca_amm2", "jupiter_v6"):
            for payload in await self.build_all(venue):
                text = json.dumps(payload, allow_nan=False)
                self.assertIn("event_type", text)
                self.assertNotIn("NaN", text)
                self.assertNotIn("Infinity", text)

    async def test_timestamp_is_iso_utc(self):
        for payload in await self.build_all("pumpfun"):
            self.assertTrue(payload["timestamp"].endswith("Z"))
            self.assertIn("T", payload["timestamp"])

    async def test_source_is_a_known_venue_label(self):
        allowed = {
            "pumpfun",
            "pumpswap",
            "raydium",
            "meteora",
            "orca",
            "jupiter",
            "system program",
            "solana program library",
            "associated token account",
            "solana",
        }
        for venue in ("pumpfun", "pumpswap", "raydium_amm4", "meteora_dlmm", "orca_amm2"):
            for payload in await self.build_all(venue):
                self.assertIn(payload["source"], allowed, f"{venue}: {payload['source']!r}")

    async def test_followed_wallet_matches_the_wallet_asked_about(self):
        owner = owner_of(corpus("pumpfun")[0])
        await self.store.add_wallet(owner, "named")
        view = build_view(corpus("pumpfun")[0])
        payloads = await self.builder.build(view, [owner], await self.store.names_for([owner]))
        for payload in payloads:
            self.assertEqual(len(payload["followed_wallets"]), 1)
            entry = payload["followed_wallets"][0]
            self.assertEqual(entry["address"], owner)
            self.assertEqual(entry["wallet_name"], "named")

    async def test_untracked_wallet_produces_nothing(self):
        owner = owner_of(corpus("pumpfun")[0])
        view = build_view(corpus("pumpfun")[0])
        payloads = await self.builder.build(view, ["11111111111111111111111111111111"], {})
        self.assertEqual(payloads, [])

    async def test_events_are_classified_into_known_types(self):
        from collections import Counter

        counter: Counter = Counter()
        for venue in ("pumpfun", "pumpswap", "meteora_dlmm", "raydium_amm4", "orca_amm2", "jupiter_v6"):
            for payload in await self.build_all(venue):
                counter[payload["event_type"]] += 1
        self.assertGreater(sum(counter.values()), 0)
        for event_type in counter:
            self.assertIn(event_type, EVENT_TYPES)


class TestFeeExtraction(PayloadTestCase):
    async def test_fees_are_non_negative_and_sum(self):
        from raycore.events import extract_fees

        for venue in ("pumpfun", "meteora_dlmm", "raydium_amm4"):
            for tx in corpus(venue):
                fees = extract_fees(build_view(tx))
                self.assertGreaterEqual(fees["priority_fee"], 0)
                self.assertGreaterEqual(fees["jito_tip"], 0)
                self.assertAlmostEqual(
                    fees["total_tip"], fees["priority_fee"] + fees["jito_tip"], places=12
                )

    async def test_priority_fee_is_detected(self):
        from raycore.events import extract_fees

        found = False
        for venue in ("pumpfun", "pumpswap", "jupiter_v6"):
            for tx in corpus(venue):
                if extract_fees(build_view(tx))["priority_fee"] > 0:
                    found = True
                    break
        self.assertTrue(found, "no priority fee was recovered from the corpus")


if __name__ == "__main__":
    unittest.main(verbosity=2)